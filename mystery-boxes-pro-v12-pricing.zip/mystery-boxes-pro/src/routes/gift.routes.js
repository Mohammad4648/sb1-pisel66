const express = require('express');
const router  = express.Router();
const gift    = require('../controllers/gift.controller');
const { protect } = require('../middleware/auth.middleware');

router.use(protect);
router.post('/send',          gift.sendGift);
router.get('/received',       gift.getReceived);
router.get('/sent',           gift.getSent);
router.post('/:id/accept',    gift.acceptGift);
router.post('/:id/decline',   gift.declineGift);
router.delete('/:id',         gift.cancelGift);

module.exports = router;
