const User     = require('../models/User');
const Referral = require('../models/Referral');
const { validationResult } = require('express-validator');
const { registerUserDevice, isSelfReferral, getClientIP } = require('../security/anti.fraud');
const notify = require('../services/notification.service');
const logger = require('../utils/logger');

const getCommissionRate = (t) => ({ bronze: 5, silver: 10, gold: 15, diamond: 20 }[t] || 5);
const sanitizeUser = (u) => ({
  id: u._id, username: u.username, email: u.email,
  walletBalance: u.walletBalance, walletId: u.walletId,
  referralCode: u.referralCode, tier: u.tier, role: u.role,
  level: u.level, xp: u.xp, referralCount: u.referralCount,
  totalCommissionEarned: u.totalCommissionEarned,
  loyaltyDiscount: `${((u.loyaltyDiscount ?? 0) * 100).toFixed(1)}%`  // خصم ولاء على السعر — لا علاقة بالحظ
});

exports.register = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ success: false, errors: errors.array() });
    const { username, email, password, referralCode } = req.body;
    const ip = req.clientIP || getClientIP(req);
    const fp = req.deviceFingerprint || null;

    const exists = await User.findOne({ $or: [{ email }, { username }] });
    if (exists) return res.status(400).json({ success: false, message: 'Username or email already taken' });

    const user = new User({ username, email, password, registrationIP: ip });
    if (fp) user.deviceFingerprints = [fp];

    if (referralCode) {
      const selfRef = await isSelfReferral(referralCode, user._id, ip, fp);
      if (selfRef) {
        logger.warn(`Self-referral blocked: IP=${ip}`);
        return res.status(400).json({ success: false, message: 'Referral code invalid from this network' });
      }
      const referrer = await User.findOne({ referralCode });
      if (referrer) {
        user.referredBy = referrer._id;
        referrer.referralCount += 1;
        referrer.updateTier();
        await referrer.save();
        await Referral.create({ referrer: referrer._id, referredUser: user._id, commissionRate: getCommissionRate(referrer.tier) });
      }
    }

    await user.save();
    registerUserDevice(user._id, ip, fp);
    notify.sendWelcome(user).catch(() => {});
    logger.info(`Registered: ${username} from ${ip}`);
    res.status(201).json({ success: true, token: user.generateAuthToken(), user: sanitizeUser(user) });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    const ip = req.clientIP || getClientIP(req);
    const user = await User.findOne({ email }).select('+password');
    if (!user || !(await user.comparePassword(password))) {
      logger.warn(`Failed login: ${email} from ${ip}`);
      return res.status(401).json({ success: false, message: 'Invalid credentials' });
    }
    if (user.isBanned) return res.status(403).json({ success: false, message: 'Account suspended' });
    user.lastLogin = new Date();
    user.lastLoginIP = ip;
    await user.save({ validateBeforeSave: false });
    registerUserDevice(user._id, ip, req.deviceFingerprint);
    res.json({ success: true, token: user.generateAuthToken(), user: sanitizeUser(user) });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.getMe = async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    res.json({ success: true, user });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.updateProfile = async (req, res) => {
  try {
    const { fullName, settings } = req.body;
    const user = await User.findByIdAndUpdate(req.user.id, { fullName, settings }, { new: true, runValidators: true });
    res.json({ success: true, user });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.changePassword = async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const user = await User.findById(req.user.id).select('+password');
    if (!(await user.comparePassword(currentPassword))) {
      return res.status(400).json({ success: false, message: 'Current password is incorrect' });
    }
    user.password = newPassword;
    await user.save();
    res.json({ success: true, message: 'Password updated' });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};
