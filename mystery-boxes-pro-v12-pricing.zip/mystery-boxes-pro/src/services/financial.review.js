/**
 * financial.review.js — مراجعة مالية شاملة
 *
 * يُجيب على سؤال واحد بدقة:
 * "هل المنصة ستربح أم تخسر؟ وكم بالضبط؟"
 *
 * يشمل:
 *   - تكاليف كل صندوق (المورد + الشحن + الدفع + العمولة + الكاشباك)
 *   - هامش الربح الصافي بعد كل التكاليف
 *   - نقطة التعادل (break-even)
 *   - توقعات الأرباح بناءً على حجم المبيعات
 *   - تحليل مخاطر الإرجاع
 */

const Order  = require('../models/Order');
const Box    = require('../models/Box');
const Item   = require('../models/Item');
const User   = require('../models/User');
const logger = require('../utils/logger');

// ── ثوابت التكاليف الثابتة ────────────────────────────────────────────────
const COST_CONSTANTS = {
  // أجرة معالجة الدفع (Stripe/Binance)
  paymentFeeFlat:    0.30,  // $ ثابت لكل معاملة
  paymentFeePercent: 0.029, // 2.9% من المبلغ

  // متوسط تكلفة شحن دولي اقتصادي
  shippingAvg: 0.90,

  // تكلفة خدمة العملاء (تقدير: 3% من الإيرادات)
  customerServiceRate: 0.03,

  // احتياطي الإرجاع (تقدير: 5% من الإيرادات)
  refundReserveRate: 0.05,

  // تكاليف تشغيل المنصة (server + bandwidth) لكل 1000 طلب
  serverCostPer1000: 2.0,
};

// ── تحليل تكلفة صندوق واحد ────────────────────────────────────────────────
function analyzeBoxCost(boxPrice, avgSupplierCost, shippingCost = 0.90, isDigital = false) {
  const payment     = +(boxPrice * COST_CONSTANTS.paymentFeePercent + COST_CONSTANTS.paymentFeeFlat).toFixed(4);
  const shipping    = isDigital ? 0 : shippingCost;
  const supplier    = avgSupplierCost;
  const customerSvc = +(boxPrice * COST_CONSTANTS.customerServiceRate).toFixed(4);
  const refundReserve = +(boxPrice * COST_CONSTANTS.refundReserveRate).toFixed(4);

  const totalCost  = +(payment + shipping + supplier + customerSvc + refundReserve).toFixed(4);
  const grossProfit= +(boxPrice - totalCost).toFixed(4);
  const margin     = boxPrice > 0 ? +(grossProfit / boxPrice * 100).toFixed(2) : 0;

  return {
    boxPrice,
    costs: {
      supplier:       +supplier.toFixed(4),
      shipping:       +shipping.toFixed(4),
      payment:        +payment.toFixed(4),
      customerService:+customerSvc.toFixed(4),
      refundReserve:  +refundReserve.toFixed(4),
      total:          totalCost
    },
    grossProfit,
    margin,
    breakEven: margin > 0
      ? Math.ceil(100 / margin) // كم طلب تحتاج لتحقيق 100$ ربح
      : null,
    viable: margin >= 10, // الحد الأدنى المقبول 10%
  };
}

// ── تحليل مالي كامل للمنصة (للأدمن) ────────────────────────────────────────
async function getPlatformFinancials(days = 30) {
  const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);

  // إحصائيات الطلبات
  const [orderStats, boxStats, refundStats] = await Promise.all([
    Order.aggregate([
      { $match: { status: 'completed', createdAt: { $gte: since } } },
      { $group: {
        _id:      null,
        revenue:  { $sum: '$price' },
        orders:   { $sum: 1 },
        avgPrice: { $avg: '$price' },
        totalItemValue: { $sum: '$totalValue' }
      }}
    ]),
    Order.aggregate([
      { $match: { status: 'completed', createdAt: { $gte: since } } },
      { $group: {
        _id:     '$boxName',
        revenue: { $sum: '$price' },
        orders:  { $sum: 1 },
        avgPrice:{ $avg: '$price' }
      }},
      { $sort: { revenue: -1 } },
      { $limit: 10 }
    ]),
    Order.aggregate([
      { $match: { status: 'refunded', createdAt: { $gte: since } } },
      { $group: { _id: null, total: { $sum: '$price' }, count: { $sum: 1 } } }
    ])
  ]);

  const s = orderStats[0] || { revenue: 0, orders: 0, avgPrice: 0, totalItemValue: 0 };
  const r = refundStats[0] || { total: 0, count: 0 };

  // تقدير التكاليف
  const estPaymentFees   = +(s.revenue * COST_CONSTANTS.paymentFeePercent + s.orders * COST_CONSTANTS.paymentFeeFlat).toFixed(2);
  const estShipping      = +(s.orders * COST_CONSTANTS.shippingAvg).toFixed(2);
  const estCustomerSvc   = +(s.revenue * COST_CONSTANTS.customerServiceRate).toFixed(2);
  const estServerCost    = +(s.orders / 1000 * COST_CONSTANTS.serverCostPer1000).toFixed(2);
  const refundLoss       = +r.total.toFixed(2);
  const totalEstCost     = +(s.totalItemValue + estPaymentFees + estShipping + estCustomerSvc + estServerCost + refundLoss).toFixed(2);
  const netProfit        = +(s.revenue - totalEstCost).toFixed(2);
  const netMargin        = s.revenue > 0 ? +(netProfit / s.revenue * 100).toFixed(2) : 0;
  const refundRate       = s.orders > 0 ? +(r.count / s.orders * 100).toFixed(2) : 0;

  return {
    period:  `${days} يوم`,
    revenue: {
      total:      +s.revenue.toFixed(2),
      orders:     s.orders,
      avgPerOrder:+s.avgPrice.toFixed(2),
      daily:      +(s.revenue / days).toFixed(2)
    },
    costs: {
      supplierItems:  +s.totalItemValue.toFixed(2),
      paymentFees:    estPaymentFees,
      shipping:       estShipping,
      customerService:estCustomerSvc,
      server:         estServerCost,
      refunds:        refundLoss,
      total:          totalEstCost
    },
    profit: {
      gross:     +(s.revenue - s.totalItemValue).toFixed(2),
      net:       netProfit,
      margin:    netMargin,
      daily:     +(netProfit / days).toFixed(2),
      monthly:   +(netProfit / days * 30).toFixed(2)
    },
    risks: {
      refundRate:    `${refundRate}%`,
      refundTarget:  '< 7%',
      refundStatus:  refundRate < 7 ? '✅ جيد' : '⚠️ مرتفع — راجع المنتجات',
      marginStatus:  netMargin >= 15 ? '✅ صحي' : netMargin >= 8 ? '⚠️ مقبول' : '❌ منخفض'
    },
    topBoxes: boxStats
  };
}

// ── توقعات الأرباح ────────────────────────────────────────────────────────
function projectRevenue(scenarios) {
  /*
   * scenarios = [
   *   { label: 'محافظ',    dailyOrders: 50,  avgBoxPrice: 6 },
   *   { label: 'متوسط',    dailyOrders: 200, avgBoxPrice: 6.5 },
   *   { label: 'متفائل',   dailyOrders: 500, avgBoxPrice: 7 },
   * ]
   */
  return scenarios.map(s => {
    const monthlyRevenue = s.dailyOrders * s.avgBoxPrice * 30;
    const estCostPerOrder = s.avgBoxPrice * 0.72; // متوسط 72% تكاليف
    const monthlyProfit   = +(monthlyRevenue - s.dailyOrders * estCostPerOrder * 30).toFixed(2);
    const margin          = +(monthlyProfit / monthlyRevenue * 100).toFixed(2);
    return {
      label:           s.label,
      dailyOrders:     s.dailyOrders,
      avgBoxPrice:     s.avgBoxPrice,
      monthlyRevenue:  +monthlyRevenue.toFixed(2),
      monthlyProfit,
      margin:          `${margin}%`,
      breakEvenDays:   Math.ceil(500 / (monthlyProfit / 30)) // 500$ تكاليف ثابتة شهرياً
    };
  });
}

// ── النموذج المالي القياسي للصناديق الخمسة ───────────────────────────────
const BOX_FINANCIAL_MODELS = [
  {
    name:   'Trial Surprise Box',
    price:  1.00,
    isDigital: true,
    avgSupplierCost: 0.05,
    shippingCost:    0.00,
    note:   'أداة تسويق — هامش 55% مقبول لأنه يجلب عميلاً متكرراً'
  },
  {
    name:   'Study & Creativity Box',
    price:  5.49,
    avgSupplierCost: 2.00,
    shippingCost:    0.85,
    note:   'منتجات قرطاسية خفيفة — هامش جيد ومخاطر إرجاع منخفضة'
  },
  {
    name:   'Home Essentials Box',
    price:  5.99,
    avgSupplierCost: 2.10,
    shippingCost:    0.90,
    note:   'أدوات منزلية متينة — رضا عالٍ وإرجاع منخفض'
  },
  {
    name:   'Daily Tech Box',
    price:  6.99,
    avgSupplierCost: 2.50,
    shippingCost:    0.95,
    note:   'إلكترونيات خفيفة — هامش معقول، راقب refundRiskScore'
  },
  {
    name:   'Fashion Surprise Box',
    price:  6.49,
    avgSupplierCost: 2.30,
    shippingCost:    0.90,
    note:   'ملابس وإكسسوارات — خطر إرجاع بسبب المقاسات، اختر منتجات free-size'
  },
  {
    name:   'Mystery Mix Box',
    price:  6.99,
    avgSupplierCost: 2.60,
    shippingCost:    0.95,
    note:   'أعلى جاذبية وأعلى مخاطر — راقب باستمرار'
  }
].map(b => ({
  ...b,
  analysis: analyzeBoxCost(b.price, b.avgSupplierCost, b.shippingCost, b.isDigital)
}));

module.exports = {
  analyzeBoxCost,
  getPlatformFinancials,
  projectRevenue,
  BOX_FINANCIAL_MODELS,
  COST_CONSTANTS
};
