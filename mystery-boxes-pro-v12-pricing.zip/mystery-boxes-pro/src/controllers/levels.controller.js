/**
 * levels.controller.js
 *
 * User progression system:
 *   - XP earned on every box open (scales with price)
 *   - Level up: level * 100 XP per threshold
 *   - loyaltyDiscount: خصم ولاء 0.5% كل 10 مستويات (بحد أقصى 5%) على سعر الصندوق
 *   - Milestone coupons auto-created at levels 5, 10, 20, 30, 50
 *   - Leaderboard by level + XP
 */

const User   = require('../models/User');
const Coupon = require('../models/Coupon');

function xpForOpen(boxPrice) {
  if (boxPrice >= 5)  return 15;
  if (boxPrice >= 2)  return 8;
  return 5;
}

const MILESTONES = {
  5:  { type: 'percent',  value: 10, label: '🎁 10% off — Level 5 reward' },
  10: { type: 'percent',  value: 15, label: '🎁 15% off — Level 10 reward' },
  20: { type: 'percent',  value: 20, label: '🎁 20% off — Level 20 reward' },
  30: { type: 'percent',  value: 25, label: '🎁 25% off — Level 30 reward' },
  50: { type: 'free_open', value: 0, label: '🎉 Free Box — Level 50 reward' }
};

async function awardXP(userId, boxPrice) {
  const user = await User.findById(userId);
  if (!user) return null;

  const prevLevel = user.level;
  user.addXP(xpForOpen(boxPrice));
  const levelsGained = user.level - prevLevel;
  let milestoneReward = null;

  if (levelsGained > 0 && MILESTONES[user.level]) {
    const m    = MILESTONES[user.level];
    const code = `LVL${user.level}-${user._id.toString().slice(-6).toUpperCase()}`;
    try {
      await Coupon.create({
        code, type: m.type, value: m.value, maxUses: 1,
        description: m.label,
        validUntil: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
        createdBy: userId
      });
      milestoneReward = { level: user.level, couponCode: code, label: m.label };
    } catch { /* ignore duplicate */ }
  }

  await user.save({ validateBeforeSave: false });
  return {
    xpEarned: xpForOpen(boxPrice),
    levelsGained,
    newLevel: user.level,
    xp: user.xp,
    xpForNext: user.xpForNextLevel(),
    milestoneReward
  };
}

// GET /api/v1/levels/me
exports.getMyLevel = async (req, res) => {
  try {
    const user = await User.findById(req.user.id)
      .select('level xp username avatar totalBoxesOpened tier');
    res.json({
      success: true,
      level:     user.level,
      xp:        user.xp,
      xpForNext: user.xpForNextLevel(),
      loyaltyDiscount: `${((user.loyaltyDiscount ?? 0) * 100).toFixed(1)}%`,
      username:  user.username,
      tier:      user.tier,
      opens:     user.totalBoxesOpened,
      nextMilestone: Object.keys(MILESTONES).map(Number).find(l => l > user.level) || null
    });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// GET /api/v1/levels/leaderboard
exports.getLeaderboard = async (req, res) => {
  try {
    const { by = 'level', limit = 20 } = req.query;
    const sort = by === 'opens' ? { totalBoxesOpened: -1 } : { level: -1, xp: -1 };
    const users = await User.find({ role: 'user', isBanned: false })
      .select('username avatar level xp totalBoxesOpened tier')
      .sort(sort).limit(parseInt(limit));

    res.json({
      success: true,
      leaderboard: users.map((u, i) => ({
        rank:      i + 1,
        username:  u.username,
        level:     u.level,
        xp:        u.xp,
        opens:     u.totalBoxesOpened,
        tier:      u.tier,
        loyaltyDiscount: `${(Math.min(Math.floor((u.level-1)/10)*0.005, 0.05)*100).toFixed(1)}%`
      }))
    });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.awardXP = awardXP;
