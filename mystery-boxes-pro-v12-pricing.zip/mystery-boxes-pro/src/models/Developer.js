const mongoose = require('mongoose');
const bcrypt   = require('bcryptjs');
const crypto   = require('crypto');

const developerSchema = new mongoose.Schema({
  name:  { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  passwordHash: { type: String, required: true, select: false },
  companyName:  { type: String, trim: true },
  website:      { type: String, trim: true },

  // API access
  apiKey:    { type: String, unique: true, select: false },
  apiSecret: { type: String, select: false },      // used for HMAC signing

  // Commission config
  commissionType:  { type: String, enum: ['percentage', 'fixed'], default: 'percentage' },
  commissionValue: { type: Number, default: 10, min: 0, max: 50 }, // 10% default

  // Financials
  balance:        { type: Number, default: 0, min: 0 },
  totalEarnings:  { type: Number, default: 0 },
  pendingPayout:  { type: Number, default: 0 },
  minPayout:      { type: Number, default: 50 },   // $50 minimum withdrawal

  // Integration
  webhookUrl:     { type: String, trim: true },
  webhookSecret:  { type: String, select: false },
  allowedIPs:     [{ type: String }],              // IP whitelist (empty = all allowed)

  // Status & approval
  status: {
    type: String,
    enum: ['pending', 'active', 'suspended', 'rejected'],
    default: 'pending'  // manual approval by admin required
  },
  approvedAt:  { type: Date },
  approvedBy:  { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  rejectedReason: { type: String },

  // Stats (denormalized for quick dashboard queries)
  totalBoxOpens:  { type: Number, default: 0 },
  totalRevenue:   { type: Number, default: 0 },
  lastActivityAt: { type: Date },

  // Rate limiting (per developer)
  rateLimitPerMin:   { type: Number, default: 60 },
  rateLimitPerHour:  { type: Number, default: 1000 },

  notes: { type: String }  // admin notes
}, { timestamps: true });

// ── Pre-save: hash password ────────────────────────────────────────────────
developerSchema.pre('save', async function (next) {
  if (this.isModified('passwordHash')) {
    this.passwordHash = await bcrypt.hash(this.passwordHash, 12);
  }
  next();
});

// ── Generate API key pair ──────────────────────────────────────────────────
developerSchema.methods.generateApiCredentials = function () {
  this.apiKey    = 'mbp_' + crypto.randomBytes(24).toString('hex');
  this.apiSecret = 'sec_' + crypto.randomBytes(32).toString('hex');
  this.webhookSecret = 'whk_' + crypto.randomBytes(20).toString('hex');
  return { apiKey: this.apiKey, apiSecret: this.apiSecret };
};

// ── Verify password ────────────────────────────────────────────────────────
developerSchema.methods.comparePassword = async function (password) {
  return bcrypt.compare(password, this.passwordHash);
};

// ── Regenerate API key ─────────────────────────────────────────────────────
developerSchema.methods.rotateApiKey = function () {
  this.apiKey    = 'mbp_' + crypto.randomBytes(24).toString('hex');
  this.apiSecret = 'sec_' + crypto.randomBytes(32).toString('hex');
  return { apiKey: this.apiKey, apiSecret: this.apiSecret };
};

// ── Credit commission ──────────────────────────────────────────────────────
developerSchema.methods.addCommission = function (amount) {
  this.balance       += amount;
  this.totalEarnings += amount;
  this.pendingPayout += amount;
};

module.exports = mongoose.model('Developer', developerSchema);
