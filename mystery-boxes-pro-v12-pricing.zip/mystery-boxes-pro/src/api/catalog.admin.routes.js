const express = require('express');
const router  = express.Router();
const c       = require('./catalog.admin.controller');
const { protect, authorize } = require('../middleware/auth.middleware');
const AdminCatalogKey = require('../models/AdminCatalogKey');

// ── middleware: يقبل JWT Admin أو API Key ck_xxx ────────────────────────────
const authCatalog = async (req, res, next) => {
  const auth = req.headers.authorization || '';
  
  // API Key
  if (auth.startsWith('Bearer ck_')) {
    const key = await AdminCatalogKey.verify(auth.replace('Bearer ', '').trim());
    if (!key) return res.status(401).json({ success: false, message: 'API key غير صالح' });
    req.user = { id: key.createdBy, role: 'admin' };
    return next();
  }
  
  // JWT عادي
  return protect(req, res, () => authorize('admin')(req, res, next));
};

router.use(authCatalog);

// مفتاح API
router.post('/generate-key',     c.generateKey);
router.get ('/key-info',         c.getKeyInfo);

// المنتجات
router.post  ('/items/bulk',     c.bulkImport);
router.post  ('/items',          c.createItem);
router.get   ('/items',          c.getItems);
router.put   ('/items/:id',      c.updateItem);
router.delete('/items/:id',      c.deleteItem);

// اختبار
router.post('/test-sample',      c.testSample);
router.post('/validate-filter',  c.validateBoxFilter);
router.get ('/stats',            c.getCatalogStats);

module.exports = router;
