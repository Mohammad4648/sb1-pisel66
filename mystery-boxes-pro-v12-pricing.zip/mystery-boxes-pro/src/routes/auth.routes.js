const express = require('express');
const router  = express.Router();
const auth    = require('../controllers/auth.controller');
const { protect } = require('../middleware/auth.middleware');
const { registerValidation, loginValidation } = require('../middleware/validation.middleware');
const { limitAuth }          = require('../middleware/rateLimiter.middleware');
const { blockMultiAccount, attachDeviceInfo } = require('../security/anti.fraud');

router.post('/register', limitAuth, blockMultiAccount(3), attachDeviceInfo, registerValidation, auth.register);
router.post('/login',    limitAuth, attachDeviceInfo, loginValidation, auth.login);
router.get('/me',        protect, auth.getMe);
router.put('/profile',   protect, auth.updateProfile);
router.put('/change-password', protect, auth.changePassword);

module.exports = router;
