
// ══════════════════════════════════════════════════════════════════════════════
// GET /boxes/trial/eligibility — هل المستخدم مؤهل للصندوق التجريبي؟
// ══════════════════════════════════════════════════════════════════════════════
exports.getTrialEligibility = async (req, res) => {
  try {
    const user     = await User.findById(req.user.id).select('trialBoxOpened walletBalance');
    const trialBox = await Box.findOne({ isTrial: true, isActive: true })
      .select('name price description transparency items')
      .populate('items', 'name marketValue productCategory');

    res.json({
      success:   true,
      eligible:  !user.trialBoxOpened,
      used:       user.trialBoxOpened,
      message:   user.trialBoxOpened
        ? 'استخدمت الصندوق التجريبي مسبقاً'
        : 'مؤهل للصندوق التجريبي 🎯',
      trialBox: trialBox ? {
        id:          trialBox._id,
        name:        trialBox.name,
        price:       trialBox.price,
        description: trialBox.description,
        products:    trialBox.items.map(i => ({
          name:     i.name,
          value:    i.marketValue,
          category: i.productCategory
        })),
        transparency: trialBox.transparency
      } : null
    });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

/**
 * box.controller.js — v3 (Retail Random Model)
 *
 * التغييرات الجوهرية:
 *   - حذف كلياً: نظام الندرة (rarity, legendary, epic, common)
 *   - حذف كلياً: pity system (ضمان legendary)
 *   - حذف كلياً: dailyWinCap (حد ربح يومي)
 *   - حذف كلياً: minOpenRequirement
 *   - حذف كلياً: pickRarityFromFloat
 *
 *   - بديل: Bucket-weighted pick — يختار من A/B/C حسب توزيع الصندوق
 *   - بديل: Smart weight — refundRiskScore يُقلل وزن المنتجات المشكلة
 *   - إضافة: Bonus item — منتج إضافي صغير دائماً من Bucket A
 *   - إضافة: transparency في كل response
 *
 * المبدأ: كل منتج قيمته بين 80%–130% من سعر الصندوق. لا تفاوت كبير. لا حظ.
 */

const Box         = require('../models/Box');
const Item        = require('../models/Item');
const Order       = require('../models/Order');
const Transaction = require('../models/Transaction');
const User        = require('../models/User');
const Inventory   = require('../models/Inventory');
const Coupon      = require('../models/Coupon');
const ProofRecord = require('../models/ProofRecord');

const { withTransaction }   = require('../config/db.transaction');
const { securePickFrom, secureRandomInt, weightedRandom } = require('../utils/secure.rng');
const { generateServerSeed, generateFloat, pickItemFromFloat, verifyResult }
                             = require('../security/fair.random');
const { validateBoxHalal }           = require('../services/halal.service');
const { sampleItem }                  = require('../services/catalog.sampler');
const { SADAQA, LANG }                = require('../config/islamic.config');
const { validateBoxPricing, computeTransparency, checkStopLoss, getBoxROI }
                             = require('../services/roi.engine');
const {
  processReferralCommission, checkMilestones  // processCashback + getCashbackRate: محذوفان
}                            = require('../services/referral.service');
const notify                 = require('../services/notify.service');
const { recordEvent }        = require('../services/mission.service');
const { pushPurchaseEvent }  = require('../services/activity.service');
const cache                  = require('../services/cache.service');
const { jobs }               = require('../queue/queue.manager');
const logger                 = require('../utils/logger');

// ══════════════════════════════════════════════════════════════════════════════
// اختيار المنتج — Bucket-weighted
// ══════════════════════════════════════════════════════════════════════════════

/**
 * اختيار المنتج الرئيسي — ثلاث طبقات وزن:
 *  1. وزن الـBucket (من إعدادات الصندوق): A=50 B=35 C=15
 *  2. وزن المنتج الفردي (selectionWeight): يتأثر بـrefundRiskScore
 *  3. Diversity boost: يرفع وزن المنتجات التي لم تُختر مؤخراً
 */
function pickMainItem(items, bucketDistribution, recentlyPicked = []) {
  const { A = 50, B = 35, C = 15 } = bucketDistribution;
  const bucketWeights = { A, B, C };

  const pool = items.filter(i => !i.isBonus && i.isActive !== false);
  if (pool.length === 0) return null;

  const weighted = pool.map(item => {
    const bucketW   = bucketWeights[item.bucket] || 10;
    const itemW     = item.selectionWeight ?? 100;
    const recentIdx = recentlyPicked.indexOf(item._id?.toString());
    const diversityW = recentIdx === -1 ? 1.2 : Math.max(0.5, 1 - recentIdx * 0.1);
    const finalWeight = (bucketW / 100) * (itemW / 100) * diversityW;
    return { value: item, weight: Math.max(0.01, finalWeight) };
  });

  return weightedRandom(weighted);
}

/**
 * اختيار المنتج الإضافي — دائماً Bonus items، أوزان متساوية
 */
function pickBonusItem(items) {
  const pool = items.filter(i => i.isBonus && i.isActive !== false);
  if (pool.length === 0) return null;
  const weighted = pool.map(item => ({ value: item, weight: item.selectionWeight ?? 100 }));
  return weightedRandom(weighted);
}

// ══════════════════════════════════════════════════════════════════════════════
// GET /boxes — قائمة الصناديق
// ══════════════════════════════════════════════════════════════════════════════
exports.getBoxes = async (req, res) => {
  try {
    const { category, boxType, featured, page = 1, limit = 12 } = req.query;
    const cacheKey = `boxes:list:${category}:${boxType}:${featured}:${page}:${limit}`;

    const result = await cache.wrap(cacheKey, async () => {
      const query = { isActive: true };
      if (category) query.category = category;
      if (boxType)  query.boxType  = boxType;
      if (featured === 'true') query.isFeatured = true;

      const skip = (Number(page) - 1) * Number(limit);
      const [boxes, total] = await Promise.all([
        Box.find(query)
          .populate('items', 'name marketValue image type productCategory isBonus bucket')
          .populate('provider', 'name type')
          .sort({ isFeatured: -1, createdAt: -1 })
          .skip(skip).limit(Number(limit)),
        Box.countDocuments(query)
      ]);
      return { boxes, total };
    }, 120);

    res.json({
      success: true,
      count: result.boxes.length,
      total: result.total,
      pages: Math.ceil(result.total / Number(limit)),
      boxes: result.boxes
    });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ══════════════════════════════════════════════════════════════════════════════
// GET /boxes/:id — تفاصيل صندوق مع الشفافية الكاملة
// ══════════════════════════════════════════════════════════════════════════════
exports.getBox = async (req, res) => {
  try {
    const box = await cache.wrap(`boxes:single:${req.params.id}`, () =>
      Box.findById(req.params.id)
        .populate('items', 'name marketValue image type productCategory description isBonus bucket')
        .populate('provider', 'name type'), 300);

    if (!box || !box.isActive) {
      return res.status(404).json({ success: false, message: 'الصندوق غير موجود' });
    }

    // قائمة المنتجات الكاملة — ظاهرة للمستخدم قبل الشراء
    const mainItems  = box.items.filter(i => !i.isBonus);
    const bonusItems = box.items.filter(i =>  i.isBonus);

    res.json({
      success: true,
      box: {
        ...box.toJSON(),
        // هذا هو الفرق عن الكازينو: كل المنتجات ظاهرة مسبقاً
        products: mainItems.map(i => ({
          name:            i.name,
          image:           i.image,
          marketValue:     i.marketValue,
          type:            i.type,
          productCategory: i.productCategory,
          description:     i.description
        })),
        bonusProducts: bonusItems.map(i => ({
          name:  i.name,
          image: i.image,
          type:  i.type
        }))
      }
    });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ══════════════════════════════════════════════════════════════════════════════
// POST /boxes/:id/open — فتح صندوق
// ══════════════════════════════════════════════════════════════════════════════
exports.openBox = async (req, res) => {
  try {
    const { shippingAddress, couponCode, clientSeed } = req.body;

    const box = await Box.findById(req.params.id).populate('items');
    if (!box || !box.isAvailable) {
      return res.status(404).json({ success: false, message: 'الصندوق غير متاح حالياً' });
    }

    if (box.boxType === 'physical' && !shippingAddress) {
      return res.status(400).json({ success: false, message: 'عنوان الشحن مطلوب' });
    }

    const user = await User.findById(req.user.id);

    // ── التحقق من صندوق Trial — مرة واحدة فقط لكل حساب ──────────────────
    if (box.isTrial) {
      if (user.trialBoxOpened) {
        return res.status(403).json({
          success: false,
          message: 'سبق أن استخدمت الصندوق التجريبي — متاح مرة واحدة فقط لكل حساب'
        });
      }
    }

    // ── التحقق من maxPerUser (غير Trial) ─────────────────────────────────
    if (!box.isTrial && box.maxPerUser !== -1) {
      const Order = require('../models/Order');
      const userOpens = await Order.countDocuments({
        user: user._id, box: box._id, status: 'completed'
      });
      if (userOpens >= box.maxPerUser) {
        return res.status(403).json({
          success: false,
          message: `هذا الصندوق متاح ${box.maxPerUser} مرة فقط لكل حساب`
        });
      }
    }

    // ── كوبون — atomic claim ──────────────────────────────────────────────
    // ── خصم الولاء — مُطبَّق على السعر مباشرة (ليس كاشباك لاحق) ─────────
    const loyaltyRate  = user.loyaltyDiscount ?? 0;
    let finalPrice     = loyaltyRate > 0
      ? +(box.finalPrice * (1 - loyaltyRate)).toFixed(2)
      : box.finalPrice;
    let loyaltyApplied = loyaltyRate > 0 ? +(box.finalPrice - finalPrice).toFixed(2) : 0;
    let couponUsed = null;

    if (couponCode) {
      const now = new Date();
      const claimedCoupon = await Coupon.findOneAndUpdate(
        {
          code: couponCode.toUpperCase(), isActive: true,
          validFrom: { $lte: now },
          $or: [{ validUntil: null }, { validUntil: { $gt: now } }],
          usedBy: { $ne: user._id },
          $expr: { $or: [{ $eq: ['$maxUses', -1] }, { $lt: ['$usedCount', '$maxUses'] }] }
        },
        { $inc: { usedCount: 1 }, $push: { usedBy: user._id } },
        { new: true }
      );
      if (claimedCoupon) {
        finalPrice = +claimedCoupon.applyDiscount(finalPrice).toFixed(2);
        couponUsed = { code: claimedCoupon.code, savings: +(box.finalPrice - finalPrice).toFixed(2) };
      }
    }

    if (user.walletBalance < finalPrice) {
      if (couponUsed) {
        await Coupon.findOneAndUpdate(
          { code: couponUsed.code },
          { $inc: { usedCount: -1 }, $pull: { usedBy: user._id } }
        );
      }
      return res.status(400).json({ success: false, message: `رصيد غير كافٍ. رصيدك: $${user.walletBalance.toFixed(2)}` });
    }

    // ── اختيار المنتج ─────────────────────────────────────────────────────
    const { serverSeed, serverSeedHash } = generateServerSeed();
    const usedClientSeed = clientSeed || require('../utils/secure.rng').secureToken(16);
    const nonce      = user.totalBoxesOpened + 1;
    const fairFloat  = generateFloat(serverSeed, usedClientSeed, nonce);

    const mainItem   = pickMainItem(box.items, box.bucketDistribution);
    const bonusItem  = box.hasBonus ? pickBonusItem(box.items) : null;

    if (!mainItem) {
      return res.status(500).json({ success: false, message: 'لا توجد منتجات في الصندوق' });
    }

    // ── TRANSACTION ───────────────────────────────────────────────────────
    let order, inventoryEntry, bonusInventory;

    await withTransaction(async (session) => {

      // 1. خصم الرصيد
      const freshUser = await User.findById(user._id).session(session);
      if (freshUser.walletBalance < finalPrice) throw new Error('رصيد غير كافٍ');

      const balanceBefore = freshUser.walletBalance;

      // ── الصدقة الاختيارية (تقريب تلقائي) ──────────────────────────────
      let sadaqaAmount = 0;
      if (SADAQA.enabled && freshUser.sadaqaEnabled) {
        const rounded    = Math.ceil(finalPrice / SADAQA.rounding) * SADAQA.rounding;
        sadaqaAmount     = +(rounded - finalPrice).toFixed(4);
        if (sadaqaAmount > 0 && freshUser.walletBalance >= finalPrice + sadaqaAmount) {
          freshUser.totalSadaqa = (freshUser.totalSadaqa || 0) + sadaqaAmount;
        } else {
          sadaqaAmount = 0; // رصيد غير كافٍ للصدقة
        }
      }

      const totalDeduct = finalPrice + sadaqaAmount;
      freshUser.walletBalance    -= totalDeduct;
      freshUser.totalSpent       += finalPrice;
      freshUser.totalBoxesOpened += 1;
      await freshUser.save({ session });

      // تسجيل الصدقة كمعاملة منفصلة
      if (sadaqaAmount > 0) {
        await Transaction.create([{
          user: user._id, type: 'bonus', amount: -sadaqaAmount,
          balanceBefore: balanceBefore - finalPrice,
          balanceAfter:  balanceBefore - finalPrice - sadaqaAmount,
          description: LANG.sadaqaMsg(sadaqaAmount),
          status: 'completed', method: 'sadaqa'
        }], { session });
      }

      // 2. الطلب
      [order] = await Order.create([{
        user: user._id, box: box._id, boxName: box.name,
        price: finalPrice,
        itemsReceived: [
          { item: mainItem._id, name: mainItem.name, value: mainItem.marketValue, image: mainItem.image },
          ...(bonusItem ? [{ item: bonusItem._id, name: bonusItem.name, value: bonusItem.marketValue, image: bonusItem.image }] : [])
        ],
        totalValue:  mainItem.marketValue + (bonusItem?.marketValue || 0),
        status:      'completed',
        completedAt: new Date(),
        paymentMethod: 'wallet'
      }], { session });

      // 3. سجل المعاملة
      await Transaction.create([{
        user: user._id, type: 'purchase', amount: -finalPrice,
        balanceBefore, balanceAfter: freshUser.walletBalance,
        description: `فتح صندوق: ${box.name}`, relatedOrder: order._id, status: 'completed'
      }], { session });

      // 4. المخزون — المنتج الرئيسي
      [inventoryEntry] = await Inventory.create([{
        user: user._id, item: mainItem._id, order: order._id,
        itemName: mainItem.name, itemValue: mainItem.marketValue, itemImage: mainItem.image,
        status: 'pending'
      }], { session });

      // 5. المخزون — المنتج الإضافي
      if (bonusItem) {
        [bonusInventory] = await Inventory.create([{
          user: user._id, item: bonusItem._id, order: order._id,
          itemName: bonusItem.name, itemValue: bonusItem.marketValue, itemImage: bonusItem.image,
          status: 'pending'
        }], { session });
      }

      // 6. سجل التحقق من العشوائية (للشفافية)
      await ProofRecord.create([{
        user: user._id, order: order._id, box: box._id,
        serverSeedHash, serverSeed, clientSeed: usedClientSeed, nonce,
        fairFloat:  fairFloat.toFixed(10),
        itemName:   mainItem.name,
        itemRarity: mainItem.bucket // نحفظ الـbucket بدل rarity
      }], { session });

      // 7. إحصائيات الصندوق
      await Box.findByIdAndUpdate(box._id, {
        $inc: { soldCount: 1, openingsCount: 1, totalRevenue: finalPrice }
      }, { session });

      // 7b. Trial: علّم المستخدم أنه استخدم الصندوق التجريبي
      if (box.isTrial) {
        await User.findByIdAndUpdate(user._id, { $set: { trialBoxOpened: true } }, { session });
      }

      // 8. إحصائيات المنتج
      await Item.findByIdAndUpdate(mainItem._id, { $inc: { droppedCount: 1 } }, { session });

      // 9. عمولة الإحالة
      if (freshUser.referredBy) {
        await processReferralCommission(freshUser, finalPrice, order._id, session);
      }

      // 10. كاشباك: محذوف — الخصم يُطبَّق على السعر مباشرة (أعلاه)
    });

    // ── Post-transaction ───────────────────────────────────────────────────
    cache.delPattern('boxes:');

    if (user.referredBy) checkMilestones(user.referredBy).catch(() => {});

    notify.itemWon(user, { name: mainItem.name, value: mainItem.marketValue }, box.name).catch(() => {});

    recordEvent(user._id, 'open_boxes',   1).catch(() => {});
    recordEvent(user._id, 'spend_amount', finalPrice).catch(() => {});

    if (box.provider) {
      jobs.fulfillItem({
        providerId:  box.provider.toString(),
        item:        mainItem.toObject?.() || mainItem,
        userId:      user._id.toString(),
        shippingAddress,
        inventoryId: inventoryEntry._id.toString()
      }).catch(err => logger.error('Queue error:', err.message));
    }

    jobs.stopLossCheck(box._id.toString()).catch(() => {});

    pushPurchaseEvent({
      username:   user.username,
      itemName:   mainItem.name,
      itemValue:  mainItem.marketValue,
      boxName:    box.name,
      userId:     user._id.toString()
    }).catch(() => {});

    jobs.sendEmail({ type: 'sendBoxOpened', user, item: { name: mainItem.name, value: mainItem.marketValue }, boxName: box.name })
      .catch(() => {});

    res.json({
      success: true,
      message: 'الحمد لله — وصلك منتجك',  // لا رسالة تشجيعية إدمانية
      order: {
        id:         order._id,
        boxName:    box.name,
        price:      finalPrice,
        couponUsed,
        loyaltyDiscount: loyaltyApplied > 0 ? { amount: loyaltyApplied, rate: `${(loyaltyRate*100).toFixed(1)}%` } : null,
        // المنتج الرئيسي
        item: {
          name:        mainItem.name,
          value:       mainItem.marketValue,
          image:       mainItem.image,
          type:        mainItem.type,
          category:    mainItem.productCategory,
          inventoryId: inventoryEntry._id
        },
        // المنتج الإضافي (إن وُجد)
        bonusItem: bonusItem ? {
          name:        bonusItem.name,
          value:       bonusItem.marketValue,
          image:       bonusItem.image,
          inventoryId: bonusInventory?._id
        } : null,
        // شفافية: يمكن للمستخدم التحقق من عشوائية الاختيار
        randomnessProof: {
          serverSeedHash, // مُعلن قبل الفتح
          clientSeed:      usedClientSeed,
          nonce,
          note: 'بعد الفتح يمكنك رؤية serverSeed والتحقق عبر /boxes/verify/:orderId'
        },
        loyaltyDiscount: `${(user.loyaltyDiscount * 100).toFixed(1)}%`,
        note: 'خصم الولاء يُطبَّق على سعر الصندوق في الطلب التالي'
      },
      newBalance: +(user.walletBalance - finalPrice).toFixed(4)
    });
  } catch (e) {
    logger.error('openBox error:', e.message);
    res.status(500).json({ success: false, message: e.message });
  }
};

// ══════════════════════════════════════════════════════════════════════════════
// GET /boxes/:orderId/verify — التحقق من عشوائية الاختيار
// ══════════════════════════════════════════════════════════════════════════════
exports.verifyOpen = async (req, res) => {
  try {
    const proof = await ProofRecord.findOne({ order: req.params.orderId, user: req.user.id })
      .select('+serverSeed');
    if (!proof) return res.status(404).json({ success: false, message: 'السجل غير موجود' });

    const verification = verifyResult({
      serverSeed:     proof.serverSeed,
      serverSeedHash: proof.serverSeedHash,
      clientSeed:     proof.clientSeed,
      nonce:          proof.nonce,
      fairFloat:      proof.fairFloat
    });

    if (!proof.revealed) {
      proof.revealed   = true;
      proof.revealedAt = new Date();
      await proof.save();
    }

    res.json({
      success: true,
      message: verification.verified
        ? '✅ الاختيار العشوائي موثق وصحيح'
        : '⚠️ تعذّر التحقق — راسل الدعم',
      proof: {
        serverSeedHash: proof.serverSeedHash,
        serverSeed:     proof.serverSeed,
        clientSeed:     proof.clientSeed,
        nonce:          proof.nonce,
        fairFloat:      proof.fairFloat,
        item:           proof.itemName
      },
      verification,
      howToVerify: `HMAC-SHA256(serverSeed, "${proof.clientSeed}:${proof.nonce}") → float = ${proof.fairFloat}`
    });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ══════════════════════════════════════════════════════════════════════════════
// [Admin] إنشاء صندوق
// ══════════════════════════════════════════════════════════════════════════════
exports.createBox = async (req, res) => {
  try {
    const { price, items: itemIds, profitMargin = 0.20 } = req.body;

    if (itemIds?.length > 0) {
      const itemDocs = await Item.find({ _id: { $in: itemIds } })
        .select('marketValue supplierCost estimatedShipping bucket isBonus name productCategory type description');

      // ── فحص الامتثال الشرعي ───────────────────────────────────────────
      const halalCheck = validateBoxHalal({ price, transparency: req.body.transparency }, itemDocs);
      if (!halalCheck.halal) {
        return res.status(400).json({
          success: false,
          message: `الصندوق لا يطابق الضوابط الشرعية`,
          issues:   halalCheck.issues,
          grade:    halalCheck.grade
        });
      }

      const check = validateBoxPricing(price, itemDocs, profitMargin);

      if (!check.valid) {
        return res.status(400).json({
          success: false,
          message: check.reason,
          pricing: check
        });
      }

      // احسب transparency وخزّنها
      req.body.transparency = computeTransparency(price, itemDocs);
    }

    req.body.createdBy = req.user.id;
    const box = await Box.create(req.body);
    cache.delPattern('boxes:');
    res.status(201).json({ success: true, box });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.updateBox = async (req, res) => {
  try {
    // إعادة حساب transparency عند التعديل
    if (req.body.items) {
      const itemDocs = await Item.find({ _id: { $in: req.body.items } })
        .select('marketValue supplierCost estimatedShipping bucket isBonus name');
      const box = await Box.findById(req.params.id);
      if (box) req.body.transparency = computeTransparency(req.body.price || box.price, itemDocs);
    }

    const box = await Box.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!box) return res.status(404).json({ success: false, message: 'الصندوق غير موجود' });
    cache.delPattern('boxes:');
    res.json({ success: true, box });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.deleteBox = async (req, res) => {
  try {
    await Box.findByIdAndUpdate(req.params.id, { isActive: false });
    cache.delPattern('boxes:');
    res.json({ success: true, message: 'تم إيقاف الصندوق' });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// [Admin] معاينة التسعير قبل الإنشاء
exports.previewPricing = async (req, res) => {
  try {
    const { price, itemIds, profitMargin = 0.20 } = req.body;
    const items  = await Item.find({ _id: { $in: itemIds } })
      .select('name marketValue supplierCost estimatedShipping bucket isBonus');
    const result = validateBoxPricing(price, items, profitMargin);
    const transparency = computeTransparency(price, items);
    res.json({ success: true, pricing: result, transparency, items });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// [Admin] تقرير ROI
exports.getBoxROI = async (req, res) => {
  try {
    const roi = await getBoxROI(req.params.id, parseInt(req.query.days) || 7);
    res.json({ success: true, roi });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};
