const mongoose = require('mongoose');

const commissionSchema = new mongoose.Schema({
  developer:    { type: mongoose.Schema.Types.ObjectId, ref: 'Developer', required: true },
  order:        { type: mongoose.Schema.Types.ObjectId, ref: 'Order', required: true },

  // Source info
  sourceApp:     { type: String },          // e.g. "TelegramBot", "GameX"
  externalUserId:{ type: String },          // the user ID in the developer's system

  // Financial breakdown
  boxPrice:      { type: Number, required: true },
  platformCost:  { type: Number, required: true },  // cost of item (EV)
  platformProfit:{ type: Number, required: true },  // boxPrice - platformCost

  commissionType:  { type: String, enum: ['percentage', 'fixed'] },
  commissionRate:  { type: Number },               // rate applied
  commissionAmount:{ type: Number, required: true },// actual $ credited

  // State
  status: { type: String, enum: ['pending', 'credited', 'reversed'], default: 'pending' },
  creditedAt: { type: Date }
}, { timestamps: true });

commissionSchema.index({ developer: 1, createdAt: -1 });
commissionSchema.index({ developer: 1, status: 1 });

module.exports = mongoose.model('Commission', commissionSchema);
