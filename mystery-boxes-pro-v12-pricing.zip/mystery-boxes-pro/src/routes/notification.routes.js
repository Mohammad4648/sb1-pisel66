const express = require('express');
const router  = express.Router();
const n       = require('../controllers/notification.controller');
const { protect } = require('../middleware/auth.middleware');

router.use(protect);
router.get('/',              n.getNotifications);
router.post('/read-all',     n.markAllRead);
router.post('/:id/read',     n.markRead);
router.delete('/:id',        n.deleteNotification);
router.delete('/',           n.clearAll);

module.exports = router;
