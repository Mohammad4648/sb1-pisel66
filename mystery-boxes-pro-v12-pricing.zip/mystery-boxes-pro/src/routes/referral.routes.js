const express  = require('express');
const router   = express.Router();
const referral = require('../controllers/referral.controller');
const { protect } = require('../middleware/auth.middleware');

router.get('/leaderboard',      referral.getLeaderboard);
router.get('/validate/:code',   referral.validateCode);

router.use(protect);
router.get('/',            referral.getDashboard);
router.get('/stats',       referral.getStats);
router.get('/list',        referral.listReferrals);
router.get('/commissions', referral.getCommissions);
router.get('/milestones',  referral.getMilestones);

module.exports = router;
