const mongoose = require('mongoose');

const notificationSchema = new mongoose.Schema({
  user:    { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  type:    {
    type: String, required: true,
    enum: [
      'box_opened', 'item_won', 'commission_earned', 'milestone_reached',
      'deposit_confirmed', 'withdrawal_processed', 'gift_received', 'gift_sent',
      'mission_completed', 'level_up', 'tier_upgrade', 'stop_loss_triggered',
      'event_started', 'event_ending', 'system'
    ]
  },
  title:   { type: String, required: true },
  message: { type: String, required: true },
  icon:    { type: String, default: '🔔' },
  data:    { type: mongoose.Schema.Types.Mixed, default: {} }, // extra payload for client
  isRead:  { type: Boolean, default: false },
  readAt:  { type: Date }
}, { timestamps: true });

notificationSchema.index({ user: 1, isRead: 1, createdAt: -1 });
notificationSchema.index({ user: 1, createdAt: -1 });

// Auto-delete read notifications older than 30 days
notificationSchema.index({ createdAt: 1 }, { expireAfterSeconds: 30 * 24 * 60 * 60 });

module.exports = mongoose.model('Notification', notificationSchema);
