/**
 * jobs/index.js — Cron Suite v5
 *
 * كل  1h:  ping providers
 * كل  3h:  stop-loss على كل الصناديق
 * كل  6h:  تنظيف كوبونات منتهية
 * كل  6h:  تفعيل/إنهاء الأحداث الموسمية تلقائياً
 * كل 24h:  sync providers + تقرير يومي + إخطار انتهاء الأحداث القريب
 */

const logger = require('../utils/logger');
let started = false;

// ── Ping providers ────────────────────────────────────────────────────────
async function pingProviders() {
  const Provider = require('../models/Provider');
  const { pingProvider } = require('../services/provider.service');
  logger.info('⏰ [Job] Pinging providers...');
  const providers = await Provider.find({ isActive: true }).select('_id name');
  for (const p of providers) {
    const r = await pingProvider(p._id);
    r.alive
      ? logger.info(`  ✅ ${p.name} ${r.latencyMs}ms`)
      : logger.warn(`  ⚠️  ${p.name} UNREACHABLE: ${r.error}`);
  }
}

// ── Stop-loss ─────────────────────────────────────────────────────────────
async function runStopLossChecks() {
  const Box = require('../models/Box');
  const { checkStopLoss } = require('../services/roi.engine');
  const cache = require('../services/cache.service');
  const notify = require('../services/notify.service');
  const User   = require('../models/User');

  logger.info('⏰ [Job] Stop-loss checks...');
  const boxes = await Box.find({ isActive: true }).select('_id name price profitMargin');
  let paused = 0;
  for (const box of boxes) {
    const r = await checkStopLoss(box);
    if (r.triggered) {
      logger.warn(`  🛑 "${box.name}" paused — ROI ${r.roi}%`);
      paused++;
      // إشعار كل الأدمن
      const admins = await User.distinct('_id', { role: 'admin' });
      admins.forEach(id => notify.stopLossTriggered(id, box.name).catch(() => {}));
    }
  }
  if (paused > 0) cache.delPattern('boxes:');
  logger.info(`  Done. ${paused} box(es) paused.`);
}

// ── Clean expired coupons ─────────────────────────────────────────────────
async function cleanExpiredCoupons() {
  const Coupon = require('../models/Coupon');
  const r = await Coupon.updateMany(
    { validUntil: { $lt: new Date() }, isActive: true },
    { $set: { isActive: false } }
  );
  if (r.modifiedCount > 0) logger.info(`⏰ [Job] Expired ${r.modifiedCount} coupon(s)`);
}

// ── Seasonal events auto-activate / auto-expire ───────────────────────────
async function manageSeasonalEvents() {
  const SeasonalEvent = require('../models/SeasonalEvent');
  const User          = require('../models/User');
  const notify        = require('../services/notify.service');
  const cache         = require('../services/cache.service');
  const now = new Date();

  // تفعيل أحداث بدأت وقتها
  const toActivate = await SeasonalEvent.find({
    isActive: false, startAt: { $lte: now }, endAt: { $gt: now }
  });
  for (const ev of toActivate) {
    await SeasonalEvent.updateMany({ isActive: true }, { $set: { isActive: false } });
    ev.isActive = true;
    await ev.save();
    cache.delPattern('event:');
    logger.info(`⏰ [Job] Event auto-activated: "${ev.name}"`);

    // إشعار جماعي للمستخدمين النشطين
    const since   = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const userIds = await User.distinct('_id', { isBanned: false, lastLogin: { $gte: since } });
    notify.broadcast(userIds, 'event_started', {
      title:   `${ev.emoji} حدث خاص: ${ev.name}`,
      message: `ينتهي ${ev.endAt.toLocaleDateString('ar')} — لا تفوّت الفرصة!`,
      data:    { eventId: ev._id, boosts: ev.boosts }
    }).catch(() => {});
  }

  // إنهاء أحداث انتهت
  const toExpire = await SeasonalEvent.find({ isActive: true, endAt: { $lte: now } });
  for (const ev of toExpire) {
    ev.isActive = false;
    await ev.save();
    cache.delPattern('event:');
    logger.info(`⏰ [Job] Event expired: "${ev.name}"`);
  }

  // تحذير: حدث سينتهي خلال ساعة
  const endingSoon = await SeasonalEvent.findOne({
    isActive: true,
    endAt: { $gt: now, $lte: new Date(Date.now() + 60 * 60 * 1000) }
  });
  if (endingSoon) {
    const since   = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const userIds = await User.distinct('_id', { isBanned: false, lastLogin: { $gte: since } });
    notify.broadcast(userIds, 'event_ending', {
      title:   `⏳ ${endingSoon.name} سينتهي قريباً!`,
      message: 'أقل من ساعة — سارع قبل فوات الأوان',
      data:    { eventId: endingSoon._id }
    }).catch(() => {});
  }
}

// ── Daily report + sync ───────────────────────────────────────────────────
async function dailySyncAndReport() {
  const Order = require('../models/Order');
  const cache = require('../services/cache.service');
  const { syncAllProviders } = require('../services/sync.service');

  logger.info('⏰ [Job] Daily sync + report...');
  await syncAllProviders();

  const [revenue, topBox] = await Promise.all([
    Order.aggregate([
      { $match: { status: 'completed', createdAt: { $gte: new Date(Date.now() - 86400000) } } },
      { $group: { _id: null, revenue: { $sum: '$price' }, opens: { $sum: 1 } } }
    ]),
    Order.aggregate([
      { $match: { status: 'completed', createdAt: { $gte: new Date(Date.now() - 86400000) } } },
      { $group: { _id: '$boxName', revenue: { $sum: '$price' }, opens: { $sum: 1 } } },
      { $sort: { revenue: -1 } }, { $limit: 1 }
    ])
  ]);

  const { revenue: rev = 0, opens = 0 } = revenue[0] || {};
  logger.info(`📊 Daily — Revenue: $${rev.toFixed(2)} | Opens: ${opens} | Profit: $${(rev * 0.30).toFixed(2)} | Top: ${topBox[0]?._id || 'N/A'}`);
  cache.delPattern('analytics:');
}

// ── Start all jobs ────────────────────────────────────────────────────────
function startJobs() {
  if (started) return;
  started = true;

  setInterval(pingProviders,        1 * 60 * 60 * 1000);
  setInterval(runStopLossChecks,    3 * 60 * 60 * 1000);
  setInterval(cleanExpiredCoupons,  6 * 60 * 60 * 1000);
  setInterval(manageSeasonalEvents, 6 * 60 * 60 * 1000);
  setInterval(runSmartRotation,    6 * 60 * 60 * 1000);
  setInterval(dailySyncAndReport,  24 * 60 * 60 * 1000);

  // تشغيل فوري بعد 15 ثانية من الإقلاع
  setTimeout(async () => {
    await pingProviders().catch(() => {});
    await runStopLossChecks().catch(() => {});
    await cleanExpiredCoupons().catch(() => {});
    await manageSeasonalEvents().catch(() => {});
    await runSmartRotation().catch(() => {});
  }, 15000);

  logger.info('⏱️  Jobs: 1h ping | 3h ROI | 6h coupons+events | 24h sync');
}

module.exports = { startJobs };


// ── Smart Rotation — يُعدّل أوزان المنتجات تلقائياً ────────────────────────
// يعمل كل 6 ساعات: المنتجات ذات refundRiskScore عالٍ أو تقييم منخفض يتقلص وزنها
async function runSmartRotation() {
  const Item = require('../models/Item');
  const Order = require('../models/Order');

  logger.info('⏰ [Job] Smart Rotation...');
  const items = await Item.find({ isActive: true }).select('_id name refundRiskScore avgRating selectionWeight droppedCount');

  let updated = 0;
  for (const item of items) {
    // حساب الوزن الجديد بناءً على refundRiskScore و avgRating
    let weight = 100;

    // كل نقطة refundRisk تخصم 15%
    weight -= (item.refundRiskScore - 1) * 15;

    // إذا التقييم أقل من 3.5 وعدد التقييمات > 10 → خصم إضافي
    if (item.avgRating > 0 && item.avgRating < 3.5 && item.ratingCount > 10) {
      weight -= 20;
    }

    // إذا refundRisk = 5 → أوقف المنتج تلقائياً للمراجعة
    if (item.refundRiskScore >= 5) {
      await Item.findByIdAndUpdate(item._id, { isActive: false });
      logger.warn(`  🛑 "${item.name}" paused — refundRiskScore=${item.refundRiskScore}`);
      updated++;
      continue;
    }

    weight = Math.max(10, Math.min(100, weight)); // حدود: 10–100
    if (weight !== item.selectionWeight) {
      await Item.findByIdAndUpdate(item._id, { selectionWeight: weight });
      updated++;
    }
  }
  logger.info(`  Smart Rotation done. ${updated} item(s) updated.`);
}
