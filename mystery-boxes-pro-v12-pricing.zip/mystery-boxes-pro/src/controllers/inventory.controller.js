/**
 * inventory.controller.js — v2 (Security + Gift)
 *
 * Bug Fix: sellItem الآن يستخدم findOneAndUpdate ذري لمنع بيع نفس العنصر مرتين.
 * جديد: giftItem — تحويل للـgift.controller.sendGift.
 */

const Inventory   = require('../models/Inventory');
const User        = require('../models/User');
const Transaction = require('../models/Transaction');
const { withTransaction } = require('../config/db.transaction');
const notify      = require('../services/notify.service');

// GET /inventory
exports.getMyInventory = async (req, res) => {
  try {
    const { page = 1, limit = 20, status, rarity } = req.query;
    const query = { user: req.user.id };
    if (status) query.status = status;
    if (rarity) query.itemRarity = rarity;

    const skip = (Number(page) - 1) * Number(limit);
    const [items, total, summary] = await Promise.all([
      Inventory.find(query)
        .populate('item', 'name image description type platform')
        .sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
      Inventory.countDocuments(query),
      Inventory.aggregate([
        { $match: { user: req.user._id } },
        { $group: { _id: '$itemRarity', count: { $sum: 1 }, totalValue: { $sum: '$itemValue' } } }
      ])
    ]);

    const totalValue = summary.reduce((s, r) => s + r.totalValue, 0);
    res.json({ success: true, count: items.length, total, pages: Math.ceil(total / Number(limit)), totalValue: +totalValue.toFixed(2), summary, items });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// GET /inventory/:id
exports.getInventoryItem = async (req, res) => {
  try {
    const item = await Inventory.findOne({ _id: req.params.id, user: req.user.id })
      .select('+deliveryCode')
      .populate('item', 'name image description type platform');
    if (!item) return res.status(404).json({ success: false, message: 'العنصر غير موجود' });
    res.json({ success: true, item });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// POST /inventory/:id/sell — BUG FIX: atomic status flip prevents double-sell
exports.sellItem = async (req, res) => {
  try {
    // findOneAndUpdate ذري: يغيّر الحالة إلى 'sold' بشرط أنها 'pending' أو 'delivered'
    // إذا كان عنصران يحاولان البيع في نفس الوقت، يفوز الأول فقط — الثاني يجد null
    const inv = await Inventory.findOneAndUpdate(
      { _id: req.params.id, user: req.user.id, status: { $in: ['pending', 'delivered'] } },
      { $set: { status: 'sold', soldAt: new Date() } },
      { new: false } // نعيد القيمة القديمة لاستخدام itemValue الأصلي
    );
    if (!inv) {
      return res.status(404).json({ success: false, message: 'العنصر غير موجود أو تم التصرف فيه مسبقاً' });
    }

    // نسبة الشراء: epic/legendary → 80%، غيره → 70%
    const pct      = ['epic', 'legendary', 'mythical'].includes(inv.itemRarity) ? 0.80 : 0.70;
    const sellValue = +(inv.itemValue * pct).toFixed(4);

    await withTransaction(async (session) => {
      await User.findByIdAndUpdate(req.user.id, {
        $inc: { walletBalance: sellValue, totalEarned: sellValue }
      }, { session });

      const user = await User.findById(req.user.id).session(session);
      await Transaction.create([{
        user: req.user.id, type: 'deposit', amount: sellValue,
        balanceBefore: user.walletBalance - sellValue,
        balanceAfter:  user.walletBalance,
        description: `بيع عنصر: ${inv.itemName} (${inv.itemRarity})`,
        status: 'completed', method: 'sell_back'
      }], { session });

      await Inventory.findByIdAndUpdate(inv._id, { $set: { soldForAmount: sellValue } }, { session });
    });

    const updated = await User.findById(req.user.id).select('walletBalance');
    res.json({
      success: true,
      message: `تم بيع "${inv.itemName}" بـ $${sellValue} (${(pct * 100).toFixed(0)}%)`,
      soldFor:    sellValue,
      newBalance: +updated.walletBalance.toFixed(4)
    });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// POST /inventory/:id/gift — يُحوَّل لـgift.controller.sendGift مع inventoryId من params
exports.giftFromInventory = async (req, res) => {
  req.body.inventoryId = req.params.id;
  return require('./gift.controller').sendGift(req, res);
};
