/**
 * developer.routes.js
 *
 * Three route groups:
 *   /api/dev/*          — External API (x-api-key auth)
 *   /api/dev-portal/*   — Developer portal (JWT auth)
 *   /api/v1/admin/developers/* — Admin management
 */

const express = require('express');

// ── External API (for apps/bots/games) ──────────────────────────────────────
const apiRouter  = express.Router();
const devApi     = require('../developer/developer.api.controller');
const { authenticateDeveloper } = require('../developer/developer.auth');

apiRouter.use(authenticateDeveloper);
apiRouter.post('/open-box',   devApi.openBox);
apiRouter.get('/boxes',       devApi.listBoxes);
apiRouter.get('/stats',       devApi.getStats);
apiRouter.get('/commissions', devApi.getCommissions);
apiRouter.post('/withdraw',   devApi.requestWithdraw);
apiRouter.get('/payouts',     devApi.getPayouts);

// ── Developer portal (self-service) ─────────────────────────────────────────
const portalRouter = express.Router();
const devPortal    = require('../developer/developer.portal.controller');

portalRouter.post('/register',    devPortal.register);
portalRouter.post('/login',       devPortal.login);
portalRouter.use(devPortal.protectPortal); // JWT required below
portalRouter.get('/me',           devPortal.getMe);
portalRouter.post('/rotate-key',  devPortal.rotateKey);
portalRouter.put('/webhook',      devPortal.updateWebhook);
portalRouter.put('/ips',          devPortal.updateIPs);

// ── Admin developer management ───────────────────────────────────────────────
const adminDevRouter = express.Router();
const adminDev  = require('../developer/admin.developer.controller');
const { protect, authorize } = require('../middleware/auth.middleware');

adminDevRouter.use(protect, authorize('admin'));
adminDevRouter.get('/',                         adminDev.getDevelopers);
adminDevRouter.get('/commissions/overview',     adminDev.getCommissionOverview);
adminDevRouter.get('/payouts/pending',          adminDev.getPendingPayouts);
adminDevRouter.get('/:id',                      adminDev.getDeveloper);
adminDevRouter.post('/:id/approve',             adminDev.approveDeveloper);
adminDevRouter.post('/:id/reject',              adminDev.rejectDeveloper);
adminDevRouter.post('/:id/suspend',             adminDev.suspendDeveloper);
adminDevRouter.put('/:id/commission',           adminDev.updateCommission);
adminDevRouter.post('/payouts/:id/process',     adminDev.processPayout);
adminDevRouter.post('/payouts/:id/reject',      adminDev.rejectPayout);

module.exports = { apiRouter, portalRouter, adminDevRouter };
