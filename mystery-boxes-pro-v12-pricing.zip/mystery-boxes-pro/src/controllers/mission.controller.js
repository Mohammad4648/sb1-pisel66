/**
 * mission.controller.js
 *
 * GET  /missions          — مهام اليوم + الأسبوع مع التقدم
 * GET  /missions/history  — سجل المهام المكتملة
 */

const { getUserMissions } = require('../services/mission.service');
const MissionProgress     = require('../models/MissionProgress');

exports.getMissions = async (req, res) => {
  try {
    const missions = await getUserMissions(req.user.id);
    res.json({ success: true, ...missions });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.getMissionHistory = async (req, res) => {
  try {
    const { page = 1, limit = 20 } = req.query;
    const skip = (Number(page) - 1) * Number(limit);
    const [completed, total] = await Promise.all([
      MissionProgress.find({ user: req.user.id, isCompleted: true })
        .sort({ completedAt: -1 }).skip(skip).limit(Number(limit)),
      MissionProgress.countDocuments({ user: req.user.id, isCompleted: true })
    ]);
    const totalXP   = completed.reduce((s, m) => s + (m.rewardXP   || 0), 0);
    const totalCash = completed.reduce((s, m) => s + (m.rewardCash || 0), 0);
    res.json({ success: true, count: completed.length, total, totalXP, totalCash, history: completed });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};
