/**
 * queue.manager.js
 *
 * BullMQ-based job queue for heavy async operations.
 * Falls back to direct execution if Redis is not configured (dev mode).
 *
 * Queues:
 *   - box-open:      process box openings asynchronously
 *   - fulfillment:   call provider APIs without blocking the HTTP response
 *   - sync:          background price sync from providers
 *   - notifications: send emails without slowing down responses
 */

const logger = require('../utils/logger');

// Check if BullMQ/Redis are available
let Queue, Worker, QueueEvents;
let bullAvailable = false;
try {
  ({ Queue, Worker, QueueEvents } = require('bullmq'));
  bullAvailable = !!process.env.REDIS_URL;
} catch {
  bullAvailable = false;
}

const redisConnection = bullAvailable
  ? { url: process.env.REDIS_URL || 'redis://localhost:6379' }
  : null;

// ─────────────────────────────────────────────────────────────────────────────
// Queue factory
// ─────────────────────────────────────────────────────────────────────────────

const queues = {};

function getQueue(name) {
  if (!bullAvailable) return null;
  if (!queues[name]) {
    queues[name] = new Queue(name, {
      connection: redisConnection,
      defaultJobOptions: { attempts: 3, backoff: { type: 'exponential', delay: 2000 } }
    });
  }
  return queues[name];
}

// ─────────────────────────────────────────────────────────────────────────────
// Enqueue helpers
// ─────────────────────────────────────────────────────────────────────────────

async function enqueue(queueName, jobName, data, opts = {}) {
  const q = getQueue(queueName);
  if (!q) {
    // Fallback: execute inline
    logger.info(`[Queue fallback] ${queueName}:${jobName} — running inline`);
    return { inline: true };
  }
  const job = await q.add(jobName, data, { priority: 1, ...opts });
  logger.info(`[Queue] Enqueued ${queueName}:${jobName} jobId=${job.id}`);
  return job;
}

// Specific job dispatchers
const jobs = {
  fulfillItem: (data) => enqueue('fulfillment', 'fulfill-item', data),
  syncProvider: (providerId) => enqueue('sync', 'sync-provider', { providerId }, { delay: 1000 }),
  sendEmail:  (data) => enqueue('notifications', 'send-email', data),
  stopLossCheck: (boxId) => enqueue('box-open', 'stop-loss-check', { boxId })
};

// ─────────────────────────────────────────────────────────────────────────────
// Worker registration — call this once on server start
// ─────────────────────────────────────────────────────────────────────────────

function startWorkers() {
  if (!bullAvailable) {
    logger.info('BullMQ workers skipped — Redis not configured');
    return;
  }

  // Fulfillment worker
  new Worker('fulfillment', async (job) => {
    if (job.name === 'fulfill-item') {
      const { providerId, item, userId, shippingAddress, inventoryId } = job.data;
      const { fulfillItem } = require('../services/provider.service');
      const User      = require('../models/User');
      const Inventory = require('../models/Inventory');

      const user   = await User.findById(userId);
      const result = await fulfillItem(providerId, item, user, shippingAddress);

      if (result.success && inventoryId) {
        await Inventory.findByIdAndUpdate(inventoryId, {
          status:       'delivered',
          deliveredAt:  new Date(),
          deliveryCode: result.deliveryData?.key
        });
      }
      return result;
    }
  }, { connection: redisConnection, concurrency: 5 });

  // Sync worker
  new Worker('sync', async (job) => {
    if (job.name === 'sync-provider') {
      const { syncProviderItems } = require('../services/sync.service');
      return syncProviderItems(job.data.providerId);
    }
  }, { connection: redisConnection, concurrency: 2 });

  // Notifications worker
  new Worker('notifications', async (job) => {
    if (job.name === 'send-email') {
      const notify = require('../services/notification.service');
      const { type, ...data } = job.data;
      if (notify[type]) await notify[type](...Object.values(data));
    }
  }, { connection: redisConnection, concurrency: 10 });

  // Stop-loss worker
  new Worker('box-open', async (job) => {
    if (job.name === 'stop-loss-check') {
      const Box = require('../models/Box');
      const { checkStopLoss } = require('../services/roi.engine');
      const box = await Box.findById(job.data.boxId);
      if (box) await checkStopLoss(box);
    }
  }, { connection: redisConnection });

  logger.info('✅ BullMQ workers started');
}

module.exports = { getQueue, enqueue, jobs, startWorkers, bullAvailable };
