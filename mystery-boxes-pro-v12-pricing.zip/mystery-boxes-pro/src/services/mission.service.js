/**
 * mission.service.js
 *
 * يتتبع تقدم المستخدم في المهام اليومية والأسبوعية.
 * كل حدث (فتح صندوق، إيداع، إحالة) يستدعي recordEvent().
 * المهمة المكتملة تُكافئ فوراً بـ XP و cash.
 */

const MissionProgress = require('../models/MissionProgress');
const { missionDefinitions } = require('../models/MissionProgress');
const User        = require('../models/User');
const Transaction = require('../models/Transaction');
const notify      = require('./notify.service');
const logger      = require('../utils/logger');

// ── مفاتيح الفترة الزمنية ──────────────────────────────────────────────────
function getDailyKey()  {
  return new Date().toISOString().slice(0, 10); // "2024-01-15"
}
function getWeeklyKey() {
  const d   = new Date();
  const jan = new Date(d.getFullYear(), 0, 1);
  const week = Math.ceil(((d - jan) / 86400000 + jan.getDay() + 1) / 7);
  return `${d.getFullYear()}-W${String(week).padStart(2, '0')}`;
}
function getPeriodKey(period) {
  return period === 'daily' ? getDailyKey() : getWeeklyKey();
}

// ── تسجيل حدث ─────────────────────────────────────────────────────────────
/**
 * @param {string} userId
 * @param {string} eventType  - 'open_boxes' | 'deposit' | 'win_rarity' | 'spend_amount' | 'refer_active'
 * @param {*}      value      - رقم أو string (للـrarity)
 */
async function recordEvent(userId, eventType, value = 1) {
  const relevant = missionDefinitions.filter(m => m.type === eventType);
  if (relevant.length === 0) return;

  const completed = [];

  for (const def of relevant) {
    const periodKey = getPeriodKey(def.period);

    // هل المهمة مكتملة بالفعل في هذه الفترة؟
    const existing = await MissionProgress.findOne({
      user: userId, missionId: def.id, periodKey
    });
    if (existing?.isCompleted) continue;

    // رارتي missions: value يجب أن يساوي الـtarget
    let increment = 1;
    if (false) { // win_rarity محذوفة — لا نظام ندرة
      if (value !== def.target) continue;
    } else if (eventType === 'spend_amount') {
      increment = Number(value) || 0;
    }

    // atomic upsert مع زيادة التقدم
    const updated = await MissionProgress.findOneAndUpdate(
      { user: userId, missionId: def.id, periodKey },
      {
        $inc:        { progress: increment },
        $setOnInsert: {
          period: def.period, target: def.target,
          rewardXP: def.xp, rewardCash: def.cash
        }
      },
      { upsert: true, new: true }
    );

    // هل أكمل المهمة للتو؟
    if (!updated.isCompleted && updated.progress >= def.target) {
      await MissionProgress.findByIdAndUpdate(updated._id, {
        $set: { isCompleted: true, completedAt: new Date() }
      });
      completed.push({ def, doc: updated });
    }
  }

  // منح المكافآت (async — لا تمنع الرد)
  for (const { def } of completed) {
    _claimReward(userId, def).catch(err =>
      logger.error(`Mission reward error [${def.id}]: ${err.message}`)
    );
  }
}

// ── منح المكافأة ──────────────────────────────────────────────────────────
async function _claimReward(userId, def) {
  const updates = { $inc: {} };
  if (def.xp > 0) {
    const user = await User.findById(userId);
    const prevLevel = user.level;
    user.addXP(def.xp);
    await user.save({ validateBeforeSave: false });

    if (user.level > prevLevel) {
      await notify.levelUp(userId, user.level, user.loyaltyDiscount ?? 0);
    }
  }

  if (def.cash > 0) {
    const user = await User.findById(userId).select('walletBalance');
    await User.findByIdAndUpdate(userId, {
      $inc: { walletBalance: def.cash, totalEarned: def.cash }
    });
    await Transaction.create({
      user: userId, type: 'bonus', amount: def.cash,
      balanceBefore: user.walletBalance, balanceAfter: user.walletBalance + def.cash,
      description: `مكافأة مهمة: ${def.label}`, status: 'completed', method: 'mission'
    });
  }

  await MissionProgress.findOneAndUpdate(
    { user: userId, missionId: def.id, periodKey: getPeriodKey(def.period) },
    { $set: { rewardClaimed: true } }
  );

  await notify.missionCompleted(userId, def.label, def.xp, def.cash);
  logger.info(`Mission reward: user=${userId} mission=${def.id} xp=${def.xp} cash=$${def.cash}`);
}

// ── جلب مهام المستخدم الحالية ─────────────────────────────────────────────
async function getUserMissions(userId) {
  const dailyKey  = getDailyKey();
  const weeklyKey = getWeeklyKey();

  const progress = await MissionProgress.find({
    user: userId,
    periodKey: { $in: [dailyKey, weeklyKey] }
  }).lean();

  const progressMap = {};
  progress.forEach(p => { progressMap[`${p.missionId}:${p.periodKey}`] = p; });

  const daily  = [];
  const weekly = [];

  for (const def of missionDefinitions) {
    const key  = def.period === 'daily' ? dailyKey : weeklyKey;
    const prog = progressMap[`${def.id}:${key}`];

    const entry = {
      id:          def.id,
      label:       def.label,
      type:        def.type,
      target:      def.target,
      progress:    prog?.progress || 0,
      isCompleted: prog?.isCompleted || false,
      rewardXP:    def.xp,
      rewardCash:  def.cash,
      completedAt: prog?.completedAt || null,
      progressPct: Math.min(100, Math.round(((prog?.progress || 0) / def.target) * 100))
    };

    if (def.period === 'daily')  daily.push(entry);
    else                          weekly.push(entry);
  }

  return {
    daily,
    weekly,
    summary: {
      dailyCompleted:  daily.filter(m => m.isCompleted).length,
      dailyTotal:      daily.length,
      weeklyCompleted: weekly.filter(m => m.isCompleted).length,
      weeklyTotal:     weekly.length
    }
  };
}

module.exports = { recordEvent, getUserMissions, getDailyKey, getWeeklyKey };
