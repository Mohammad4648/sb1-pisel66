const mongoose = require('mongoose');

const referralSchema = new mongoose.Schema({
  referrer:     { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  referredUser: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, unique: true },

  // Commission config at time of joining (can differ per deal)
  commissionRate:    { type: Number, required: true }, // % e.g. 10
  commissionType:    { type: String, enum: ['percentage', 'fixed'], default: 'percentage' },

  // Financials
  totalCommissionEarned:  { type: Number, default: 0 },
  totalReferredSpent:     { type: Number, default: 0 }, // كل ما أنفقه المُحال
  purchaseCount:          { type: Number, default: 0 },
  isActive:               { type: Boolean, default: false }, // true بعد أول شراء

  // First purchase milestone
  firstPurchaseAt:  { type: Date },
  firstPurchaseAmt: { type: Number },

  // Purchases log (آخر 100 فقط)
  purchases: [{
    order:      { type: mongoose.Schema.Types.ObjectId, ref: 'Order' },
    amount:     Number,
    commission: Number,
    date:       { type: Date, default: Date.now }
  }],

  status: { type: String, enum: ['active', 'inactive', 'flagged'], default: 'active' }

}, { timestamps: true });

referralSchema.index({ referrer: 1, createdAt: -1 });
referralSchema.index({ referredUser: 1 });
referralSchema.index({ referrer: 1, isActive: 1 });

module.exports = mongoose.model('Referral', referralSchema);
