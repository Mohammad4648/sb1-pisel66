const express = require('express');
const router  = express.Router();
const c       = require('./import.controller');
const { protect, authorize } = require('../middleware/auth.middleware');

router.use(protect, authorize('admin'));

router.post('/run',          c.runImport);
router.post('/run-box',      c.runBoxImport);
router.post('/sync-prices',  c.syncPrices);
router.post('/clean',        c.clean);
router.get ('/status',       c.getStatus);
router.get ('/plan',         c.getPlan);

module.exports = router;
