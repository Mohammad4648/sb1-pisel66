const express = require('express');
const router  = express.Router();
const admin   = require('../controllers/admin.controller');
const { protect, authorize } = require('../middleware/auth.middleware');

router.use(protect, authorize('admin'));

// Dashboard
router.get('/dashboard',   admin.getDashboardStats);

// Providers
router.get('/providers',          admin.getProviders);
router.post('/providers',         admin.createProvider);
router.put('/providers/:id',      admin.updateProvider);
router.delete('/providers/:id',   admin.deleteProvider);
router.get('/providers/:id/ping', admin.pingProviderHealth);

// Sync
router.post('/sync/all',  admin.syncAll);
router.post('/sync/:id',  admin.syncProvider);

// Pricing / ROI
router.post('/pricing/check',      admin.checkBoxPricing);
router.get('/pricing/projection',  admin.revenueProjection);
router.get('/boxes/:id/roi',       admin.getBoxROIReport);
router.put('/boxes/:id/margin',    admin.updateBoxMargin);
router.post('/boxes/:id/stop',     admin.emergencyStopBox);
router.post('/boxes/:id/stoploss', admin.runStopLoss);

// User management
router.get('/users',                  admin.getUsers);
router.post('/users/:id/ban',         admin.banUser);
router.post('/users/:id/unban',       admin.unbanUser);
router.put('/users/:id/balance',      admin.adjustUserBalance);

// Analytics
router.get('/analytics/summary',      admin.getPlatformSummary);
router.get('/analytics/revenue',      admin.getRevenueChart);
router.get('/analytics/boxes',        admin.getBoxPerformance);
router.get('/analytics/rarity',       admin.getRarityDistribution);
router.get('/analytics/top-spenders', admin.getTopSpenders);

// Fraud
router.get('/fraud',                  admin.getFraudReport);

// Orders audit
router.get('/orders',                 admin.getAllOrders);

// Cache
router.get('/cache/stats',   admin.getCacheStats);
router.post('/cache/flush',  admin.flushCache);

module.exports = router;
