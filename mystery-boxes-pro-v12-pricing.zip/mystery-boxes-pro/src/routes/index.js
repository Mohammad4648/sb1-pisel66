const express = require('express');
const router  = express.Router();

// ── Core routes ───────────────────────────────────────────────────────────
router.use('/auth',          require('./auth.routes'));
router.use('/boxes',         require('./box.routes'));
router.use('/wallet',        require('./wallet.routes'));
router.use('/referrals',     require('./referral.routes'));
router.use('/orders',        require('./order.routes'));
router.use('/coupons',       require('./coupon.routes'));
router.use('/inventory',     require('./inventory.routes'));
router.use('/levels',        require('./levels.routes'));

// ── New features ──────────────────────────────────────────────────────────
router.use('/items',          require('./item.routes'));
router.use('/notifications', require('./notification.routes'));
router.use('/gifts',         require('./gift.routes'));
router.use('/missions',      require('./mission.routes'));
router.use('/events',        require('./event.routes'));
router.use('/activity',      require('./activity.routes'));

// ── Admin ─────────────────────────────────────────────────────────────────
router.use('/admin/compliance',  require('./compliance.routes'));
router.use('/admin/catalog',      require('../api/catalog.admin.routes'));
router.use('/admin/catalog/import', require('../import/import.routes'));

// ── شهادة الامتثال الشرعي العامة ──────────────────────────────────────────
router.get('/halal-certificate', (req, res) => {
  const { SHARIA_RULES, TERMS_OF_SERVICE, PLATFORM } = require('../config/islamic.config');
  res.json({
    success: true,
    platform: PLATFORM,
    certificate: {
      title:    'شهادة الامتثال الشرعي',
      issuedBy: `${PLATFORM.nameAr} — فريق المراجعة الشرعية`,
      date:     new Date().toISOString().slice(0, 10),
      status:   '✅ المنصة ممتثلة للضوابط الشرعية الإسلامية',
      rules:    SHARIA_RULES,
      terms:    TERMS_OF_SERVICE
    }
  });
});
router.use('/admin',             require('./admin.routes'));
router.use('/admin/developers',  require('./developer.routes').adminDevRouter);

// ── B2B Developer API ─────────────────────────────────────────────────────
const { apiRouter, portalRouter } = require('./developer.routes');
router.use('/dev',           apiRouter);
router.use('/dev-portal',    portalRouter);

// ── Root info ─────────────────────────────────────────────────────────────
router.get('/', (req, res) => {
  res.json({
    name:    `🏡 ${require('../config/islamic.config').PLATFORM.nameAr} — ${require('../config/islamic.config').PLATFORM.taglineAr}`,
    version: '10.0.0',
    endpoints: {
      auth:          '/api/v1/auth',
      boxes:         '/api/v1/boxes',
      wallet:        '/api/v1/wallet',
      inventory:     '/api/v1/inventory',
      referrals:     '/api/v1/referrals',
      levels:        '/api/v1/levels',
      missions:      '/api/v1/missions',
      gifts:         '/api/v1/gifts',
      events:        '/api/v1/events/active',
      activity:      '/api/v1/activity',
      notifications: '/api/v1/notifications',
      orders:        '/api/v1/orders',
      coupons:       '/api/v1/coupons',
      admin:         '/api/v1/admin',
      compliance:    '/api/v1/admin/compliance',
      catalog:       '/api/v1/admin/catalog',
      devApi:        '/api/v1/dev',
      devPortal:     '/api/v1/dev-portal'
    }
  });
});

// ── Supplier API — مسار مستقل بمفتاح Bearer sk_live_xxx ─────────────────
// يُضاف في app.js: app.use('/api/supplier', require('./routes/supplier.public'));
module.exports = router;
