/**
 * item.controller.js — كتالوج المنتجات
 *
 * GET  /items                  — تصفح الكتالوج مع فلترة وبحث
 * GET  /items/:id              — تفاصيل منتج
 * POST /items/:id/rate         — تقييم منتج (بعد الاستلام)
 * GET  /items/categories       — قائمة الفئات مع العدد
 *
 * [Admin]
 * POST   /items                — إضافة منتج
 * PUT    /items/:id            — تعديل منتج
 * DELETE /items/:id            — إيقاف منتج
 * PUT    /items/:id/risk       — تعديل refundRiskScore يدوياً
 */

const Item      = require('../models/Item');
const Inventory = require('../models/Inventory');
const cache     = require('../services/cache.service');

// ── تصفح الكتالوج ─────────────────────────────────────────────────────────
exports.getItems = async (req, res) => {
  try {
    const {
      page = 1, limit = 24,
      type, category, bucket,
      minValue, maxValue,
      sort = 'popular',   // popular | newest | price_asc | price_desc | rating
      search,
      isBonus
    } = req.query;

    const query = { isActive: true };
    if (type)     query.type            = type;
    if (category) query.productCategory = { $regex: category, $options: 'i' };
    if (bucket)   query.bucket          = bucket;
    if (isBonus !== undefined) query.isBonus = isBonus === 'true';
    if (minValue || maxValue) {
      query.marketValue = {};
      if (minValue) query.marketValue.$gte = Number(minValue);
      if (maxValue) query.marketValue.$lte = Number(maxValue);
    }
    if (search) {
      query.$or = [
        { name:            { $regex: search, $options: 'i' } },
        { productCategory: { $regex: search, $options: 'i' } },
        { description:     { $regex: search, $options: 'i' } }
      ];
    }

    const sortMap = {
      popular:    { droppedCount: -1 },
      newest:     { createdAt: -1 },
      price_asc:  { marketValue: 1 },
      price_desc: { marketValue: -1 },
      rating:     { avgRating: -1, ratingCount: -1 }
    };

    const skip = (Number(page) - 1) * Number(limit);
    const [items, total] = await Promise.all([
      Item.find(query)
        .select('-supplierCost -estimatedShipping -selectionWeight -refundRiskScore -provider -externalId')
        .sort(sortMap[sort] || sortMap.popular)
        .skip(skip).limit(Number(limit)),
      Item.countDocuments(query)
    ]);

    res.json({
      success: true,
      count: items.length,
      total,
      pages: Math.ceil(total / Number(limit)),
      items
    });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ── تفاصيل منتج ─────────────────────────────────────────────────────────────
exports.getItem = async (req, res) => {
  try {
    const item = await Item.findById(req.params.id)
      .select('-supplierCost -estimatedShipping -selectionWeight -refundRiskScore');
    if (!item || !item.isActive) {
      return res.status(404).json({ success: false, message: 'المنتج غير موجود' });
    }
    res.json({ success: true, item });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ── قائمة الفئات مع العدد ─────────────────────────────────────────────────
exports.getCategories = async (req, res) => {
  try {
    const cacheKey = 'items:categories';
    const cats = await cache.wrap(cacheKey, async () => {
      const [byType, byCategory] = await Promise.all([
        Item.aggregate([
          { $match: { isActive: true, isBonus: false } },
          { $group: { _id: '$type', count: { $sum: 1 } } },
          { $sort: { count: -1 } }
        ]),
        Item.aggregate([
          { $match: { isActive: true, isBonus: false, productCategory: { $ne: null } } },
          { $group: { _id: '$productCategory', count: { $sum: 1 }, type: { $first: '$type' } } },
          { $sort: { count: -1 } }
        ])
      ]);
      return { byType, byCategory };
    }, 300);
    res.json({ success: true, ...cats });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ── تقييم منتج — فقط من استلمه ───────────────────────────────────────────
exports.rateItem = async (req, res) => {
  try {
    const { rating, review } = req.body;
    if (!rating || rating < 1 || rating > 5) {
      return res.status(400).json({ success: false, message: 'التقييم يجب أن يكون بين 1 و5' });
    }

    // التحقق أن المستخدم استلم هذا المنتج فعلاً
    const inv = await Inventory.findOne({
      user: req.user.id,
      item: req.params.id,
      status: { $in: ['delivered', 'redeemed', 'sold'] }
    });
    if (!inv) {
      return res.status(403).json({ success: false, message: 'يمكنك التقييم فقط بعد استلام المنتج' });
    }

    // تحقق من عدم التقييم مسبقاً
    if (inv.rated) {
      return res.status(400).json({ success: false, message: 'قيّمت هذا المنتج مسبقاً' });
    }

    // تحديث متوسط التقييم atomic
    const item = await Item.findById(req.params.id);
    if (!item) return res.status(404).json({ success: false, message: 'المنتج غير موجود' });

    const newCount  = item.ratingCount + 1;
    const newAvg    = +((item.avgRating * item.ratingCount + rating) / newCount).toFixed(2);

    // تحديث refundRiskScore تلقائياً إذا التقييم منخفض جداً
    let riskUpdate = {};
    if (newAvg < 2.5 && newCount >= 5) {
      riskUpdate.refundRiskScore = Math.min(5, (item.refundRiskScore || 2) + 1);
    } else if (newAvg >= 4.2 && newCount >= 10) {
      riskUpdate.refundRiskScore = Math.max(1, (item.refundRiskScore || 2) - 1);
    }

    await Item.findByIdAndUpdate(req.params.id, {
      $set:  { avgRating: newAvg, ...riskUpdate },
      $inc:  { ratingCount: 1 }
    });

    // علّم في المخزون أنه قيّم
    await Inventory.findByIdAndUpdate(inv._id, { $set: { rated: true } });

    cache.delPattern('items:');
    res.json({
      success: true,
      message: 'شكراً على تقييمك!',
      newRating: { avg: newAvg, count: newCount }
    });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ══════════════════════════════════════════════════════════════════════════
// [Admin] CRUD
// ══════════════════════════════════════════════════════════════════════════

exports.createItem = async (req, res) => {
  try {
    // ── فحص الامتثال الشرعي قبل إضافة المنتج ────────────────────────────
    const { validateItemHalal } = require('../services/halal.service');
    const halalCheck = validateItemHalal(req.body);
    if (!halalCheck.halal) {
      return res.status(400).json({
        success: false,
        message: 'المنتج لا يطابق الضوابط الشرعية',
        violations: halalCheck.violations
      });
    }

    req.body.createdBy = req.user.id;
    const item = await Item.create(req.body);
    cache.delPattern('items:');
    res.status(201).json({ success: true, item });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.updateItem = async (req, res) => {
  try {
    // منع تعديل بيانات الأسعار الداخلية من الـAPI العام
    delete req.body.selectionWeight; // يُعدَّل فقط بواسطة Smart Rotation
    const item = await Item.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!item) return res.status(404).json({ success: false, message: 'المنتج غير موجود' });
    cache.delPattern('items:');
    res.json({ success: true, item });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.deleteItem = async (req, res) => {
  try {
    await Item.findByIdAndUpdate(req.params.id, { isActive: false });
    cache.delPattern('items:');
    res.json({ success: true, message: 'تم إيقاف المنتج' });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.updateRisk = async (req, res) => {
  try {
    const { refundRiskScore } = req.body;
    if (!refundRiskScore || refundRiskScore < 1 || refundRiskScore > 5) {
      return res.status(400).json({ success: false, message: 'refundRiskScore يجب أن يكون 1–5' });
    }
    const item = await Item.findByIdAndUpdate(req.params.id,
      { refundRiskScore, selectionWeight: Math.max(10, 100 - (refundRiskScore - 1) * 15) },
      { new: true }
    );
    res.json({ success: true, item });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// [Admin] إحصائيات المنتجات
exports.getItemStats = async (req, res) => {
  try {
    const stats = await Item.aggregate([
      { $match: { isActive: true } },
      { $group: {
        _id:   '$type',
        count:       { $sum: 1 },
        avgRating:   { $avg: '$avgRating' },
        totalDropped:{ $sum: '$droppedCount' },
        avgRisk:     { $avg: '$refundRiskScore' }
      }},
      { $sort: { totalDropped: -1 } }
    ]);
    const risky = await Item.find({ refundRiskScore: { $gte: 4 }, isActive: true })
      .select('name type refundRiskScore avgRating droppedCount').limit(10);

    res.json({ success: true, stats, riskyItems: risky });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};
