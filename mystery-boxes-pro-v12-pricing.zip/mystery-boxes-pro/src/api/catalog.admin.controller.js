/**
 * catalog.admin.controller.js — إدارة الكتالوج (للأدمن فقط)
 *
 * طريقتان للوصول:
 *   A) Session JWT (من لوحة التحكم)
 *   B) API Key: Authorization: Bearer ck_xxx (من أدوات خارجية)
 *
 * ─────────────────────────────────────────────────────
 * مفتاح API:
 *   POST /admin/catalog/generate-key      ← توليد مفتاح جديد
 *   GET  /admin/catalog/key-info          ← معلومات المفتاح الحالي
 *
 * إدارة المنتجات:
 *   POST   /admin/catalog/items           ← إضافة منتج واحد
 *   POST   /admin/catalog/items/bulk      ← استيراد بالجملة (حتى 5000)
 *   GET    /admin/catalog/items           ← عرض + فلترة + بحث
 *   PUT    /admin/catalog/items/:id       ← تعديل
 *   DELETE /admin/catalog/items/:id       ← إيقاف
 *
 * اختبار الصندوق:
 *   POST /admin/catalog/test-sample       ← محاكاة اختيار منتج
 *   POST /admin/catalog/validate-filter   ← التحقق من فلتر صندوق
 *
 * إحصاءات:
 *   GET /admin/catalog/stats              ← إجمالي الكتالوج
 */

const CatalogItem    = require('../models/CatalogItem');
const AdminCatalogKey= require('../models/AdminCatalogKey');
const { validateItemHalal } = require('../services/halal.service');
const { sampleItem, validateFilter, getStats } = require('../services/catalog.sampler');
const logger = require('../utils/logger');

// ══════════════════════════════════════════════════════════════════════════════
// مفتاح API
// ══════════════════════════════════════════════════════════════════════════════

// POST /admin/catalog/generate-key
exports.generateKey = async (req, res) => {
  try {
    // إلغاء المفتاح القديم إن وجد
    await AdminCatalogKey.updateMany({}, { isActive: false });

    const { raw, hash, prefix } = AdminCatalogKey.generate();
    await AdminCatalogKey.create({
      label:     req.body.label || 'Admin Catalog Key',
      keyHash:   hash,
      keyPrefix: prefix,
      createdBy: req.user.id,
    });

    res.json({
      success:   true,
      apiKey:    raw,
      keyPrefix: prefix,
      warning:   '⚠️ احفظ هذا المفتاح الآن — لن يُعرض مجدداً',
      usage:     'Authorization: Bearer ' + raw,
      endpoints: {
        addOne:  'POST /admin/catalog/items',
        addBulk: 'POST /admin/catalog/items/bulk',
        list:    'GET  /admin/catalog/items',
      }
    });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// GET /admin/catalog/key-info
exports.getKeyInfo = async (req, res) => {
  try {
    const key = await AdminCatalogKey.findOne({ isActive: true }).select('-keyHash');
    res.json({ success: true, hasKey: !!key, key: key || null });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ══════════════════════════════════════════════════════════════════════════════
// إضافة منتج واحد
// ══════════════════════════════════════════════════════════════════════════════

exports.createItem = async (req, res) => {
  try {
    const data = req.body;

    // تحقق أساسي
    const mv = +Number(data.marketValue  || 0).toFixed(2);
    const sc = +Number(data.supplierCost || 0).toFixed(2);
    const errors = [];
    if (!data.name || data.name.trim().length < 2) errors.push('name مطلوب');
    if (!data.category) errors.push('category مطلوب');
    if (mv <= 0) errors.push('marketValue > 0 مطلوب');
    if (sc <= 0) errors.push('supplierCost > 0 مطلوب');
    if (mv < sc) errors.push('marketValue يجب ≥ supplierCost');

    // فحص حلال
    const halal = validateItemHalal({ name: data.name, description: data.description, productCategory: data.category });
    if (!halal.halal) errors.push(...halal.violations);

    if (errors.length) return res.status(400).json({ success: false, errors });

    const item = await CatalogItem.create({
      name:              data.name.trim(),
      description:       data.description?.trim() || '',
      image:             data.image || '',
      sku:               data.sku   || '',
      category:          data.category,
      subCategory:       data.subCategory || '',
      marketValue:       mv,
      supplierCost:      sc,
      estimatedShipping: +Number(data.shipping || 0.9).toFixed(2),
      selectionWeight:   Number(data.selectionWeight ?? 100),
      refundRiskScore:   Number(data.riskScore ?? 2),
      isActive:          true,
      halalVerified:     true,
      addedBy:           req.user?.id,
      notes:             data.notes || '',
    });

    res.status(201).json({ success: true, itemId: item._id, name: item.name });
  } catch (e) {
    if (e.code === 11000) return res.status(409).json({ success: false, message: 'منتج مكرر' });
    res.status(500).json({ success: false, message: e.message });
  }
};

// ══════════════════════════════════════════════════════════════════════════════
// استيراد بالجملة — حتى 5000 منتج
// ══════════════════════════════════════════════════════════════════════════════

exports.bulkImport = async (req, res) => {
  try {
    const { items } = req.body;
    if (!Array.isArray(items) || !items.length)
      return res.status(400).json({ success: false, message: 'items[] مطلوب' });

    if (items.length > 5000)
      return res.status(400).json({ success: false, message: `الحد الأقصى 5000 منتج/طلب — لديك ${items.length}` });

    const accepted = [], rejected = [];

    for (const [i, d] of items.entries()) {
      const mv = +Number(d.marketValue || 0).toFixed(2);
      const sc = +Number(d.supplierCost || 0).toFixed(2);
      const errs = [];

      if (!d.name?.trim())  errs.push('name مطلوب');
      if (!d.category)      errs.push('category مطلوب');
      if (mv <= 0)          errs.push('marketValue مطلوب');
      if (sc <= 0)          errs.push('supplierCost مطلوب');
      if (mv < sc)          errs.push('marketValue < supplierCost');

      const halal = validateItemHalal({ name: d.name, description: d.description, productCategory: d.category });
      if (!halal.halal) errs.push(...halal.violations);

      if (errs.length) {
        rejected.push({ index: i, name: d.name, errors: errs });
        continue;
      }

      accepted.push({
        name:              d.name.trim(),
        description:       d.description?.trim() || '',
        image:             d.image || '',
        sku:               d.sku   || '',
        category:          d.category,
        subCategory:       d.subCategory || '',
        marketValue:       mv,
        supplierCost:      sc,
        estimatedShipping: +Number(d.shipping || 0.9).toFixed(2),
        selectionWeight:   Number(d.selectionWeight ?? 100),
        refundRiskScore:   Number(d.riskScore ?? 2),
        isActive:          true,
        halalVerified:     true,
        addedBy:           req.user?.id,
      });
    }

    let inserted = 0;
    if (accepted.length) {
      const r = await CatalogItem.insertMany(accepted, { ordered: false, rawResult: true })
        .catch(e => {
          if (e.writeErrors) return { insertedCount: accepted.length - e.writeErrors.length };
          throw e;
        });
      inserted = r.insertedCount ?? accepted.length;
    }

    logger.info(`bulkImport: accepted=${inserted} rejected=${rejected.length}`);

    res.status(201).json({
      success:      true,
      total:        items.length,
      accepted:     inserted,
      rejected:     rejected.length,
      rejectedList: rejected.slice(0, 20),
    });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ══════════════════════════════════════════════════════════════════════════════
// عرض المنتجات
// ══════════════════════════════════════════════════════════════════════════════

exports.getItems = async (req, res) => {
  try {
    const { page=1, limit=50, category, active, search, minValue, maxValue } = req.query;
    const q = {};
    if (category)  q.category  = category;
    if (active !== undefined) q.isActive = active === 'true';
    if (minValue)  q.marketValue = { ...q.marketValue, $gte: +minValue };
    if (maxValue)  q.marketValue = { ...q.marketValue, $lte: +maxValue };
    if (search)    q.name = { $regex: search, $options: 'i' };

    const skip = (Number(page)-1) * Number(limit);
    const [docs, total] = await Promise.all([
      CatalogItem.find(q).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
      CatalogItem.countDocuments(q)
    ]);
    res.json({ success: true, total, page: Number(page), items: docs });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ══════════════════════════════════════════════════════════════════════════════
// تعديل / إيقاف
// ══════════════════════════════════════════════════════════════════════════════

exports.updateItem = async (req, res) => {
  try {
    const item = await CatalogItem.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!item) return res.status(404).json({ success: false, message: 'المنتج غير موجود' });
    res.json({ success: true, item });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.deleteItem = async (req, res) => {
  try {
    await CatalogItem.findByIdAndUpdate(req.params.id, { isActive: false });
    res.json({ success: true, message: 'تم إيقاف المنتج' });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ══════════════════════════════════════════════════════════════════════════════
// اختبار الاختيار العشوائي — للتأكد قبل نشر الصندوق
// ══════════════════════════════════════════════════════════════════════════════

exports.testSample = async (req, res) => {
  try {
    const { filter, boxPrice, times = 5 } = req.body;
    if (!boxPrice) return res.status(400).json({ success: false, message: 'boxPrice مطلوب' });

    // اختبر N مرات وأظهر التوزيع
    const results = [];
    for (let i = 0; i < Math.min(times, 20); i++) {
      const r = await sampleItem(filter, boxPrice);
      if (r.item) results.push({ name: r.item.name, value: r.item.marketValue, category: r.item.category });
    }

    const validation = await validateFilter(filter, boxPrice);

    res.json({
      success:       true,
      filter,
      boxPrice,
      catalogMatch:  validation,
      samples:       results,
      note:          'هذا مجرد اختبار — النتائج الفعلية عشوائية تماماً'
    });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// POST /admin/catalog/validate-filter
exports.validateBoxFilter = async (req, res) => {
  try {
    const { filter, boxPrice } = req.body;
    if (!boxPrice) return res.status(400).json({ success: false, message: 'boxPrice مطلوب' });
    const result = await validateFilter(filter, boxPrice);
    res.json({ success: true, ...result });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// GET /admin/catalog/stats
exports.getCatalogStats = async (req, res) => {
  try {
    const stats = await getStats();
    res.json({ success: true, ...stats });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};
