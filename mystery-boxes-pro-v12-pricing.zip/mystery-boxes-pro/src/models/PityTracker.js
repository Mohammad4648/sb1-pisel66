const mongoose = require('mongoose');

/**
 * Pity System — guarantees rare/epic/legendary after N consecutive opens
 * without getting that rarity tier or higher.
 *
 * Example: if pityRare = 10, user is guaranteed a ≥ rare item on their 10th open
 * without having received one, resetting the counter.
 */
const pityTrackerSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  box:  { type: mongoose.Schema.Types.ObjectId, ref: 'Box',  required: true },

  // Opens since last rare/epic/legendary (resets on each tier)
  opensSinceRare:      { type: Number, default: 0 },
  opensSinceEpic:      { type: Number, default: 0 },
  opensSinceLegendary: { type: Number, default: 0 },

  totalOpens: { type: Number, default: 0 },
  lastOpenAt: { type: Date }
}, { timestamps: true });

pityTrackerSchema.index({ user: 1, box: 1 }, { unique: true });

/**
 * After each open, update pity counters based on what rarity was received.
 * Returns true if pity was triggered (forced upgrade).
 */
pityTrackerSchema.methods.recordOpen = function (receivedRarity, boxPityConfig) {
  this.totalOpens    += 1;
  this.lastOpenAt     = new Date();
  this.opensSinceRare      += 1;
  this.opensSinceEpic      += 1;
  this.opensSinceLegendary += 1;

  // Reset counters based on rarity received
  const rarityRank = { common: 0, uncommon: 1, rare: 2, epic: 3, legendary: 4 };
  if (rarityRank[receivedRarity] >= 2) this.opensSinceRare      = 0; // rare or better
  if (rarityRank[receivedRarity] >= 3) this.opensSinceEpic      = 0; // epic or better
  if (rarityRank[receivedRarity] >= 4) this.opensSinceLegendary = 0; // legendary

  return this.save({ validateBeforeSave: false });
};

/**
 * Check if any pity threshold is reached — returns the minimum guaranteed rarity.
 */
pityTrackerSchema.methods.getPityGuarantee = function (boxPityConfig) {
  const { rare = 10, epic = 50, legendary = 100 } = boxPityConfig || {};
  if (this.opensSinceLegendary >= legendary - 1) return 'legendary';
  if (this.opensSinceEpic      >= epic      - 1) return 'epic';
  if (this.opensSinceRare      >= rare      - 1) return 'rare';
  return null; // no guarantee triggered
};

module.exports = mongoose.model('PityTracker', pityTrackerSchema);
