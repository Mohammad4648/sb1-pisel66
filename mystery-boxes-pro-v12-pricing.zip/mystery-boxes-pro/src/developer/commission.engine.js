/**
 * commission.engine.js
 *
 * Calculates and credits developer commissions on every box open.
 *
 * Profit flow (example $1 box):
 *   boxPrice   = $1.00
 *   itemCost   = $0.60  (expected value / what we pay out)
 *   profit     = $0.40  (40% actual margin)
 *
 *   Developer commission (percentage, 20% of profit):
 *     commission = $0.40 × 20% = $0.08
 *
 *   Developer commission (fixed, $0.05 per open):
 *     commission = $0.05
 *
 * Commission is only credited AFTER order is marked completed.
 */

const Developer  = require('../models/Developer');
const Commission = require('../models/Commission');
const logger     = require('../utils/logger');

/**
 * Calculate commission amount for a developer.
 * @param {Developer} dev
 * @param {number} boxPrice
 * @param {number} itemValue  - actual prize value (cost to platform)
 */
function calculateCommission(dev, boxPrice, itemValue) {
  const platformProfit = Math.max(0, boxPrice - itemValue);

  let amount = 0;
  if (dev.commissionType === 'percentage') {
    amount = platformProfit * (dev.commissionValue / 100);
  } else if (dev.commissionType === 'fixed') {
    // Fixed: min of fixed amount and 80% of platform profit (safety cap)
    amount = Math.min(dev.commissionValue, platformProfit * 0.80);
  }

  return {
    amount:         +Math.max(0, amount).toFixed(4),
    boxPrice,
    itemValue,
    platformProfit: +platformProfit.toFixed(4),
    commissionType: dev.commissionType,
    commissionRate: dev.commissionValue
  };
}

/**
 * Process and credit commission for a completed order.
 * Called from box.controller after successful open.
 *
 * @param {string} developerId
 * @param {Object} order        - Mongoose order document
 * @param {number} itemValue    - Actual won item value
 * @param {string} externalUserId
 * @param {string} sourceApp
 */
async function processCommission(developerId, order, itemValue, externalUserId, sourceApp) {
  if (!developerId) return null;

  const dev = await Developer.findById(developerId);
  if (!dev || dev.status !== 'active') {
    logger.warn(`Commission skipped: developer ${developerId} not active`);
    return null;
  }

  const { amount, boxPrice, platformProfit, commissionType, commissionRate } = calculateCommission(dev, order.price, itemValue);

  if (amount <= 0) return null;

  // BUG FIX: Use atomic $inc instead of read-modify-save.
  // Concurrent box opens previously caused lost updates:
  //   Request A reads balance=$10, Request B reads balance=$10
  //   Both compute $10 + $0.08 = $10.08, both save → $0.08 lost.
  // $inc is atomic at the MongoDB document level — no race possible.
  const updatedDev = await Developer.findByIdAndUpdate(
    dev._id,
    {
      $inc: {
        balance:       amount,
        totalEarnings: amount,
        pendingPayout: amount,
        totalBoxOpens: 1,
        totalRevenue:  order.price
      },
      $set: { lastActivityAt: new Date() }
    },
    { new: true }
  );

  // Record commission event
  const commission = await Commission.create({
    developer:       updatedDev._id,
    order:           order._id,
    sourceApp,
    externalUserId,
    boxPrice,
    platformCost:    itemValue,
    platformProfit,
    commissionType,
    commissionRate,
    commissionAmount: amount,
    status:          'credited',
    creditedAt:      new Date()
  });

  logger.info(`💰 Commission credited: dev=${updatedDev.name} amount=$${amount} order=${order._id}`);
  return commission;
}

/**
 * Get commission summary for a developer (for dashboard).
 */
async function getDeveloperStats(developerId, days = 30) {
  const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);

  const [totals, daily, topBoxes] = await Promise.all([
    Commission.aggregate([
      { $match: { developer: developerId, status: 'credited', createdAt: { $gte: since } } },
      { $group: { _id: null, revenue: { $sum: '$boxPrice' }, commission: { $sum: '$commissionAmount' }, opens: { $sum: 1 } } }
    ]),
    Commission.aggregate([
      { $match: { developer: developerId, status: 'credited', createdAt: { $gte: since } } },
      { $group: {
        _id:    { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } },
        revenue: { $sum: '$boxPrice' },
        commission: { $sum: '$commissionAmount' },
        opens:  { $sum: 1 }
      }},
      { $sort: { _id: 1 } }
    ]),
    Commission.aggregate([
      { $match: { developer: developerId, status: 'credited' } },
      { $group: { _id: '$order', boxPrice: { $first: '$boxPrice' }, commission: { $first: '$commissionAmount' } } },
      { $group: { _id: null, topBox: { $max: '$commission' } } }
    ])
  ]);

  return {
    period:     `${days}d`,
    opens:      totals[0]?.opens      || 0,
    revenue:    +(totals[0]?.revenue   || 0).toFixed(2),
    commission: +(totals[0]?.commission || 0).toFixed(2),
    dailyChart: daily
  };
}

module.exports = { calculateCommission, processCommission, getDeveloperStats };
