const mongoose = require('mongoose');

const giftSchema = new mongoose.Schema({
  sender:    { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  receiver:  { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  inventory: { type: mongoose.Schema.Types.ObjectId, ref: 'Inventory', required: true },

  // Snapshot at time of gift
  itemName:   { type: String, required: true },
  itemRarity: { type: String, required: true },
  itemValue:  { type: Number, required: true },
  itemImage:  { type: String },

  message:   { type: String, maxlength: 200 },

  status: {
    type:    String,
    enum:    ['pending', 'accepted', 'declined', 'cancelled'],
    default: 'pending'
  },

  expiresAt:   { type: Date, default: () => new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) }, // 7 days
  respondedAt: { type: Date }
}, { timestamps: true });

giftSchema.index({ sender: 1, createdAt: -1 });
giftSchema.index({ receiver: 1, status: 1 });
giftSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 }); // TTL cleanup

module.exports = mongoose.model('Gift', giftSchema);
