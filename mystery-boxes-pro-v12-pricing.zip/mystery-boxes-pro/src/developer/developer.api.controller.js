/**
 * developer.api.controller.js
 *
 * External API consumed by developer apps/bots/games.
 * All routes protected by authenticateDeveloper middleware.
 *
 * Routes:
 *   POST /api/dev/open-box      - Open a box for an external user
 *   GET  /api/dev/boxes         - List available boxes
 *   GET  /api/dev/stats         - Developer stats + earnings
 *   GET  /api/dev/commissions   - Commission history
 *   POST /api/dev/withdraw      - Request payout
 *   GET  /api/dev/payouts       - Payout history
 */

const Box            = require('../models/Box');
const Order          = require('../models/Order');
const Transaction    = require('../models/Transaction');
const DeveloperPayout= require('../models/DeveloperPayout');
const Developer      = require('../models/Developer');

const { withTransaction }    = require('../config/db.transaction');
const { securePickFrom }     = require('../utils/secure.rng');
const { generateServerSeed, generateOutcome, pickRarityFromFloat, buildProof } = require('../security/provably.fair');
const { checkDailyWinCap, meetsMinimumOpens } = require('../services/roi.engine');
const { processCommission, getDeveloperStats } = require('./commission.engine');
const { dispatchBoxOpened }  = require('./webhook.service');
const cache  = require('../services/cache.service');
const logger = require('../utils/logger');

// ─────────────────────────────────────────────────────────────────────────────
// POST /api/dev/open-box
// Open a box on behalf of an external user (identified by externalUserId)
// ─────────────────────────────────────────────────────────────────────────────
exports.openBox = async (req, res) => {
  try {
    const { externalUserId, boxId, clientSeed, sourceApp } = req.body;
    const dev = req.developer;

    if (!externalUserId || !boxId) {
      return res.status(400).json({ success: false, error: 'externalUserId and boxId are required' });
    }

    const box = await Box.findById(boxId).populate('items');
    if (!box || !box.isActive) {
      return res.status(404).json({ success: false, error: 'Box not found or unavailable' });
    }

    // ── Provably fair outcome ─────────────────────────────────────────────
    const { serverSeed, serverSeedHash } = generateServerSeed();
    const usedClientSeed = clientSeed || `${externalUserId}-${Date.now()}`;
    const nonce     = box.openingsCount + 1;
    const fairFloat = generateOutcome(serverSeed, usedClientSeed, nonce);
    const rarityPick = pickRarityFromFloat(fairFloat, box.rarityDistribution);

    // ── Pick item ─────────────────────────────────────────────────────────
    const pool = box.items.filter(i => i.rarity === rarityPick);
    const item = securePickFrom(pool.length > 0 ? pool : box.items);
    if (!item) return res.status(500).json({ success: false, error: 'No items in box' });

    // ── Create order (no wallet deduction — developer manages payments) ───
    const order = await Order.create({
      box:      box._id,
      boxName:  box.name,
      price:    box.finalPrice,
      externalUserId,
      developerId: dev._id,
      sourceApp:   sourceApp || 'external',
      itemsReceived: [{
        item:   item._id,
        name:   item.name,
        rarity: item.rarity,
        value:  item.baseValue,
        image:  item.image
      }],
      totalValue:    item.baseValue,
      status:        'completed',
      paymentMethod: 'developer_api',
      completedAt:   new Date()
    });

    // Update box stats
    await Box.findByIdAndUpdate(box._id, {
      $inc: { openingsCount: 1, soldCount: 1, totalRevenue: box.finalPrice }
    });
    cache.delPattern('boxes:');

    // ── Commission engine ─────────────────────────────────────────────────
    const commission = await processCommission(
      dev._id, order, item.baseValue, externalUserId, sourceApp || dev.name
    );
    const commissionAmount = commission?.commissionAmount || 0;

    // ── Webhook dispatch (async, non-blocking) ────────────────────────────
    if (dev.webhookUrl) {
      dispatchBoxOpened(dev, {
        externalUserId,
        boxId:   box._id.toString(),
        boxName: box.name,
        reward:  { name: item.name, rarity: item.rarity, value: item.baseValue, image: item.image },
        commission: commissionAmount
      }).catch(err => logger.error('Webhook error:', err.message));
    }

    logger.info(`[DEV API] ${dev.name} opened "${box.name}" for user ${externalUserId} — commission $${commissionAmount}`);

    res.json({
      success: true,
      reward: {
        name:   item.name,
        rarity: item.rarity,
        value:  item.baseValue,
        image:  item.image
      },
      orderId:   order._id,
      fairness: {
        serverSeedHash,
        clientSeed: usedClientSeed,
        nonce,
        // serverSeed revealed so dev can verify independently
        serverSeed
      },
      commission: commissionAmount
    });
  } catch (err) {
    logger.error('DEV openBox error:', err.message);
    res.status(500).json({ success: false, error: err.message });
  }
};

// ─────────────────────────────────────────────────────────────────────────────
// GET /api/dev/boxes
// ─────────────────────────────────────────────────────────────────────────────
exports.listBoxes = async (req, res) => {
  try {
    const { category, boxType } = req.query;
    const cacheKey = `dev:boxes:${category}:${boxType}`;
    const boxes = await cache.wrap(cacheKey, () => {
      const query = { isActive: true };
      if (category) query.category = category;
      if (boxType)  query.boxType  = boxType;
      return Box.find(query).select('name price finalPrice category boxType rarityDistribution openingsCount').sort({ price: 1 });
    }, 120);
    res.json({ success: true, count: boxes.length, boxes });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};

// ─────────────────────────────────────────────────────────────────────────────
// GET /api/dev/stats
// ─────────────────────────────────────────────────────────────────────────────
exports.getStats = async (req, res) => {
  try {
    const dev  = req.developer;
    const days = parseInt(req.query.days) || 30;
    const stats = await getDeveloperStats(dev._id, days);

    res.json({
      success: true,
      developer: {
        name:           dev.name,
        status:         dev.status,
        balance:        +dev.balance.toFixed(2),
        totalEarnings:  +dev.totalEarnings.toFixed(2),
        pendingPayout:  +dev.pendingPayout.toFixed(2),
        commissionType: dev.commissionType,
        commissionValue:`${dev.commissionValue}${dev.commissionType === 'percentage' ? '%' : '$'}`
      },
      stats
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};

// ─────────────────────────────────────────────────────────────────────────────
// GET /api/dev/commissions
// ─────────────────────────────────────────────────────────────────────────────
exports.getCommissions = async (req, res) => {
  try {
    const Commission = require('../models/Commission');
    const { page = 1, limit = 20 } = req.query;
    const skip = (page - 1) * limit;
    const [items, total] = await Promise.all([
      Commission.find({ developer: req.developer._id, status: 'credited' })
        .sort({ createdAt: -1 }).skip(skip).limit(parseInt(limit)),
      Commission.countDocuments({ developer: req.developer._id, status: 'credited' })
    ]);
    res.json({ success: true, count: items.length, total, commissions: items });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};

// ─────────────────────────────────────────────────────────────────────────────
// POST /api/dev/withdraw
// ─────────────────────────────────────────────────────────────────────────────
exports.requestWithdraw = async (req, res) => {
  try {
    const { amount, method = 'crypto', address } = req.body;
    const dev = await Developer.findById(req.developer._id);

    if (!amount || amount < dev.minPayout) {
      return res.status(400).json({ success: false, error: `Minimum withdrawal is $${dev.minPayout}` });
    }
    if (!address) {
      return res.status(400).json({ success: false, error: 'Wallet address or payment details required' });
    }
    if (dev.balance < amount) {
      return res.status(400).json({ success: false, error: `Insufficient balance. Available: $${dev.balance.toFixed(2)}` });
    }

    // Reserve funds
    dev.balance        -= amount;
    dev.pendingPayout  -= amount;
    await dev.save({ validateBeforeSave: false });

    const payout = await DeveloperPayout.create({
      developer: dev._id, amount, method, address, status: 'pending'
    });

    logger.info(`💸 Payout request: dev=${dev.name} amount=$${amount} method=${method}`);
    res.json({
      success: true,
      message: 'Payout request submitted. Processing within 1–3 business days.',
      payout: { id: payout._id, amount, method, status: 'pending' }
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};

// ─────────────────────────────────────────────────────────────────────────────
// GET /api/dev/payouts
// ─────────────────────────────────────────────────────────────────────────────
exports.getPayouts = async (req, res) => {
  try {
    const payouts = await DeveloperPayout.find({ developer: req.developer._id })
      .sort({ createdAt: -1 }).limit(50);
    res.json({ success: true, payouts });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};
