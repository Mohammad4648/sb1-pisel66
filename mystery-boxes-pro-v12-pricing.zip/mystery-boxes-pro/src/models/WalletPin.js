const mongoose = require('mongoose');
const bcrypt   = require('bcryptjs');

const walletPinSchema = new mongoose.Schema({
  user:           { type: mongoose.Schema.Types.ObjectId, ref: 'User', unique: true, required: true },
  pinHash:        { type: String, required: true },
  failedAttempts: { type: Number, default: 0 },
  lockedUntil:    { type: Date }
}, { timestamps: true });

walletPinSchema.pre('save', async function (next) {
  if (this.isModified('pinHash') && !this.pinHash.startsWith('$2')) {
    this.pinHash = await bcrypt.hash(this.pinHash, 12);
  }
  next();
});

walletPinSchema.methods.verifyPin = async function (pin) {
  if (this.lockedUntil && new Date() < this.lockedUntil) {
    const mins = Math.ceil((this.lockedUntil - Date.now()) / 60000);
    throw new Error(`PIN مقفل. حاول بعد ${mins} دقيقة`);
  }
  const ok = await bcrypt.compare(String(pin), this.pinHash);
  if (!ok) {
    this.failedAttempts += 1;
    if (this.failedAttempts >= 5) {
      this.lockedUntil    = new Date(Date.now() + 15 * 60 * 1000);
      this.failedAttempts = 0;
    }
    await this.save();
    return false;
  }
  this.failedAttempts = 0;
  await this.save();
  return true;
};

module.exports = mongoose.model('WalletPin', walletPinSchema);
