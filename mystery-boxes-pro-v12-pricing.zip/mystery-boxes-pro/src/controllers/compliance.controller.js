/**
 * compliance.controller.js — لوحة المراجعة المالية والشرعية
 *
 * [Admin فقط]
 * GET /admin/compliance/halal         — بيان الامتثال الشرعي الكامل
 * GET /admin/compliance/financials    — مراجعة مالية شاملة
 * GET /admin/compliance/box/:id       — تحليل مالي + شرعي لصندوق
 * GET /admin/compliance/projections   — توقعات أرباح
 * POST /admin/compliance/audit-item   — فحص منتج قبل إضافته
 * POST /admin/compliance/audit-box    — فحص صندوق قبل نشره
 */

const { validateItemHalal, validateBoxHalal, COMPLIANCE_STATEMENT } = require('../services/halal.service');
const { getPlatformFinancials, analyzeBoxCost, projectRevenue, BOX_FINANCIAL_MODELS } = require('../services/financial.review');
const Box  = require('../models/Box');
const Item = require('../models/Item');

// ── بيان الامتثال الشرعي ─────────────────────────────────────────────────
exports.getHalalCompliance = async (req, res) => {
  try {
    // فحص كل المنتجات النشطة
    const items   = await Item.find({ isActive: true }).select('name type productCategory description');
    const issues  = [];

    for (const item of items) {
      const check = validateItemHalal(item);
      if (!check.halal) {
        issues.push({ item: item.name, violations: check.violations });
      }
    }

    // فحص كل الصناديق النشطة
    const boxes      = await Box.find({ isActive: true }).populate('items');
    const boxIssues  = [];

    for (const box of boxes) {
      const check = validateBoxHalal(box, box.items);
      if (!check.halal) {
        boxIssues.push({ box: box.name, issues: check.issues, grade: check.grade });
      }
    }

    res.json({
      success: true,
      compliance: {
        ...COMPLIANCE_STATEMENT,
        audit: {
          itemsChecked:    items.length,
          itemsPassed:     items.length - issues.length,
          itemsFailed:     issues.length,
          boxesChecked:    boxes.length,
          boxesPassed:     boxes.length - boxIssues.length,
          boxesFailed:     boxIssues.length,
          overallStatus:   (issues.length + boxIssues.length) === 0 ? '✅ ممتثل بالكامل' : '⚠️ يحتاج مراجعة',
          itemIssues:      issues,
          boxIssues
        }
      }
    });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ── مراجعة مالية شاملة ────────────────────────────────────────────────────
exports.getFinancials = async (req, res) => {
  try {
    const days = parseInt(req.query.days) || 30;
    const [platform, projections] = await Promise.all([
      getPlatformFinancials(days),
      Promise.resolve(projectRevenue([
        { label: 'محافظ',  dailyOrders: 50,  avgBoxPrice: 6.0 },
        { label: 'متوسط',  dailyOrders: 200, avgBoxPrice: 6.5 },
        { label: 'متفائل', dailyOrders: 500, avgBoxPrice: 7.0 },
      ]))
    ]);

    res.json({
      success: true,
      financial: {
        platform,
        boxModels:   BOX_FINANCIAL_MODELS,
        projections,
        summary: {
          healthScore: platform.risks.marginStatus,
          refundAlert: platform.risks.refundStatus,
          recommendation: platform.profit.margin >= 15
            ? 'المنصة مربحة — يمكن التوسع'
            : platform.profit.margin >= 8
              ? 'الهامش مقبول — راجع التكاليف لتحسينه'
              : 'الهامش منخفض — راجع أسعار الصناديق أو تكاليف المورد'
        }
      }
    });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ── تحليل مالي + شرعي لصندوق معين ─────────────────────────────────────────
exports.auditBox = async (req, res) => {
  try {
    const box   = await Box.findById(req.params.id).populate('items');
    if (!box) return res.status(404).json({ success: false, message: 'الصندوق غير موجود' });

    const mainItems     = box.items.filter(i => !i.isBonus);
    const avgSupplier   = mainItems.reduce((s, i) => s + (i.supplierCost || 0), 0) / (mainItems.length || 1);
    const avgShipping   = mainItems.reduce((s, i) => s + (i.estimatedShipping || 0.9), 0) / (mainItems.length || 1);

    const [financial, halal] = [
      analyzeBoxCost(box.price, avgSupplier, avgShipping, box.boxType === 'digital'),
      validateBoxHalal(box, mainItems)
    ];

    res.json({
      success: true,
      boxName: box.name,
      price:   box.price,
      items:   mainItems.length,
      financial,
      halal,
      overallGrade: halal.halal && financial.viable
        ? 'A ✅ — مطابق شرعياً ومالياً'
        : !halal.halal
          ? `C ❌ — مشاكل شرعية: ${halal.issues.join(', ')}`
          : `B ⚠️ — مقبول شرعياً لكن هامش مالي ${financial.margin}%`
    });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ── فحص منتج قبل الإضافة ─────────────────────────────────────────────────
exports.auditItem = async (req, res) => {
  try {
    const check = validateItemHalal(req.body);
    res.json({
      success: true,
      ...check,
      boxPrice: req.body.boxPrice,
      valueCheck: req.body.boxPrice ? {
        marketValue:  req.body.marketValue,
        minAllowed:   +(req.body.boxPrice * 0.70).toFixed(2),
        maxAllowed:   +(req.body.boxPrice * 1.40).toFixed(2),
        inRange:      req.body.marketValue >= req.body.boxPrice * 0.70 &&
                      req.body.marketValue <= req.body.boxPrice * 1.40
      } : null
    });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ── فحص صندوق قبل النشر ───────────────────────────────────────────────────
exports.auditBoxPreview = async (req, res) => {
  try {
    const { price, itemIds } = req.body;
    if (!price || !itemIds?.length) {
      return res.status(400).json({ success: false, message: 'price و itemIds مطلوبان' });
    }
    const items    = await Item.find({ _id: { $in: itemIds } });
    const halal    = validateBoxHalal({ price }, items);
    const avgCost  = items.reduce((s, i) => s + (i.supplierCost || 0), 0) / items.length;
    const financial= analyzeBoxCost(price, avgCost);

    res.json({
      success: true,
      halal,
      financial,
      ready: halal.halal && financial.viable
    });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};
