/**
 * catalog.sampler.js — اختيار عشوائي من الكتالوج
 *
 * للحجم: 1K–50K منتج
 * الطريقة: MongoDB $sample (عشوائي حقيقي على مستوى DB)
 *
 * الصندوق يحتوي:
 *   catalogFilter: { categories: ['electronics'], minPricePct: 0.85, maxPricePct: 1.15 }
 *
 * عند الفتح:
 *   1. query = { category: {$in:[...]}, marketValue: {$gte, $lte}, isActive: true }
 *   2. $sample:{size:10} يختار 10 عشوائياً
 *   3. weightedRandom يختار 1 من الـ10 حسب selectionWeight
 */

const CatalogItem = require('../models/CatalogItem');
const { weightedRandom } = require('../utils/secure.rng');
const { catalogFilter: getPriceFilter } = require('./pricing.engine.v2');
const logger = require('../utils/logger');

// ── بناء Query من فلتر الصندوق ──────────────────────────────────────────────
function buildQuery(filter, boxPrice) {
  const {
    categories  = [],    // ['electronics'] أو [] = كل الفئات
    minPricePct = 0.85,
    maxPricePct = 1.15,
    excludeIds  = [],    // تنويع — استبعاد ما اختير مؤخراً
  } = filter || {};

  // نستخدم supplierCost (لا marketValue) لأن الفلتر ربحي لا شفافية
  const pf   = getPriceFilter(boxPrice);
  const minV = pf.priceMin;
  const maxV = pf.priceMax;

  const q = {
    isActive:      true,
    halalRejected: false,
    supplierCost:  { $gte: minV, $lte: maxV }, // فلتر ربحي صحيح
  };

  if (categories.length > 0) q.category = { $in: categories };
  if (excludeIds.length > 0)  q._id      = { $nin: excludeIds };

  return { query: q, minV, maxV };
}

// ── الاختيار الرئيسي ──────────────────────────────────────────────────────────
async function sampleItem(filter, boxPrice) {
  const { query, minV, maxV } = buildQuery(filter, boxPrice);

  // عدّ سريع (يستخدم index)
  const count = await CatalogItem.countDocuments(query);

  if (count === 0) {
    logger.warn(`catalog.sampler: لا منتجات | price=$${boxPrice} filter=${JSON.stringify(filter)}`);
    return { item: null, error: 'NO_ITEMS_FOUND', count: 0 };
  }

  // لـ1K–50K: $sample:{size:10} سريع جداً (ميلي ثوانٍ)
  const candidates = await CatalogItem.aggregate([
    { $match: query },
    { $sample: { size: Math.min(10, count) } },
    { $project: {
        name:1, description:1, image:1, category:1, subCategory:1,
        marketValue:1, estimatedShipping:1, selectionWeight:1, refundRiskScore:1
    }}
  ]);

  if (!candidates.length) return { item: null, error: 'EMPTY', count };

  // اختيار مرجّح من الـ10
  const selected = weightedRandom(
    candidates.map(c => ({ value: c, weight: c.selectionWeight ?? 100 }))
  );

  logger.info(`sampler: "${selected.name}" (من ${count} منتج)`);
  return { item: selected, count, range: { minV, maxV } };
}

// ── التحقق من الفلتر قبل حفظ الصندوق ──────────────────────────────────────────
async function validateFilter(filter, boxPrice) {
  const { query, minV, maxV } = buildQuery(filter, boxPrice);
  const count = await CatalogItem.countDocuments(query);
  return {
    valid:   count >= 5,
    count,
    range:   { minV, maxV },
    message: count < 5
      ? `⚠️ ${count} منتجات فقط — أضف المزيد لهذه الفئة`
      : `✅ ${count} منتجاً مطابقاً`
  };
}

// ── إحصاءات سريعة ─────────────────────────────────────────────────────────────
async function getStats() {
  const [byCategory, total] = await Promise.all([
    CatalogItem.aggregate([
      { $match: { isActive: true } },
      { $group: { _id: '$category', count: { $sum: 1 }, avgValue: { $avg: '$marketValue' } } },
      { $sort: { count: -1 } }
    ]),
    CatalogItem.countDocuments({ isActive: true })
  ]);
  return { total, byCategory };
}

module.exports = { sampleItem, validateFilter, getStats, buildQuery };
