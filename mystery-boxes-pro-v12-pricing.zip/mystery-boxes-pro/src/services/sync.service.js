/**
 * sync.service.js
 *
 * Periodically syncs item availability & prices from external providers.
 * Can be triggered manually (admin) or via a cron job.
 */

const axios   = require('axios');
const Item     = require('../models/Item');
const Provider = require('../models/Provider');
const logger   = require('../utils/logger');

/**
 * Sync all digital items linked to a given provider.
 * Updates: stock, baseValue (cost from provider), isActive.
 */
async function syncProviderItems(providerId) {
  const provider = await Provider.findById(providerId).select('+apiKey');
  if (!provider || !provider.isActive) {
    logger.warn(`Sync skipped – provider ${providerId} inactive or not found`);
    return { synced: 0, errors: 0 };
  }

  const items = await Item.find({ provider: providerId, isActive: true });
  let synced = 0, errors = 0;

  for (const item of items) {
    try {
      let providerPrice = null;

      // ── Kingdomlikes ────────────────────────
      if (provider.name === 'Kingdomlikes') {
        const res = await axios.get(`${provider.apiUrl}/services`, {
          params: { key: provider.apiKey },
          timeout: 8000
        });
        const svc = (res.data || []).find(s => String(s.service) === String(item.externalId));
        if (svc) providerPrice = parseFloat(svc.rate) || null;
      }

      // ── G2A ─────────────────────────────────
      if (provider.name === 'G2A') {
        const res = await axios.get(`${provider.apiUrl}/products/${item.externalId}`, {
          headers: { Authorization: `Bearer ${provider.apiKey}` },
          timeout: 8000
        });
        providerPrice = parseFloat(res.data?.lowestPrice) || null;
      }

      if (providerPrice !== null) {
        item.providerCost = providerPrice;
        // Keep baseValue (what we show as "prize value") ≥ providerCost
        if (item.baseValue < providerPrice) item.baseValue = providerPrice;
        await item.save({ validateBeforeSave: false });
        synced++;
      }
    } catch (err) {
      logger.error(`Sync failed for item ${item._id}: ${err.message}`);
      errors++;
    }
  }

  logger.info(`Sync complete for provider "${provider.name}": ${synced} synced, ${errors} errors`);
  return { synced, errors, provider: provider.name };
}

/**
 * Sync all active providers at once.
 */
async function syncAllProviders() {
  const providers = await Provider.find({ isActive: true }).select('_id name');
  const results = [];
  for (const p of providers) {
    const r = await syncProviderItems(p._id);
    results.push({ provider: p.name, ...r });
  }
  return results;
}

module.exports = { syncProviderItems, syncAllProviders };
