/**
 * provider.service.js  v2
 * Adapters: Kingdomlikes, G2A, Whop, CJdropshipping
 */
const axios    = require('axios');
const Provider = require('../models/Provider');
const logger   = require('../utils/logger');

async function fulfillKingdomlikes(apiKey, apiUrl, item, user) {
  try {
    const res = await axios.post(`${apiUrl}/order`, { key: apiKey, service: item.externalId, link: user.email, quantity: 1 }, { timeout: 10000 });
    if (res.data?.order) return { success: true, deliveryData: { orderId: res.data.order }, providerRef: String(res.data.order) };
    throw new Error(res.data?.error || 'Unknown error');
  } catch (err) { logger.error(`Kingdomlikes: ${err.message}`); return { success: false, error: err.message }; }
}

async function fulfillG2A(apiKey, apiUrl, item) {
  try {
    const res = await axios.get(`${apiUrl}/products/${item.externalId}/keys`, { headers: { Authorization: `Bearer ${apiKey}` }, timeout: 10000 });
    const key = res.data?.keys?.[0];
    if (!key) throw new Error('No key available');
    return { success: true, deliveryData: { key, platform: item.platform || 'PC' }, providerRef: key };
  } catch (err) { logger.error(`G2A: ${err.message}`); return { success: false, error: err.message }; }
}

async function fulfillWhop(apiKey, apiUrl, item, user) {
  try {
    const res = await axios.post(`${apiUrl || 'https://api.whop.com/v2'}/passes`, {
      plan_id: item.externalId, email: user.email,
      metadata: { userId: String(user._id), itemName: item.name }
    }, { headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' }, timeout: 10000 });
    if (res.data?.id) return { success: true, deliveryData: { passId: res.data.id, accessLink: res.data.access_link }, providerRef: res.data.id };
    throw new Error(res.data?.message || 'Whop pass creation failed');
  } catch (err) { logger.error(`Whop: ${err.message}`); return { success: false, error: err.message }; }
}

async function fulfillCJdropshipping(apiKey, apiUrl, item, user, addr) {
  try {
    const res = await axios.post(`${apiUrl}/shopping/order/createOrderV2`, {
      orderNumber: `MBP-${Date.now()}`, shippingZip: addr.zip, shippingCountry: addr.country,
      shippingPhone: addr.phone, shippingName: addr.name, shippingAddress: addr.line1, shippingCity: addr.city,
      products: [{ vid: item.externalId, quantity: 1, shippingName: 'CJPacket Ordinary' }]
    }, { headers: { 'CJ-Access-Token': apiKey }, timeout: 15000 });
    if (res.data?.result) return { success: true, deliveryData: { cjOrderId: res.data.data?.orderId }, providerRef: res.data.data?.orderId };
    throw new Error(res.data?.message || 'CJ order failed');
  } catch (err) { logger.error(`CJdropshipping: ${err.message}`); return { success: false, error: err.message }; }
}

async function fulfillItem(providerId, item, user, shippingAddress = null) {
  const provider = await Provider.findById(providerId).select('+apiKey +apiSecret');
  if (!provider || !provider.isActive) return { success: false, error: 'Provider unavailable' };
  const { name, apiUrl, apiKey } = provider;
  logger.info(`Fulfilling "${item.name}" via ${name}`);
  if (name === 'Kingdomlikes') return fulfillKingdomlikes(apiKey, apiUrl, item, user);
  if (name === 'G2A')          return fulfillG2A(apiKey, apiUrl, item);
  if (name === 'Whop')         return fulfillWhop(apiKey, apiUrl, item, user);
  if (name === 'CJdropshipping' || name === 'AliExpress') {
    if (!shippingAddress) return { success: false, error: 'Shipping address required' };
    return fulfillCJdropshipping(apiKey, apiUrl, item, user, shippingAddress);
  }
  logger.warn(`No adapter for "${name}" — manual`);
  return { success: true, deliveryData: { note: 'Manual fulfillment', item: item.name }, providerRef: `MANUAL-${Date.now()}` };
}

async function pingProvider(providerId) {
  const provider = await Provider.findById(providerId).select('+apiKey');
  if (!provider) return { alive: false, error: 'Not found' };
  try {
    const start = Date.now();
    await axios.get(provider.apiUrl, { headers: { Authorization: `Bearer ${provider.apiKey}` }, timeout: 5000 });
    provider.lastPingedAt = new Date();
    await provider.save({ validateBeforeSave: false });
    return { alive: true, latencyMs: Date.now() - start };
  } catch (err) { return { alive: false, error: err.message }; }
}

module.exports = { fulfillItem, pingProvider };
