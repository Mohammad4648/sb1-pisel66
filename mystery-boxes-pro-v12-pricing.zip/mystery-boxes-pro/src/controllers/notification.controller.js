/**
 * notification.controller.js
 *
 * GET  /notifications         — قائمة الإشعارات + عدد غير المقروءة
 * POST /notifications/read/:id — تحديد إشعار كمقروء
 * POST /notifications/read-all — تحديد الكل كمقروء
 * DELETE /notifications/:id  — حذف إشعار
 * DELETE /notifications       — مسح الكل
 */

const Notification = require('../models/Notification');

exports.getNotifications = async (req, res) => {
  try {
    const { page = 1, limit = 20, unreadOnly } = req.query;
    const query = { user: req.user.id };
    if (unreadOnly === 'true') query.isRead = false;

    const skip = (Number(page) - 1) * Number(limit);
    const [notifications, total, unreadCount] = await Promise.all([
      Notification.find(query).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
      Notification.countDocuments(query),
      Notification.countDocuments({ user: req.user.id, isRead: false })
    ]);

    res.json({
      success: true,
      unreadCount,
      count: notifications.length,
      total,
      pages:  Math.ceil(total / Number(limit)),
      notifications
    });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.markRead = async (req, res) => {
  try {
    await Notification.findOneAndUpdate(
      { _id: req.params.id, user: req.user.id },
      { $set: { isRead: true, readAt: new Date() } }
    );
    res.json({ success: true });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.markAllRead = async (req, res) => {
  try {
    const { modifiedCount } = await Notification.updateMany(
      { user: req.user.id, isRead: false },
      { $set: { isRead: true, readAt: new Date() } }
    );
    res.json({ success: true, marked: modifiedCount });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.deleteNotification = async (req, res) => {
  try {
    await Notification.findOneAndDelete({ _id: req.params.id, user: req.user.id });
    res.json({ success: true });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.clearAll = async (req, res) => {
  try {
    const { deletedCount } = await Notification.deleteMany({ user: req.user.id });
    res.json({ success: true, deleted: deletedCount });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};
