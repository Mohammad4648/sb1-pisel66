const mongoose = require('mongoose');

const providerSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    // e.g. "Kingdomlikes", "G2A", "CJdropshipping"
  },

  type: {
    type: String,
    required: true,
    enum: ['digital', 'physical', 'game_key', 'gift_card'],
  },

  apiUrl: { type: String, trim: true },
  apiKey: { type: String, select: false },  // never returned in queries
  apiSecret: { type: String, select: false },
  webhookSecret: { type: String, select: false },

  // Supported box categories
  supportedCategories: [{
    type: String,
    enum: ['digital', 'gaming', 'physical', 'gift_card']
  }],

  // Fee the provider charges per fulfilled item (% or flat)
  feeType: { type: String, enum: ['percent', 'flat'], default: 'percent' },
  feeValue: { type: Number, default: 0 },  // e.g. 5 => 5%

  // Health & reliability
  isActive: { type: Boolean, default: true },
  lastPingedAt: { type: Date },
  successRate: { type: Number, default: 100, min: 0, max: 100 }, // %

  // Metadata
  website: { type: String },
  notes: { type: String },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
}, { timestamps: true });

module.exports = mongoose.model('Provider', providerSchema);
