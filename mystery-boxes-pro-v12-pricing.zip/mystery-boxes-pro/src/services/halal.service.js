/**
 * halal.service.js — ضوابط الامتثال الشرعي
 *
 * المبادئ المطبّقة:
 * ─────────────────────────────────────────────────────────────────────
 * 1. لا ربا  — لا فوائد على الأرصدة أو الإيداع أو التأخير
 * 2. لا غرر  — شفافية كاملة في المنتجات قبل الشراء
 * 3. لا مقامرة (مَيسر) — لا تفاوت كبير في القيمة، لا نظام نُدرة
 * 4. لا جهالة — كل المنتجات معلومة مسبقاً، السعر ثابت
 * 5. البيع الحلال فقط — فلترة المنتجات المحرّمة
 * 6. العدل في العمولات — عمولة الإحالة مباشرة فقط (L1)، لا شبكات
 * 7. رسوم الخدمة الشفافة — سُمّيت "أجرة" لا "فائدة"
 *
 * المصادر الفقهية المستند إليها:
 *   - قرار مجمع الفقه الإسلامي رقم 63 (بيع الغائب)
 *   - فتاوى هيئة المحاسبة والمراجعة للمؤسسات المالية الإسلامية (AAOIFI)
 *   - مبدأ البيع بالتعيين — المنتج معلوم قبل البيع
 */

const logger = require('../utils/logger');

// ── فئات المنتجات المحرّمة — لا تُضاف للمنصة أبداً ─────────────────────
const HARAM_CATEGORIES = [
  'alcohol', 'tobacco', 'pork', 'gambling', 'adult',
  'weapons', 'drugs', 'interest_products',
  // بالعربية أيضاً
  'كحول', 'تبغ', 'لحم_خنزير', 'قمار', 'أسلحة'
];

const HARAM_KEYWORDS = [
  'casino', 'bet', 'lottery', 'alcohol', 'wine', 'beer', 'pork',
  'tobacco', 'cigarette', 'gambling', 'adult', 'interest', 'riba',
  'خمر', 'خنزير', 'قمار', 'ربا', 'رهان'
];

// ── فحص منتج قبل الإضافة ─────────────────────────────────────────────────
function validateItemHalal(item) {
  const violations = [];

  // فحص الفئة
  const itemCategory = (item.productCategory || item.type || '').toLowerCase();
  if (HARAM_CATEGORIES.some(h => itemCategory.includes(h))) {
    violations.push(`الفئة "${item.productCategory}" غير مسموح بها شرعاً`);
  }

  // فحص الاسم والوصف
  const text = `${item.name} ${item.description || ''}`.toLowerCase();
  const foundKeyword = HARAM_KEYWORDS.find(k => text.includes(k));
  if (foundKeyword) {
    violations.push(`الكلمة "${foundKeyword}" في اسم/وصف المنتج تشير لمحرّم`);
  }

  // فحص التفاوت في القيمة (لا غرر)
  // القاعدة: القيمة السوقية يجب ≥ 70% من سعر الصندوق
  // (يُطبَّق على مستوى الصندوق، ليس هنا)

  return {
    halal:      violations.length === 0,
    violations,
    message:    violations.length === 0
      ? '✅ المنتج مطابق للضوابط الشرعية'
      : `⚠️ ${violations.join(' | ')}`
  };
}

// ── حساب أجرة الخدمة الشفافة (بدل "رسوم") ───────────────────────────────
// الفرق الشرعي: "الأجرة" مقابل خدمة فعلية، "الفائدة" مقابل المال فقط.
// هنا الأجرة مقابل: معالجة الدفع + التخزين + الشحن + خدمة العملاء.
const SERVICE_FEES = {
  // طريقة السحب:  أجرة_الخدمة (نسبة)  |  التبرير
  crypto_usdt:  { rate: 0.01,  label: 'أجرة معالجة شبكة USDT',  justification: 'رسوم شبكة بلوكشين' },
  crypto_btc:   { rate: 0.015, label: 'أجرة معالجة شبكة BTC',   justification: 'رسوم شبكة بيتكوين' },
  bank:         { rate: 0.015, label: 'أجرة تحويل مصرفي',        justification: 'عمولة البنك الوسيط' },
  paypal:       { rate: 0.02,  label: 'أجرة معالجة PayPal',      justification: 'رسوم بوابة الدفع' },
};

function getServiceFee(method, amount) {
  const fee = SERVICE_FEES[method];
  if (!fee) return { amount: 0, label: 'بدون أجرة', rate: 0 };
  return {
    amount:        +( amount * fee.rate ).toFixed(4),
    label:          fee.label,
    justification:  fee.justification,
    rate:           fee.rate
  };
}

// ── التحقق من ضوابط البيع (بيع الموجود) ──────────────────────────────────
// الشرط: المنتج موجود ومعلوم قبل البيع
function validateBoxHalal(box, items) {
  const issues = [];

  // 1. الصندوق يجب أن يحتوي على منتجات فعلية
  if (!items || items.length < 3) {
    issues.push('يجب أن يحتوي الصندوق على 3 منتجات على الأقل لضمان الشفافية');
  }

  // 2. لا تفاوت كبير — كل المنتجات بين 85%–115% من سعر الصندوق (شُدِّد)
  const price = box.price || box.finalPrice;
  const outOfRange = (items || []).filter(i => {
    const v = i.marketValue || 0;
    return v < price * 0.88 || v > price * 1.12;  // ±12% — غرر يسير فقط
  });
  if (outOfRange.length > 0) {
    issues.push(`${outOfRange.length} منتج خارج النطاق الشرعي (85%–115% من السعر) — غرر مؤثر`);
  }

  // 3. قائمة المنتجات يجب أن تكون مكشوفة للمشتري
  if (!box.transparency || !box.transparency.totalProducts) {
    issues.push('يجب عرض قائمة المنتجات للمشتري قبل الشراء (شرط العلم بالمبيع)');
  }

  // 4. لا منتجات محرّمة
  const haramItem = (items || []).find(i => {
    const check = validateItemHalal(i);
    return !check.halal;
  });
  if (haramItem) {
    issues.push(`منتج غير حلال في الصندوق: ${haramItem.name}`);
  }

  return {
    halal:  issues.length === 0,
    issues,
    grade:  issues.length === 0 ? 'A — مطابق شرعياً' :
            issues.length <= 2   ? 'B — يحتاج تعديل' : 'C — غير مسموح'
  };
}

// ── بيان الامتثال الشرعي للـAPI ──────────────────────────────────────────
const COMPLIANCE_STATEMENT = {
  platform:       'Mystery Boxes — منصة حلال',
  certifiedBy:    'مراجعة داخلية وفق مبادئ الفقه الإسلامي',
  principles: [
    { rule: 'لا ربا',     status: 'مطبّق', detail: 'لا فوائد على الأرصدة أو الإيداع' },
    { rule: 'لا غرر',    status: 'مطبّق', detail: 'كل المنتجات معروضة قبل الشراء' },
    { rule: 'لا مقامرة', status: 'مطبّق', detail: 'كل المنتجات بقيمة قريبة من السعر، لا نظام ندرة' },
    { rule: 'لا جهالة',  status: 'مطبّق', detail: 'السعر ثابت، المنتج معلوم النوع مسبقاً' },
    { rule: 'بيع الحلال','status': 'مطبّق', detail: 'فلترة المنتجات المحرّمة عند الإضافة' },
    { rule: 'عدالة العمولات', status: 'مطبّق', detail: 'عمولة إحالة مباشرة فقط — لا شبكات هرمية' },
  ],
  prohibited: HARAM_CATEGORIES,
  updatedAt:  new Date().toISOString().slice(0, 10)
};

module.exports = {
  validateItemHalal,
  validateBoxHalal,
  getServiceFee,
  SERVICE_FEES,
  HARAM_CATEGORIES,
  COMPLIANCE_STATEMENT
};
