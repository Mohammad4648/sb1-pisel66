/**
 * provably.fair.js
 *
 * Provably Fair implementation for Mystery Boxes.
 *
 * Flow:
 *   1. Before open: server generates serverSeed (hashed), sends hash to user
 *   2. User provides clientSeed (or we generate one)
 *   3. Combined hash determines which item is picked
 *   4. After open: reveal serverSeed so user can verify result
 *
 * Verification:
 *   HMAC-SHA256(serverSeed, clientSeed + ':' + nonce) → float [0,1)
 *   That float determines the item picked.
 *
 * User can independently verify every result is not manipulated.
 */

const crypto = require('crypto');

/**
 * Generate a new server seed pair: { serverSeed, serverSeedHash }
 * Store serverSeed securely; send only serverSeedHash to user before opening.
 */
function generateServerSeed() {
  const serverSeed     = crypto.randomBytes(32).toString('hex');
  const serverSeedHash = crypto.createHash('sha256').update(serverSeed).digest('hex');
  return { serverSeed, serverSeedHash };
}

/**
 * Generate a float [0, 1) from seeds — used to pick the item.
 * @param {string} serverSeed  - Secret, revealed only after open
 * @param {string} clientSeed  - Provided by user or generated randomly
 * @param {number} nonce       - Increments with each open (total opens count)
 */
function generateOutcome(serverSeed, clientSeed, nonce) {
  const hmac = crypto.createHmac('sha256', serverSeed);
  hmac.update(`${clientSeed}:${nonce}`);
  const hash = hmac.digest('hex');

  // Use first 8 hex chars (32 bits) as a float
  const intVal = parseInt(hash.slice(0, 8), 16);
  return intVal / 0x100000000; // [0, 1)
}

/**
 * Use the fair float to pick an item from the pool based on rarity weights.
 * @param {number} fairFloat   - from generateOutcome()
 * @param {Array}  rarityPool  - [{ rarity, weight }, ...] where weights sum to 100
 */
function pickRarityFromFloat(fairFloat, distribution) {
  // ملاحظة: هذا الملف قديم — المستخدم الآن fair.random.js (بدون rarity pyramid)
  const tiers = [
    { rarity: 'legendary', threshold: legendary },
    { rarity: 'epic',      threshold: legendary + epic },
    { rarity: 'rare',      threshold: legendary + epic + rare },
    { rarity: 'uncommon',  threshold: legendary + epic + rare + uncommon },
    { rarity: 'common',    threshold: 100 }
  ];

  const roll = fairFloat * 100;
  for (const tier of tiers) {
    if (roll < tier.threshold) return tier.rarity;
  }
  return 'common';
}

/**
 * Generate proof object — stored with the order, shown to user on reveal.
 */
function buildProof(serverSeed, serverSeedHash, clientSeed, nonce, fairFloat, itemName, itemRarity) {
  return {
    serverSeedHash,  // shown BEFORE open (commitment)
    serverSeed,      // revealed AFTER open (verification)
    clientSeed,
    nonce,
    fairFloat: fairFloat.toFixed(10),
    result: { itemName, itemRarity },
    verify: `HMAC-SHA256(serverSeed, "${clientSeed}:${nonce}") → float = ${fairFloat.toFixed(10)}`
  };
}

/**
 * Client-side verification logic (can be embedded in frontend too).
 * Returns true if the proof is valid and result matches.
 */
function verifyProof(proof) {
  const computed = generateOutcome(proof.serverSeed, proof.clientSeed, proof.nonce);
  const hashCheck = crypto.createHash('sha256').update(proof.serverSeed).digest('hex');

  return {
    hashValid:    hashCheck === proof.serverSeedHash,
    floatValid:   Math.abs(computed - parseFloat(proof.fairFloat)) < 1e-9,
    verified:     hashCheck === proof.serverSeedHash && Math.abs(computed - parseFloat(proof.fairFloat)) < 1e-9
  };
}

module.exports = { generateServerSeed, generateOutcome, pickRarityFromFloat, buildProof, verifyProof };
