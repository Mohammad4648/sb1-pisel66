const mongoose = require('mongoose');
const crypto   = require('crypto');

const transactionSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },

  type: {
    type: String,
    enum: [
      'deposit',        // إيداع
      'withdrawal',     // سحب
      'purchase',       // شراء صندوق
      'commission',     // عمولة إحالة
      'refund',         // استرداد
      'bonus',          // مكافأة (milestone / promo)
      'transfer_in',    // استلام تحويل
      'transfer_out',   // إرسال تحويل
      'adjustment'      // تعديل إداري
    ],
    required: true
  },

  amount:        { type: Number, required: true },          // موجب = دخل، سالب = خروج
  fee:           { type: Number, default: 0 },              // رسوم المنصة
  netAmount:     { type: Number },                          // amount - fee (يُحسب في pre-save)
  balanceBefore: { type: Number, required: true },
  balanceAfter:  { type: Number, required: true },
  description:   { type: String, required: true },

  status: {
    type: String,
    enum: ['pending', 'processing', 'completed', 'failed', 'reversed'],
    default: 'completed'
  },

  // References
  reference: {
    type: String, unique: true, sparse: true,
    default: () => 'TXN-' + Date.now() + '-' + crypto.randomBytes(3).toString('hex').toUpperCase()
  },
  relatedOrder:       { type: mongoose.Schema.Types.ObjectId, ref: 'Order' },
  relatedReferral:    { type: mongoose.Schema.Types.ObjectId, ref: 'Referral' },
  relatedWithdrawal:  { type: mongoose.Schema.Types.ObjectId, ref: 'WithdrawalRequest' },
  fromUser:           { type: mongoose.Schema.Types.ObjectId, ref: 'User' }, // for transfers

  // Extra info
  currency:    { type: String, default: 'USD' },
  method:      { type: String },      // binance_pay, crypto, bank, wallet, etc.
  notes:       { type: String },
  metadata:    { type: Object, default: {} },
  reversedAt:  { type: Date },
  reversedBy:  { type: mongoose.Schema.Types.ObjectId, ref: 'User' }

}, { timestamps: true });

// Auto-compute netAmount
transactionSchema.pre('save', function (next) {
  if (this.netAmount == null) {
    this.netAmount = this.amount - (this.fee || 0);
  }
  next();
});

transactionSchema.index({ user: 1, createdAt: -1 });
transactionSchema.index({ user: 1, type: 1 });
transactionSchema.index({ status: 1 });
transactionSchema.index({ reference: 1 });

module.exports = mongoose.model('Transaction', transactionSchema);
