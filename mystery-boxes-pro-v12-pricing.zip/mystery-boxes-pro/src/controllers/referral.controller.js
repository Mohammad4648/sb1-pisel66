/**
 * referral.controller.js
 *
 * Endpoints:
 *   GET  /referrals/           — Dashboard كامل
 *   GET  /referrals/stats      — إحصائيات مفصلة
 *   GET  /referrals/list       — قائمة الإحالات مع pagination
 *   GET  /referrals/commissions — سجل العمولات
 *   GET  /referrals/milestones — المايلستونز
 *   GET  /referrals/leaderboard — ترتيب أعلى مُحيلين
 *   GET  /referrals/validate/:code — التحقق من كود
 *   POST /referrals/claim-cashback — طلب الكاشباك المتراكم
 */

const User           = require('../models/User');
const Referral       = require('../models/Referral');
const ReferralReward = require('../models/ReferralReward');
const Transaction    = require('../models/Transaction');
const cache          = require('../services/cache.service');
const {
  getReferralStats, MILESTONES, getCashbackRate, checkMilestones
} = require('../services/referral.service');
const logger = require('../utils/logger');

// GET /referrals/ — Dashboard سريع
exports.getDashboard = async (req, res) => {
  try {
    const user = await User.findById(req.user.id)
      .select('tier activeReferrals referralCount totalCommissionEarned referralCode level username');

    const cacheKey = `ref:dash:${req.user.id}`;
    const data = await cache.wrap(cacheKey, async () => {
      const [recent, totalPending, recentTx] = await Promise.all([
        Referral.find({ referrer: req.user.id })
          .sort({ createdAt: -1 }).limit(5)
          .populate('referredUser', 'username level createdAt'),
        Transaction.aggregate([
          { $match: { user: req.user._id, type: 'commission', status: 'pending' } },
          { $group: { _id: null, total: { $sum: '$amount' } } }
        ]),
        Transaction.find({ user: req.user.id, type: 'commission' })
          .sort({ createdAt: -1 }).limit(10).select('amount description createdAt')
      ]);
      return { recent, totalPending: totalPending[0]?.total || 0, recentTx };
    }, 60);

    const nextTier = user.getNextTierInfo();
    const claimedMilestones = await ReferralReward.distinct('milestone', { user: user._id });
    const pendingMilestones = MILESTONES.filter(
      m => user.activeReferrals >= m.at && !claimedMilestones.includes(m.at)
    );

    res.json({
      success: true,
      dashboard: {
        tier:            user.tier,
        commissionRate:  `${(user.getCommissionRate() * 100).toFixed(0)}%`,
        referralCode:    user.referralCode,
        referralLink:    `${process.env.CLIENT_URL || 'https://app.mysteryrewards.com'}/join?ref=${user.referralCode}`,
        totalReferrals:  user.referralCount,
        activeReferrals: user.activeReferrals,
        totalEarned:     +user.totalCommissionEarned.toFixed(2),
        pendingCommission: +data.totalPending.toFixed(2),
        cashbackRate:    `${(getCashbackRate(user.level) * 100).toFixed(1)}%`,
        nextTier: nextTier.nextTier ? {
          name:   nextTier.nextTier,
          rate:   `${(nextTier.nextRate * 100).toFixed(0)}%`,
          needed: nextTier.referralsNeeded
        } : null,
        pendingMilestones,
        recentReferrals:  data.recent.map(r => ({
          username:  r.referredUser?.username,
          level:     r.referredUser?.level,
          joinedAt:  r.createdAt,
          isActive:  r.isActive
        })),
        recentCommissions: data.recentTx
      }
    });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// GET /referrals/stats?days=30
exports.getStats = async (req, res) => {
  try {
    const days  = Math.min(parseInt(req.query.days) || 30, 90);
    const stats = await getReferralStats(req.user.id, days);
    res.json({ success: true, days, ...stats });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// GET /referrals/list?page=1&active=true
exports.listReferrals = async (req, res) => {
  try {
    const { page = 1, limit = 20, active } = req.query;
    const query = { referrer: req.user.id };
    if (active !== undefined) query.isActive = active === 'true';
    const skip = (Number(page) - 1) * Number(limit);

    const [referrals, total] = await Promise.all([
      Referral.find(query)
        .populate('referredUser', 'username email level tier totalBoxesOpened createdAt')
        .sort({ totalCommissionEarned: -1 })
        .skip(skip).limit(Number(limit)),
      Referral.countDocuments(query)
    ]);

    res.json({
      success: true,
      count: referrals.length,
      total,
      pages: Math.ceil(total / Number(limit)),
      referrals: referrals.map(r => ({
        username:       r.referredUser?.username,
        level:          r.referredUser?.level,
        tier:           r.referredUser?.tier,
        opens:          r.referredUser?.totalBoxesOpened,
        joinedAt:       r.createdAt,
        isActive:       r.isActive,
        totalSpent:     +r.totalReferredSpent.toFixed(2),
        yourEarnings:   +r.totalCommissionEarned.toFixed(2),
        purchaseCount:  r.purchaseCount,
        firstPurchase:  r.firstPurchaseAt
      }))
    });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// GET /referrals/commissions?page=1
exports.getCommissions = async (req, res) => {
  try {
    const { page = 1, limit = 20, from, to } = req.query;
    const query = { user: req.user.id, type: { $in: ['commission', 'bonus'] } };
    if (from || to) {
      query.createdAt = {};
      if (from) query.createdAt.$gte = new Date(from);
      if (to)   query.createdAt.$lte = new Date(to);
    }
    const skip = (Number(page) - 1) * Number(limit);

    const [txns, total, summary] = await Promise.all([
      Transaction.find(query).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
      Transaction.countDocuments(query),
      Transaction.aggregate([
        { $match: { ...query, status: 'completed' } },
        { $group: {
          _id:   '$method',
          total: { $sum: '$amount' },
          count: { $sum: 1 }
        }}
      ])
    ]);

    const byMethod = {};
    summary.forEach(s => { byMethod[s._id || 'other'] = { total: +s.total.toFixed(2), count: s.count }; });

    res.json({
      success: true,
      count: txns.length, total,
      pages: Math.ceil(total / Number(limit)),
      summary: {
        referral:       byMethod['referral']       || { total: 0, count: 0 },
        referral_l2:    byMethod['referral_l2']    || { total: 0, count: 0 },
        milestone_bonus: byMethod['milestone_bonus'] || { total: 0, count: 0 },
        cashback:       byMethod['cashback']       || { total: 0, count: 0 },
        first_deposit_bonus: byMethod['first_deposit_bonus'] || { total: 0, count: 0 }
      },
      transactions: txns
    });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// GET /referrals/milestones
exports.getMilestones = async (req, res) => {
  try {
    const user    = await User.findById(req.user.id).select('activeReferrals totalCommissionEarned');
    const claimed = await ReferralReward.find({ user: user._id }).sort({ milestone: 1 });
    const claimedSet = new Set(claimed.map(c => c.milestone));

    const milestones = MILESTONES.map(m => ({
      at:         m.at,
      type:       m.type,
      amount:     m.amount,
      label:      m.label,
      status:     claimedSet.has(m.at) ? 'claimed'
                : user.activeReferrals >= m.at ? 'ready'
                : 'locked',
      progress:   Math.min(user.activeReferrals, m.at),
      claimedAt:  claimed.find(c => c.milestone === m.at)?.claimedAt || null
    }));

    // تشغيل check في الخلفية
    checkMilestones(user._id).catch(() => {});

    res.json({ success: true, activeReferrals: user.activeReferrals, milestones });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// GET /referrals/leaderboard?by=commission&limit=20
exports.getLeaderboard = async (req, res) => {
  try {
    const cacheKey = `ref:leaderboard:${req.query.by || 'commission'}`;
    const data = await cache.wrap(cacheKey, async () => {
      const users = await User.find({ role: 'user', isBanned: false, activeReferrals: { $gt: 0 } })
        .select('username avatar tier activeReferrals totalCommissionEarned level')
        .sort({ totalCommissionEarned: -1 })
        .limit(20);
      return users;
    }, 300);

    res.json({
      success: true,
      leaderboard: data.map((u, i) => ({
        rank:            i + 1,
        username:        u.username,
        tier:            u.tier,
        level:           u.level,
        activeReferrals: u.activeReferrals,
        totalEarned:     +u.totalCommissionEarned.toFixed(2),
        rate:            `${(u.getCommissionRate() * 100).toFixed(0)}%`
      }))
    });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// GET /referrals/validate/:code
exports.validateCode = async (req, res) => {
  try {
    const code = req.params.code.toUpperCase();
    const user = await User.findOne({ referralCode: code, isBanned: false })
      .select('username tier activeReferrals level');
    if (!user) return res.json({ success: true, valid: false });
    const rate = user.getCommissionRate();
    res.json({
      success: true,
      valid: true,
      referrer: {
        username:     user.username,
        tier:         user.tier,
        level:        user.level,
        commissionRate: `${(rate * 100).toFixed(0)}%`
      }
    });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};
