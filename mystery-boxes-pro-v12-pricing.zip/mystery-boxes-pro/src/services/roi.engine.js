/**
 * roi.engine.js — v2 (Retail Model)
 *
 * التغييرات من v1:
 *   - حذف: checkDailyWinCap    (حد ربح يومي — ميكانيكية كازينو)
 *   - حذف: meetsMinimumOpens   (حد فتحات قبل epic — ميكانيكية كازينو)
 *   - حذف: adjustProbabilities (كان يتلاعب بالاحتمالات)
 *   - إعادة كتابة: validateBoxPricing للـbuckets
 *   - يبقى: checkStopLoss (أداة إدارية — لا تُعرض للمستخدم)
 *   - يبقى: getBoxROI (تقارير داخلية)
 */

const Order  = require('../models/Order');
const logger = require('../utils/logger');
const { breakdown: priceBreakdown, validateProductCost } = require('./pricing.engine.v2');

const STOP_LOSS_MARGIN = 0.05; // أوقف الصندوق إذا ROI < 5%

// ── حساب متوسط تكلفة الصندوق بناءً على الـbuckets ────────────────────────
// يُستخدم عند إنشاء الصندوق للتحقق من أن الهامش معقول
function computeExpectedCost(items, bucketDistribution) {
  if (!items || items.length === 0) return 0;

  const { A = 50, B = 35, C = 15 } = bucketDistribution || {};
  const totalWeight = A + B + C;

  // متوسط تكلفة كل bucket
  const byBucket = { A: [], B: [], C: [] };
  items.forEach(item => {
    if (byBucket[item.bucket]) byBucket[item.bucket].push(item.supplierCost || 0);
  });

  const avgCost = (bucket, weight) => {
    const arr = byBucket[bucket];
    if (arr.length === 0) return 0;
    const avg = arr.reduce((s, v) => s + v, 0) / arr.length;
    return avg * (weight / totalWeight);
  };

  const expectedCost = avgCost('A', A) + avgCost('B', B) + avgCost('C', C);
  return +expectedCost.toFixed(4);
}

// ── التحقق من أن سعر الصندوق منطقي ──────────────────────────────────────
// يضمن أن جميع المنتجات قيمتها السوقية قريبة من السعر (لا تفاوت كبير)
function validateBoxPricing(boxPrice, items) {
  if (!items || items.length === 0)
    return { valid: false, reason: 'لا توجد منتجات' };

  // احسب الميزانية الصحيحة من محرك التسعير
  const b = priceBreakdown(boxPrice);

  // تحقق من supplierCost كل منتج
  const costViolations = items.filter(i => {
    const v = validateProductCost(i.supplierCost || 0, boxPrice, i.estimatedShipping || 0.9);
    return !v.valid;
  });

  // تحقق من marketValue (شفافية مع المستخدم)
  const { validateMarketValue } = require('./pricing.engine.v2');
  const mvViolations = items.filter(i => {
    const mv = i.marketValue || 0;
    return !validateMarketValue(mv, boxPrice).valid;
  });

  const avgSupplierCost = items.reduce((s,i) => s + (i.supplierCost||0), 0) / items.length;

  return {
    valid:             costViolations.length === 0,
    costViolations:    costViolations.map(i => ({ name: i.name, cost: i.supplierCost, range: { min: b.minSupplierCost, max: b.maxSupplierCost } })),
    mvViolations:      mvViolations.map(i => ({ name: i.name, value: i.marketValue })),
    avgSupplierCost:   +avgSupplierCost.toFixed(2),
    maxSupplierCost:   b.maxSupplierCost,
    minSupplierCost:   b.minSupplierCost,
    targetProfit:      b.targetProfit,
    profitPct:         b.profitPct,
    breakdown:         b,
    reason: costViolations.length > 0
      ? `${costViolations.length} منتج supplierCost خارج الميزانية`
      : 'صالح ✅'
  };
}

// ── حساب transparency للصندوق ─────────────────────────────────────────────
function computeTransparency(boxPrice, items) {
  const active  = items.filter(i => i.isActive !== false && !i.isBonus);
  if (active.length === 0) return {};

  const values  = active.map(i => i.marketValue || 0);
  const minVal  = Math.min(...values);
  const maxVal  = Math.max(...values);
  const avgVal  = values.reduce((s, v) => s + v, 0) / values.length;

  return {
    totalProducts:  active.length,
    minValue:       +minVal.toFixed(2),
    maxValue:       +maxVal.toFixed(2),
    averageValue:   +avgVal.toFixed(2),
    valueGuarantee: `كل منتج بقيمة ${minVal.toFixed(0)}$–${maxVal.toFixed(0)}$ — مضمون`
  };
}

// ── Stop-loss — أداة إدارية داخلية فقط ───────────────────────────────────
// إذا الصندوق يخسر لمدة 3 أيام → يُوقف تلقائياً حتى المراجعة
async function checkStopLoss(box) {
  try {
    const since = new Date(Date.now() - 3 * 24 * 60 * 60 * 1000);
    const stats = await Order.aggregate([
      { $match: { box: box._id, status: 'completed', createdAt: { $gte: since } } },
      { $group: {
        _id:        null,
        revenue:    { $sum: '$price' },
        totalCost:  { $sum: '$totalValue' },
        opens:      { $sum: 1 }
      }}
    ]);

    if (!stats[0] || stats[0].opens < 10) return { triggered: false, reason: 'بيانات غير كافية' };

    const { revenue, totalCost } = stats[0];
    const roi = revenue > 0 ? (revenue - totalCost) / revenue : 0;

    if (roi < STOP_LOSS_MARGIN) {
      await require('../models/Box').findByIdAndUpdate(box._id, { isActive: false });
      logger.warn(`[Stop-loss] "${box.name}" paused — ROI ${(roi*100).toFixed(1)}%`);
      return { triggered: true, roi: +(roi * 100).toFixed(2), boxId: box._id };
    }

    return { triggered: false, roi: +(roi * 100).toFixed(2) };
  } catch (e) {
    logger.error(`Stop-loss error for ${box._id}: ${e.message}`);
    return { triggered: false };
  }
}

// ── تقرير ROI للأدمن ──────────────────────────────────────────────────────
async function getBoxROI(boxId, days = 7) {
  const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
  const [stats, daily] = await Promise.all([
    Order.aggregate([
      { $match: { box: require('mongoose').Types.ObjectId(boxId), status: 'completed', createdAt: { $gte: since } } },
      { $group: {
        _id:       null,
        revenue:   { $sum: '$price' },
        totalCost: { $sum: '$totalValue' },
        opens:     { $sum: 1 },
        avgPrice:  { $avg: '$price' }
      }}
    ]),
    Order.aggregate([
      { $match: { box: require('mongoose').Types.ObjectId(boxId), status: 'completed', createdAt: { $gte: since } } },
      { $group: {
        _id:     { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } },
        revenue: { $sum: '$price' },
        opens:   { $sum: 1 }
      }},
      { $sort: { _id: 1 } }
    ])
  ]);

  const s = stats[0] || { revenue: 0, totalCost: 0, opens: 0 };
  const roi = s.revenue > 0 ? (s.revenue - s.totalCost) / s.revenue : 0;

  return {
    days,
    opens:      s.opens,
    revenue:    +s.revenue.toFixed(2),
    totalCost:  +s.totalCost.toFixed(2),
    profit:     +(s.revenue - s.totalCost).toFixed(2),
    roi:        +(roi * 100).toFixed(2),
    stopLoss:   roi < STOP_LOSS_MARGIN,
    dailyChart: daily
  };
}

module.exports = {
  validateBoxPricing,
  computeExpectedCost,
  computeTransparency,
  checkStopLoss,
  getBoxROI
};
