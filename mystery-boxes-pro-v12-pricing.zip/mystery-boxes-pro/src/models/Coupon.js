const mongoose = require('mongoose');

const couponSchema = new mongoose.Schema({
  code: {
    type: String,
    required: true,
    unique: true,
    uppercase: true,
    trim: true
  },
  type: {
    type: String,
    enum: ['percent', 'flat', 'free_open'],  // percent off, flat $ off, free box open
    required: true
  },
  value: { type: Number, required: true, min: 0 }, // % or $ amount
  maxUses: { type: Number, default: -1 },           // -1 = unlimited
  usedCount: { type: Number, default: 0 },
  usedBy: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],

  // Restrictions
  minPurchase: { type: Number, default: 0 },
  applicableBoxes: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Box' }], // empty = all boxes
  applicableBoxTypes: [{ type: String, enum: ['digital', 'gaming', 'physical'] }],

  // Validity
  validFrom: { type: Date, default: Date.now },
  validUntil: { type: Date },
  isActive: { type: Boolean, default: true },

  description: { type: String },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
}, { timestamps: true });

// Check if coupon is currently valid
couponSchema.methods.isValid = function (userId, boxPrice, boxId) {
  const now = new Date();
  if (!this.isActive) return { valid: false, reason: 'Coupon is inactive' };
  if (this.validUntil && now > this.validUntil) return { valid: false, reason: 'Coupon has expired' };
  if (now < this.validFrom) return { valid: false, reason: 'Coupon not yet active' };
  if (this.maxUses !== -1 && this.usedCount >= this.maxUses) return { valid: false, reason: 'Coupon usage limit reached' };
  if (this.usedBy.some(id => id.equals(userId))) return { valid: false, reason: 'You have already used this coupon' };
  if (boxPrice < this.minPurchase) return { valid: false, reason: `Minimum purchase $${this.minPurchase} required` };
  if (this.applicableBoxes.length > 0 && !this.applicableBoxes.some(id => id.equals(boxId))) {
    return { valid: false, reason: 'Coupon not valid for this box' };
  }
  return { valid: true };
};

// Calculate discounted price
couponSchema.methods.applyDiscount = function (originalPrice) {
  if (this.type === 'percent') return Math.max(0, originalPrice - (originalPrice * this.value / 100));
  if (this.type === 'flat')    return Math.max(0, originalPrice - this.value);
  if (this.type === 'free_open') return 0;
  return originalPrice;
};

module.exports = mongoose.model('Coupon', couponSchema);
