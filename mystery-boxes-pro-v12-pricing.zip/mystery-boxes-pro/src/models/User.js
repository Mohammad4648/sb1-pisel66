const mongoose = require('mongoose');
const bcrypt   = require('bcryptjs');
const jwt      = require('jsonwebtoken');
const crypto   = require('crypto');

const userSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true, trim: true, minlength: 3, maxlength: 30 },
  email:    { type: String, required: true, unique: true, lowercase: true, trim: true },
  password: { type: String, required: true, minlength: 6, select: false },
  fullName: { type: String, trim: true },
  avatar:   { type: String, default: 'default-avatar.png' },
  role:     { type: String, enum: ['user', 'admin', 'moderator'], default: 'user' },

  // ── Wallet ────────────────────────────────────────────────────────────────
  walletBalance:    { type: Number, default: 0, min: 0 },
  lockedBalance:    { type: Number, default: 0, min: 0 }, // locked in pending withdrawals
  walletId: {
    type: String, unique: true,
    default: () => 'WALLET-' + crypto.randomBytes(5).toString('hex').toUpperCase()
  },
  totalSpent:       { type: Number, default: 0 },
  totalEarned:      { type: Number, default: 0 },
  totalWithdrawn:   { type: Number, default: 0 },
  totalDeposited:   { type: Number, default: 0 },
  walletPinEnabled: { type: Boolean, default: false },
  dailyWithdrawLimit:   { type: Number, default: 500 },
  monthlyWithdrawLimit: { type: Number, default: 5000 },

  // ── Referral ──────────────────────────────────────────────────────────────
  referralCode: {
    type: String, unique: true,
    default: () => 'REF-' + crypto.randomBytes(3).toString('hex').toUpperCase()
  },
  referredBy:              { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  referralCount:           { type: Number, default: 0 },
  activeReferrals:         { type: Number, default: 0 },
  totalCommissionEarned:   { type: Number, default: 0 },
  pendingCommission:       { type: Number, default: 0 },
  lifetimeReferralRevenue: { type: Number, default: 0 },

  // ── Tier ─────────────────────────────────────────────────────────────────
  // bronze: 0-4 referrals   → 5%
  // silver: 5-19            → 10%
  // gold:   20-49           → 15%
  // diamond:50-99           → 20%
  // vip:    100+            → 25% + extras
  tier: {
    type: String,
    enum: ['bronze', 'silver', 'gold', 'diamond', 'vip'],
    default: 'bronze'
  },

  // ── Status ────────────────────────────────────────────────────────────────
  isVerified:  { type: Boolean, default: false },
  isActive:    { type: Boolean, default: true },
  isBanned:    { type: Boolean, default: false },
  lastLogin:   { type: Date },
  lastLoginIP: { type: String },

  // ── Stats ─────────────────────────────────────────────────────────────────
  totalBoxesOpened: { type: Number, default: 0 },
  trialBoxOpened:   { type: Boolean, default: false },
  sadaqaEnabled:    { type: Boolean, default: false }, // خاصية الصدقة — تقريب تلقائي
  totalSadaqa:      { type: Number,  default: 0 },    // إجمالي ما تصدّق به // فتح الصندوق التجريبي 1$
  totalWon:         { type: Number, default: 0 },  // total value of prizes won

  // ── Level system ──────────────────────────────────────────────────────────
  xp:    { type: Number, default: 0 },
  level: { type: Number, default: 1 },

  // ── Anti-fraud ────────────────────────────────────────────────────────────
  registrationIP:     { type: String },
  deviceFingerprints: [{ type: String }],
  fraudScore:         { type: Number, default: 0 },
  isFlaggedForFraud:  { type: Boolean, default: false },

  // ── Security ──────────────────────────────────────────────────────────────
  passwordResetToken:       String,
  passwordResetExpires:     Date,
  emailVerificationToken:   String,
  emailVerificationExpires: Date,

  // ── Settings ──────────────────────────────────────────────────────────────
  settings: {
    emailNotifications: { type: Boolean, default: true },
    language:  { type: String, default: 'ar', enum: ['ar', 'en'] },
    currency:  { type: String, default: 'USD' },
    autoWithdraw:        { type: Boolean, default: false },
    autoWithdrawThreshold: { type: Number, default: 100 }
  }
}, { timestamps: true, toJSON: { virtuals: true }, toObject: { virtuals: true } });

// ── Indexes ───────────────────────────────────────────────────────────────────
userSchema.index({ referralCode: 1 });
userSchema.index({ referredBy: 1 });
userSchema.index({ tier: 1 });

// ── Pre-save: hash password ────────────────────────────────────────────────────
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 12);
  next();
});

// ── Auth methods ───────────────────────────────────────────────────────────────
userSchema.methods.comparePassword = async function (pwd) {
  return bcrypt.compare(pwd, this.password);
};

userSchema.methods.generateAuthToken = function () {
  return jwt.sign({ id: this._id, role: this.role }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRE || '7d'
  });
};

// ── Tier calculation ───────────────────────────────────────────────────────────
// Based on activeReferrals (referrals who made ≥1 purchase) not just count
const TIER_THRESHOLDS = { bronze: 0, silver: 5, gold: 20, diamond: 50, vip: 100 };
const COMMISSION_RATES = { bronze: 0.05, silver: 0.10, gold: 0.15, diamond: 0.20, vip: 0.25 };

userSchema.methods.updateTier = function () {
  const n = this.activeReferrals;
  if      (n >= TIER_THRESHOLDS.vip)     this.tier = 'vip';
  else if (n >= TIER_THRESHOLDS.diamond) this.tier = 'diamond';
  else if (n >= TIER_THRESHOLDS.gold)    this.tier = 'gold';
  else if (n >= TIER_THRESHOLDS.silver)  this.tier = 'silver';
  else                                   this.tier = 'bronze';
};

userSchema.methods.getCommissionRate = function () {
  return COMMISSION_RATES[this.tier] || 0.05;
};

userSchema.methods.getNextTierInfo = function () {
  const tiers  = ['bronze', 'silver', 'gold', 'diamond', 'vip'];
  const idx    = tiers.indexOf(this.tier);
  if (idx === tiers.length - 1) return { nextTier: null, referralsNeeded: 0 };
  const next   = tiers[idx + 1];
  return {
    nextTier:         next,
    nextRate:         COMMISSION_RATES[next],
    activeReferrals:  this.activeReferrals,
    referralsNeeded:  TIER_THRESHOLDS[next] - this.activeReferrals
  };
};

// ── Wallet methods ─────────────────────────────────────────────────────────────
userSchema.methods.addToWallet = async function (amount, session = null) {
  this.walletBalance += amount;
  this.totalEarned   += amount;
  return session ? this.save({ session }) : this.save();
};

userSchema.methods.subtractFromWallet = async function (amount, session = null) {
  if (this.walletBalance < amount) throw new Error('Insufficient balance');
  this.walletBalance -= amount;
  this.totalSpent    += amount;
  return session ? this.save({ session }) : this.save();
};

// Available balance = walletBalance - lockedBalance
userSchema.virtual('availableBalance').get(function () {
  return Math.max(0, this.walletBalance - this.lockedBalance);
});

// ── XP / Level ────────────────────────────────────────────────────────────────
userSchema.methods.xpForNextLevel = function () { return this.level * 100; };
userSchema.methods.addXP = function (points) {
  this.xp += points;
  while (this.xp >= this.xpForNextLevel()) {
    this.xp   -= this.xpForNextLevel();
    this.level = Math.min(this.level + 1, 100);
  }
};
// lootBonus: محذوف — زيادة "الحظ" مقابل المستوى تُعدّ غرراً أو مقامرة
// البديل الحلال: خصم ولاء على سعر الصندوق (خصم على السلعة لا على الاحتمال)
userSchema.virtual('loyaltyDiscount').get(function () {
  // خصم 0.5% لكل 10 مستويات، بحد أقصى 5% عند المستوى 100
  // هذا خصم تجاري مشروع — مثل بطاقة الولاء في المتاجر
  return Math.min(Math.floor((this.level - 1) / 10) * 0.005, 0.05);
});

// ── Password reset ────────────────────────────────────────────────────────────
userSchema.methods.createPasswordResetToken = function () {
  const token = crypto.randomBytes(32).toString('hex');
  this.passwordResetToken   = crypto.createHash('sha256').update(token).digest('hex');
  this.passwordResetExpires = Date.now() + 10 * 60 * 1000;
  return token;
};

module.exports = mongoose.model('User', userSchema);
module.exports.TIER_THRESHOLDS   = TIER_THRESHOLDS;
module.exports.COMMISSION_RATES  = COMMISSION_RATES;
