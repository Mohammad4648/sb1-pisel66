const express = require('express');
const router  = express.Router();
const ev      = require('../controllers/event.controller');
const { protect, authorize } = require('../middleware/auth.middleware');

// Public
router.get('/active', ev.getActiveEvent);

// Admin
router.use(protect, authorize('admin'));
router.get('/',              ev.listEvents);
router.post('/',             ev.createEvent);
router.put('/:id',           ev.updateEvent);
router.delete('/:id',        ev.deleteEvent);
router.post('/:id/activate', ev.activateEvent);
router.post('/:id/deactivate', ev.deactivateEvent);

module.exports = router;
