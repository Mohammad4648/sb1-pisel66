/**
 * catalog.pipeline.js — Pipeline استيراد مركزي
 *
 * يُشغَّل يدوياً من الأدمن أو تلقائياً كل 24 ساعة
 *
 * الخطوات:
 *   1. استيراد من CJ Dropshipping
 *   2. استيراد من AliExpress
 *   3. فلترة: حذف خارج النطاق الشرعي (85%–115% من سعر الصندوق)
 *   4. فلترة: حذف المنتجات الحرام
 *   5. إزالة المكررات (بالاسم المتشابه)
 *   6. ترتيب تلقائي للـselectionWeight حسب التقييم
 *   7. تقرير نهائي
 *
 * الاستخدام:
 *   node src/import/catalog.pipeline.js --run
 *   أو من الأدمن: POST /admin/catalog/import/run
 */

const mongoose = require('mongoose');
const CatalogItem = require('../models/CatalogItem');
const { catalogFilter: getPriceFilter } = require('../services/pricing.engine.v2');
const cj          = require('./cj.importer');
const ae          = require('./aliexpress.importer');
const { validateItemHalal } = require('../services/halal.service');
const logger      = require('../utils/logger');

// ── خطة الاستيراد لكل صندوق ──────────────────────────────────────────────
const IMPORT_PLAN = [

  // ① Daily Tech Box — 6.99$
  // النطاق: مُحسَّب تلقائياً من pricing.engine.v2
  // يشمل: ربح 22% + إحالة 8% + مطورين 5% + CS
  // الهدف: 3000+ منتج إلكترونيات
  {
    box:      'tech',
    boxPrice: 6.99,
    targetCount: 3000,
    jobs: [
      { source: 'cj', method: 'importByCategory', arg: 'Phone Accessories',   limit: 500 },
      { source: 'cj', method: 'importByCategory', arg: 'Electronics',         limit: 500 },
      { source: 'cj', method: 'importByCategory', arg: 'Computer & Office',   limit: 500 },
      { source: 'ae', method: 'importByKeyword',  arg: 'phone accessories',   limit: 600 },
      { source: 'ae', method: 'importByKeyword',  arg: 'usb gadgets',         limit: 400 },
      { source: 'ae', method: 'importByKeyword',  arg: 'bluetooth earphone',  limit: 300 },
      { source: 'ae', method: 'importByKeyword',  arg: 'laptop stand',        limit: 200 },
    ]
  },

  // ② Study & Creativity Box — 5.49$
  // النطاق الشرعي: 4.67$–6.31$
  // الهدف: 2000+ منتج قرطاسية/إبداع
  {
    box:      'study',
    boxPrice: 5.49,
    targetCount: 2000,
    jobs: [
      { source: 'cj', method: 'importByCategory', arg: 'Office & School',     limit: 500 },
      { source: 'cj', method: 'importByCategory', arg: 'Toys & Hobbies',      limit: 400 },
      { source: 'ae', method: 'importByKeyword',  arg: 'stationery set',      limit: 400 },
      { source: 'ae', method: 'importByKeyword',  arg: 'notebook journal',    limit: 300 },
      { source: 'ae', method: 'importByKeyword',  arg: 'art supplies',        limit: 300 },
      { source: 'ae', method: 'importByKeyword',  arg: 'rubik cube puzzle',   limit: 200 },
    ]
  },

  // ③ Golden Box — 49.99$
  // النطاق الشرعي: 42.49$–57.49$
  // الهدف: 1500+ منتج فاخر
  {
    box:      'golden',
    boxPrice: 49.99,
    targetCount: 1500,
    jobs: [
      { source: 'cj', method: 'importByCategory', arg: 'Smart Devices',       limit: 300 },
      { source: 'cj', method: 'importByCategory', arg: 'Bags & Shoes',        limit: 300 },
      { source: 'ae', method: 'importByKeyword',  arg: 'smartwatch fitness',  limit: 300 },
      { source: 'ae', method: 'importByKeyword',  arg: 'wireless headphones', limit: 300 },
      { source: 'ae', method: 'importByKeyword',  arg: 'portable speaker',    limit: 200 },
      { source: 'ae', method: 'importByKeyword',  arg: 'gaming keyboard',     limit: 200 },
    ]
  },

  // ④ Trial Box — 1.00$ (رقمي — لا يحتاج استيراد)
];

// ── تشغيل Pipeline ─────────────────────────────────────────────────────────
async function runPipeline(options = {}) {
  const {
    sources = ['cj', 'ae'], // أي مصادر تُشغَّل
    boxes   = ['tech', 'study', 'golden'],
    dryRun  = false,
  } = options;

  const report = {
    startedAt: new Date(),
    boxes: {},
    total: { fetched: 0, imported: 0, haram: 0, outOfRange: 0, skipped: 0 },
  };

  for (const plan of IMPORT_PLAN) {
    if (!boxes.includes(plan.box)) continue;

    const boxReport = { jobs: [] };
    logger.info(`\n═══ Pipeline: "${plan.box}" box ($${plan.boxPrice}) ═══`);

    for (const job of plan.jobs) {
      if (!sources.includes(job.source)) continue;

      logger.info(`  ↳ ${job.source.toUpperCase()} | ${job.arg} | limit=${job.limit}`);

      if (dryRun) {
        boxReport.jobs.push({ ...job, status: 'dry_run' });
        continue;
      }

      try {
        let stats;
        const importer = job.source === 'cj' ? cj : ae;
        const method   = importer[job.method];

        if (!method) {
          logger.warn(`  ⚠️ method "${job.method}" not found in ${job.source}`);
          continue;
        }

        stats = await method(job.arg, { boxPrice: plan.boxPrice, limit: job.limit });

        boxReport.jobs.push({ ...job, stats });
        report.total.fetched    += stats.fetched    || 0;
        report.total.imported   += stats.imported   || 0;
        report.total.haram      += stats.haram      || 0;
        report.total.outOfRange += stats.outOfRange || 0;
        report.total.skipped    += stats.skipped    || 0;

        logger.info(`     ✅ imported=${stats.imported} haram=${stats.haram} outOfRange=${stats.outOfRange}`);

      } catch (e) {
        logger.error(`  ❌ ${job.source} ${job.arg}: ${e.message}`);
        boxReport.jobs.push({ ...job, error: e.message });
      }

      // استراحة بين الوظائف
      await new Promise(r => setTimeout(r, 1000));
    }

    report.boxes[plan.box] = boxReport;
  }

  // ── مرحلة الفلترة النهائية ───────────────────────────────────────────────
  if (!dryRun) {
    logger.info('\n═══ مرحلة الفلترة النهائية ═══');
    const cleaned = await cleanCatalog();
    report.cleanup = cleaned;
  }

  report.finishedAt = new Date();
  report.duration   = Math.round((report.finishedAt - report.startedAt) / 1000) + 's';

  logger.info(`\n✅ Pipeline اكتمل في ${report.duration}`);
  logger.info(`   الإجمالي: مُستورَد=${report.total.imported} حرام=${report.total.haram} خارج_النطاق=${report.total.outOfRange}`);

  return report;
}

// ── تنظيف الكتالوج ────────────────────────────────────────────────────────
async function cleanCatalog() {
  const stats = { removedHaram: 0, removedShort: 0, weightUpdated: 0 };

  // 1. حذف منتجات ظهر أنها حرام
  const haram = await CatalogItem.find({ isActive: true }).select('name description category');
  for (const item of haram) {
    const check = validateItemHalal(item);
    if (!check.halal) {
      await CatalogItem.findByIdAndUpdate(item._id, { isActive: false, halalRejected: true, halalNote: check.violations.join(', ') });
      stats.removedHaram++;
    }
  }

  // 2. حذف منتجات بأسماء قصيرة جداً (< 5 أحرف) = بيانات سيئة
  const removed = await CatalogItem.updateMany(
    { name: { $regex: /^.{1,4}$/ } },
    { $set: { isActive: false } }
  );
  stats.removedShort = removed.modifiedCount;

  // 3. تحديث selectionWeight بناءً على avgRating
  const items = await CatalogItem.find({ isActive: true, avgRating: { $gt: 0 } });
  for (const item of items) {
    const w = Math.min(100, Math.round(item.avgRating * 20));
    if (w !== item.selectionWeight) {
      await CatalogItem.findByIdAndUpdate(item._id, { selectionWeight: w });
      stats.weightUpdated++;
    }
  }

  logger.info(`cleanCatalog: ${JSON.stringify(stats)}`);
  return stats;
}

// ── مزامنة أسعار من المصادر ────────────────────────────────────────────────
async function syncAllPrices() {
  const [cjResult, aeResult] = await Promise.allSettled([
    cj.syncPrices(),
    ae.syncPrices(),
  ]);
  return {
    cj: cjResult.status === 'fulfilled' ? cjResult.value : { error: cjResult.reason?.message },
    ae: aeResult.status === 'fulfilled' ? aeResult.value : { error: aeResult.reason?.message },
  };
}

// ── تشغيل مباشر من CLI ──────────────────────────────────────────────────────
if (process.argv.includes('--run')) {
  require('dotenv').config();
  mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/mystery-boxes-pro')
    .then(() => runPipeline())
    .then(r => { console.log('\n📊 التقرير:'); console.log(JSON.stringify(r, null, 2)); process.exit(0); })
    .catch(e => { console.error(e); process.exit(1); });
}

module.exports = { runPipeline, cleanCatalog, syncAllPrices, IMPORT_PLAN };
