const express = require('express');
const router  = express.Router();
const c       = require('../controllers/compliance.controller');
const { protect, authorize } = require('../middleware/auth.middleware');

router.use(protect, authorize('admin'));

router.get('/halal',          c.getHalalCompliance);
router.get('/financials',     c.getFinancials);
router.get('/box/:id',        c.auditBox);
router.post('/audit-item',    c.auditItem);
router.post('/audit-box',     c.auditBoxPreview);

module.exports = router;
