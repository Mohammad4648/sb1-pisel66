/**
 * wallet.controller.js — v2
 *
 * التحسينات:
 *   - getWallet: رصيد متاح + مقفل + حدود السحب + إحصائيات كاملة
 *   - getTransactions: فلتر شامل + ملخص حسب نوع المعاملة
 *   - getWalletSummary: بيانات رسم بياني 7/30/90 يوم
 *   - withdraw: حدود يومية/شهرية + رسوم حسب الطريقة + PIN + WithdrawalRequest
 *   - cancelWithdrawal: إلغاء + إعادة تحرير الرصيد المقفل
 *   - setPin / removePin: حماية 4-رقم للسحب والتحويل
 *   - transfer: تحويل محفظة-لمحفظة مع PIN
 *   - Admin: قائمة/موافقة/رفض/إتمام طلبات السحب
 */

const { } = require('../services/referral.service'); // firstDepositBonus محذوف — halal compliance
const { getServiceFee } = require('../services/halal.service');
const notify = require('../services/notify.service');
const bcrypt = require('bcryptjs');
const User              = require('../models/User');
const Transaction       = require('../models/Transaction');
const WithdrawalRequest = require('../models/WithdrawalRequest');
const WalletPin         = require('../models/WalletPin');
const { createBinancePayOrder, verifyBinanceWebhook } = require('../services/crypto.payment');
const { withTransaction } = require('../config/db.transaction');
const { v4: uuidv4 }    = require('uuid');
const logger            = require('../utils/logger');

// ── ثوابت ──────────────────────────────────────────────────────────────────
// WITHDRAWAL_FEES: نُقلت لـ halal.service كـ SERVICE_FEES (مع تبرير شرعي لكل رسوم)
const MIN_WITHDRAWAL  = 5;
const AUTO_APPROVE_MAX = 100;

// ── مساعد: استهلاك حدود السحب ─────────────────────────────────────────────
async function calcWithdrawUsage(userId) {
  const now        = new Date();
  const todayStart = new Date(now); todayStart.setHours(0, 0, 0, 0);
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  const [daily, monthly] = await Promise.all([
    WithdrawalRequest.aggregate([
      { $match: { user: userId, status: { $in: ['pending','approved','processing'] }, createdAt: { $gte: todayStart } } },
      { $group: { _id: null, total: { $sum: '$amount' } } }
    ]),
    WithdrawalRequest.aggregate([
      { $match: { user: userId, status: { $in: ['pending','approved','processing','completed'] }, createdAt: { $gte: monthStart } } },
      { $group: { _id: null, total: { $sum: '$amount' } } }
    ])
  ]);
  return { dailyUsed: daily[0]?.total || 0, monthlyUsed: monthly[0]?.total || 0 };
}

// ── مساعد: التحقق من PIN ───────────────────────────────────────────────────
async function checkPin(user, pin) {
  if (!user.walletPinEnabled) return true;
  if (!pin) throw new Error('PIN المحفظة مطلوب');
  const pinDoc = await WalletPin.findOne({ user: user._id });
  if (!pinDoc) throw new Error('لم يتم إعداد PIN');
  return pinDoc.verifyPin(pin);
}

// ════════════════════════════════════════════════════════════════════════════
// GET /wallet
// ════════════════════════════════════════════════════════════════════════════
exports.getWallet = async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select(
      'walletBalance lockedBalance walletId totalSpent totalEarned totalWithdrawn totalDeposited walletPinEnabled dailyWithdrawLimit monthlyWithdrawLimit'
    );
    const { dailyUsed, monthlyUsed } = await calcWithdrawUsage(user._id);
    const pending = await WithdrawalRequest.find({
      user: user._id, status: { $in: ['pending','approved','processing'] }
    }).sort({ createdAt: -1 }).limit(5).select('amount method status createdAt');

    res.json({
      success: true,
      wallet: {
        balance:          +user.walletBalance.toFixed(4),
        lockedBalance:    +user.lockedBalance.toFixed(4),
        availableBalance: +Math.max(0, user.walletBalance - user.lockedBalance).toFixed(4),
        walletId:         user.walletId,
        pinEnabled:       user.walletPinEnabled,
        stats: {
          totalSpent:     +user.totalSpent.toFixed(2),
          totalEarned:    +user.totalEarned.toFixed(2),
          totalWithdrawn: +user.totalWithdrawn.toFixed(2),
          totalDeposited: +user.totalDeposited.toFixed(2),
          netProfit:      +(user.totalEarned - user.totalSpent).toFixed(2)
        },
        limits: {
          daily:       user.dailyWithdrawLimit,
          dailyUsed:   +dailyUsed.toFixed(2),
          dailyLeft:   +Math.max(0, user.dailyWithdrawLimit - dailyUsed).toFixed(2),
          monthly:     user.monthlyWithdrawLimit,
          monthlyUsed: +monthlyUsed.toFixed(2),
          monthlyLeft: +Math.max(0, user.monthlyWithdrawLimit - monthlyUsed).toFixed(2)
        },
        serviceFees: require('../services/halal.service').SERVICE_FEES,
        feeNote: 'الرسوم هي أجرة خدمة مقابل معالجة الدفع — لا فوائد ربوية',
        pendingWithdrawals: pending
      }
    });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ════════════════════════════════════════════════════════════════════════════
// GET /wallet/transactions
// ════════════════════════════════════════════════════════════════════════════
exports.getTransactions = async (req, res) => {
  try {
    const { page = 1, limit = 20, type, status, from, to } = req.query;
    const query = { user: req.user.id };
    if (type)   query.type   = type;
    if (status) query.status = status;
    if (from || to) {
      query.createdAt = {};
      if (from) query.createdAt.$gte = new Date(from);
      if (to)   query.createdAt.$lte = new Date(to);
    }
    const skip = (Number(page) - 1) * Number(limit);
    const [transactions, total, summary] = await Promise.all([
      Transaction.find(query).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
      Transaction.countDocuments(query),
      Transaction.aggregate([
        { $match: { user: req.user._id, status: 'completed' } },
        { $group: { _id: '$type', total: { $sum: { $abs: '$amount' } }, count: { $sum: 1 } } }
      ])
    ]);
    const summaryMap = {};
    summary.forEach(s => { summaryMap[s._id] = { total: +s.total.toFixed(2), count: s.count }; });
    res.json({ success: true, count: transactions.length, total, pages: Math.ceil(total / Number(limit)), transactions, summary: summaryMap });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ════════════════════════════════════════════════════════════════════════════
// GET /wallet/summary — بيانات الرسم البياني
// ════════════════════════════════════════════════════════════════════════════
exports.getWalletSummary = async (req, res) => {
  try {
    const days  = Math.min(parseInt(req.query.days) || 30, 90);
    const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
    const data  = await Transaction.aggregate([
      { $match: { user: req.user._id, status: 'completed', createdAt: { $gte: since } } },
      { $group: {
        _id:   { date: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } }, type: '$type' },
        total: { $sum: { $abs: '$amount' } }
      }},
      { $sort: { '_id.date': 1 } }
    ]);
    const byDate = {};
    data.forEach(d => {
      const { date, type } = d._id;
      if (!byDate[date]) byDate[date] = { date, deposit: 0, withdrawal: 0, purchase: 0, commission: 0, bonus: 0 };
      if (byDate[date][type] !== undefined) byDate[date][type] = +d.total.toFixed(4);
    });
    res.json({ success: true, days, chart: Object.values(byDate) });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ════════════════════════════════════════════════════════════════════════════
// POST /wallet/deposit — إيداع يدوي
// ════════════════════════════════════════════════════════════════════════════
exports.deposit = async (req, res) => {
  try {
    const { amount } = req.body;
    if (!amount || amount <= 0) return res.status(400).json({ success: false, message: 'مبلغ غير صالح' });
    // firstDepositBonus: محذوف — halal compliance
    const firstDepositBonus = null;
    await withTransaction(async (session) => {
      const user   = await User.findById(req.user.id).session(session);
      const before = user.walletBalance;
      // مكافأة أول إيداع (قبل تحديث totalDeposited)
      // processFirstDepositBonus: محذوف
      user.walletBalance  += amount;
      user.totalEarned    += amount;
      user.totalDeposited += amount;
      await user.save({ session });
      await Transaction.create([{
        user: user._id, type: 'deposit', amount,
        balanceBefore: before, balanceAfter: user.walletBalance,
        description: `إيداع يدوي – $${amount}`, status: 'completed', method: 'manual'
      }], { session });
    });
    const updated = await User.findById(req.user.id).select('walletBalance');
    notify.depositConfirmed(req.user.id, amount, 'إيداع يدوي').catch(() => {});
    res.json({
      success: true, message: 'تم الإيداع بنجاح',
      newBalance: +updated.walletBalance.toFixed(4),
      firstDepositBonus
    });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ════════════════════════════════════════════════════════════════════════════
// POST /wallet/deposit/crypto — Binance Pay
// ════════════════════════════════════════════════════════════════════════════
exports.initiateCryptoDeposit = async (req, res) => {
  try {
    const { amount } = req.body;
    if (!amount || amount < 1) return res.status(400).json({ success: false, message: 'الحد الأدنى للإيداع $1' });
    const orderId = `DEP-${uuidv4().split('-')[0].toUpperCase()}-${Date.now()}`;
    const user    = await User.findById(req.user.id).select('walletBalance');
    const result  = await createBinancePayOrder(amount, orderId, req.user.id);
    if (!result.success) return res.status(500).json({ success: false, message: result.error });
    await Transaction.create({
      user: req.user.id, type: 'deposit', amount,
      balanceBefore: user.walletBalance, balanceAfter: user.walletBalance,
      description: `إيداع كريبتو – $${amount}`, status: 'pending',
      reference: orderId, method: 'binance_pay',
      metadata: { prepayId: result.prepayId, mock: result.mock || false }
    });
    res.json({ success: true, orderId, amount, checkoutUrl: result.checkoutUrl, prepayId: result.prepayId });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ════════════════════════════════════════════════════════════════════════════
// POST /wallet/webhook/binance — idempotent
// ════════════════════════════════════════════════════════════════════════════
exports.binancePayWebhook = async (req, res) => {
  try {
    if (!verifyBinanceWebhook(req)) return res.status(401).json({ success: false, message: 'Invalid signature' });
    const { bizType, data } = req.body;
    if (bizType !== 'PAY' || data?.status !== 'PAY_SUCCESS')
      return res.status(200).json({ returnCode: 'SUCCESS', returnMessage: null });
    const txn = await Transaction.findOneAndUpdate(
      { 'metadata.prepayId': data.prepayId, status: 'pending', type: 'deposit' },
      { $set: { status: 'processing' } },
      { new: false }
    );
    if (!txn) return res.status(200).json({ returnCode: 'SUCCESS', returnMessage: null });
    await withTransaction(async (session) => {
      const user  = await User.findById(txn.user).session(session);
      const before = user.walletBalance;
      // مكافأة أول إيداع
      await processFirstDepositBonus(user._id, txn.amount, session);
      user.walletBalance  += txn.amount;
      user.totalEarned    += txn.amount;
      user.totalDeposited += txn.amount;
      await user.save({ session });
      await Transaction.findByIdAndUpdate(txn._id, {
        $set: { status: 'completed', balanceBefore: before, balanceAfter: before + txn.amount }
      }, { session });
    });
    res.status(200).json({ returnCode: 'SUCCESS', returnMessage: null });
    // إشعار خارج الـresponse
    notify.depositConfirmed(txn.user, txn.amount, 'Binance Pay').catch(() => {});
    if (req.body?.data?.prepayId)
      await Transaction.findOneAndUpdate(
        { 'metadata.prepayId': req.body.data.prepayId, status: 'processing' },
        { $set: { status: 'pending' } }
      ).catch(() => {});
    res.status(500).json({ returnCode: 'FAIL', returnMessage: e.message });
  }
};

// ════════════════════════════════════════════════════════════════════════════
// POST /wallet/withdraw
// ════════════════════════════════════════════════════════════════════════════
exports.withdraw = async (req, res) => {
  try {
    const { amount, method = 'crypto_usdt', address, network, pin } = req.body;
    if (!amount || amount < MIN_WITHDRAWAL)
      return res.status(400).json({ success: false, message: `الحد الأدنى للسحب $${MIN_WITHDRAWAL}` });
    if (!address)
      return res.status(400).json({ success: false, message: 'عنوان المحفظة / الحساب مطلوب' });

    const user = await User.findById(req.user.id);

    // PIN
    try { const ok = await checkPin(user, pin); if (!ok) return res.status(401).json({ success: false, message: 'PIN غير صحيح' }); }
    catch (e) { return res.status(401).json({ success: false, message: e.message }); }

    // رصيد متاح
    const available = user.walletBalance - user.lockedBalance;
    if (available < amount)
      return res.status(400).json({ success: false, message: `الرصيد المتاح $${available.toFixed(2)} فقط` });

    // حدود السحب
    const { dailyUsed, monthlyUsed } = await calcWithdrawUsage(user._id);
    if (dailyUsed + amount > user.dailyWithdrawLimit)
      return res.status(400).json({ success: false, message: `تجاوزت الحد اليومي. المتاح: $${(user.dailyWithdrawLimit - dailyUsed).toFixed(2)}` });
    if (monthlyUsed + amount > user.monthlyWithdrawLimit)
      return res.status(400).json({ success: false, message: `تجاوزت الحد الشهري. المتاح: $${(user.monthlyWithdrawLimit - monthlyUsed).toFixed(2)}` });

    // رسوم
    const serviceFee = getServiceFee(method, amount);
    const feeRate    = serviceFee.rate;
    const fee        = serviceFee.amount;
    const netAmount  = +(amount - fee).toFixed(4);
    const autoApprove = amount <= AUTO_APPROVE_MAX;

    let withdrawal;
    await withTransaction(async (session) => {
      await User.findByIdAndUpdate(user._id, { $inc: { lockedBalance: amount } }, { session });
      [withdrawal] = await WithdrawalRequest.create([{
        user: user._id, amount, method, address,
        network: network || null, fee, netAmount,
        status: autoApprove ? 'approved' : 'pending',
        autoApproved: autoApprove, ipAddress: req.ip
      }], { session });
      await Transaction.create([{
        user: user._id, type: 'withdrawal', amount: -amount, fee, netAmount: -netAmount,
        balanceBefore: user.walletBalance, balanceAfter: user.walletBalance - amount,
        description: `طلب سحب ${method} – $${amount}`,
        status: 'pending', method, relatedWithdrawal: withdrawal._id
      }], { session });
    });

    logger.info(`Withdrawal: ${user.username} $${amount} via ${method} auto=${autoApprove}`);
    res.json({
      success: true,
      message: autoApprove
        ? 'تمت الموافقة التلقائية — سيُحوَّل المبلغ خلال 24 ساعة'
        : 'طلب السحب تحت المراجعة — ستُخطَر عند المعالجة',
      withdrawal: {
        id: withdrawal._id, amount,
        fee: +fee.toFixed(4), netAmount: +netAmount.toFixed(4),
        feePercent: `${(feeRate * 100).toFixed(1)}%`,
        method, status: withdrawal.status, autoApproved: autoApprove
      }
    });
  } catch (e) {
    logger.error('Withdraw error:', e.message);
    res.status(500).json({ success: false, message: e.message });
  }
};

// ════════════════════════════════════════════════════════════════════════════
// GET /wallet/withdrawals
// ════════════════════════════════════════════════════════════════════════════
exports.getWithdrawals = async (req, res) => {
  try {
    const { page = 1, limit = 20, status } = req.query;
    const query = { user: req.user.id };
    if (status) query.status = status;
    const skip = (Number(page) - 1) * Number(limit);
    const [withdrawals, total] = await Promise.all([
      WithdrawalRequest.find(query).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
      WithdrawalRequest.countDocuments(query)
    ]);
    res.json({ success: true, count: withdrawals.length, total, withdrawals });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ════════════════════════════════════════════════════════════════════════════
// DELETE /wallet/withdrawals/:id — إلغاء طلب معلّق
// ════════════════════════════════════════════════════════════════════════════
exports.cancelWithdrawal = async (req, res) => {
  try {
    const wd = await WithdrawalRequest.findOne({ _id: req.params.id, user: req.user.id });
    if (!wd) return res.status(404).json({ success: false, message: 'الطلب غير موجود' });
    if (wd.status !== 'pending')
      return res.status(400).json({ success: false, message: `لا يمكن إلغاء طلب بحالة "${wd.status}"` });

    await withTransaction(async (session) => {
      await WithdrawalRequest.findByIdAndUpdate(wd._id, { status: 'cancelled' }, { session });
      await User.findByIdAndUpdate(req.user.id, { $inc: { lockedBalance: -wd.amount } }, { session });
      await Transaction.findOneAndUpdate(
        { relatedWithdrawal: wd._id },
        { $set: { status: 'reversed', reversedAt: new Date() } },
        { session }
      );
    });
    res.json({ success: true, message: 'تم إلغاء طلب السحب وتحرير الرصيد' });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ════════════════════════════════════════════════════════════════════════════
// POST /wallet/pin — تفعيل/تغيير PIN
// ════════════════════════════════════════════════════════════════════════════
exports.setPin = async (req, res) => {
  try {
    const { pin, currentPin } = req.body;
    if (!pin || !/^\d{4}$/.test(String(pin)))
      return res.status(400).json({ success: false, message: 'PIN يجب أن يكون 4 أرقام' });
    const user = await User.findById(req.user.id);
    if (user.walletPinEnabled) {
      if (!currentPin) return res.status(400).json({ success: false, message: 'PIN الحالي مطلوب للتغيير' });
      const existing = await WalletPin.findOne({ user: user._id });
      if (!existing || !(await existing.verifyPin(currentPin)))
        return res.status(401).json({ success: false, message: 'PIN الحالي غير صحيح' });
      existing.pinHash = String(pin); // will be hashed in pre-save
      existing.markModified('pinHash');
      await existing.save();
    } else {
      await WalletPin.create({ user: user._id, pinHash: String(pin) });
      await User.findByIdAndUpdate(user._id, { walletPinEnabled: true });
    }
    res.json({ success: true, message: 'تم تفعيل PIN المحفظة — ستحتاجه عند كل سحب أو تحويل' });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ════════════════════════════════════════════════════════════════════════════
// DELETE /wallet/pin — إزالة PIN
// ════════════════════════════════════════════════════════════════════════════
exports.removePin = async (req, res) => {
  try {
    const { pin } = req.body;
    if (!pin) return res.status(400).json({ success: false, message: 'أدخل PIN الحالي للإزالة' });
    const pinDoc = await WalletPin.findOne({ user: req.user.id });
    if (!pinDoc || !(await pinDoc.verifyPin(pin)))
      return res.status(401).json({ success: false, message: 'PIN غير صحيح' });
    await WalletPin.deleteOne({ user: req.user.id });
    await User.findByIdAndUpdate(req.user.id, { walletPinEnabled: false });
    res.json({ success: true, message: 'تم إزالة PIN المحفظة بنجاح' });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ════════════════════════════════════════════════════════════════════════════
// POST /wallet/transfer — تحويل بين المحافظ
// ════════════════════════════════════════════════════════════════════════════
exports.transfer = async (req, res) => {
  try {
    const { walletId, amount, note, pin } = req.body;
    if (!amount || amount < 0.01) return res.status(400).json({ success: false, message: 'أقل مبلغ للتحويل $0.01' });
    if (!walletId) return res.status(400).json({ success: false, message: 'معرّف محفظة المستلم مطلوب' });

    const sender   = await User.findById(req.user.id);
    const receiver = await User.findOne({ walletId: walletId.toUpperCase() });
    if (!receiver) return res.status(404).json({ success: false, message: 'لا توجد محفظة بهذا المعرّف' });
    if (receiver._id.equals(sender._id)) return res.status(400).json({ success: false, message: 'لا يمكن التحويل لنفسك' });

    // PIN
    try { const ok = await checkPin(sender, pin); if (!ok) return res.status(401).json({ success: false, message: 'PIN غير صحيح' }); }
    catch (e) { return res.status(401).json({ success: false, message: e.message }); }

    const available = sender.walletBalance - sender.lockedBalance;
    if (available < amount) return res.status(400).json({ success: false, message: `الرصيد المتاح $${available.toFixed(2)} فقط` });

    await withTransaction(async (session) => {
      await User.findByIdAndUpdate(sender._id, { $inc: { walletBalance: -amount, totalSpent: amount } }, { session });
      await User.findByIdAndUpdate(receiver._id, { $inc: { walletBalance: amount, totalEarned: amount } }, { session });
      const desc = note ? `: ${note}` : '';
      await Transaction.create([
        {
          user: sender._id, type: 'transfer_out', amount: -amount,
          balanceBefore: sender.walletBalance, balanceAfter: sender.walletBalance - amount,
          description: `تحويل إلى ${receiver.username}${desc}`, status: 'completed',
          fromUser: receiver._id, method: 'wallet'
        },
        {
          user: receiver._id, type: 'transfer_in', amount,
          balanceBefore: receiver.walletBalance, balanceAfter: receiver.walletBalance + amount,
          description: `تحويل من ${sender.username}${desc}`, status: 'completed',
          fromUser: sender._id, method: 'wallet'
        }
      ], { session });
    });

    logger.info(`Transfer: ${sender.username} → ${receiver.username} $${amount}`);
    res.json({
      success: true,
      message: `تم تحويل $${amount} إلى ${receiver.username} بنجاح`,
      receiver: { username: receiver.username, walletId: receiver.walletId },
      newBalance: +(sender.walletBalance - amount).toFixed(4)
    });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ════════════════════════════════════════════════════════════════════════════
// [ADMIN] GET /admin/withdrawals
// ════════════════════════════════════════════════════════════════════════════
exports.adminGetWithdrawals = async (req, res) => {
  try {
    const { status = 'pending', page = 1, limit = 20 } = req.query;
    const skip = (Number(page) - 1) * Number(limit);
    const [items, total] = await Promise.all([
      WithdrawalRequest.find({ status }).sort({ createdAt: 1 }).skip(skip).limit(Number(limit))
        .populate('user', 'username email walletBalance tier'),
      WithdrawalRequest.countDocuments({ status })
    ]);
    const totalAmt = items.reduce((s, w) => s + w.amount, 0);
    res.json({ success: true, count: items.length, total, totalAmount: +totalAmt.toFixed(2), withdrawals: items });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ════════════════════════════════════════════════════════════════════════════
// [ADMIN] POST /admin/withdrawals/:id — approve | complete | reject
// ════════════════════════════════════════════════════════════════════════════
exports.adminProcessWithdrawal = async (req, res) => {
  try {
    const { action, txHash, rejectedReason } = req.body;
    const wd = await WithdrawalRequest.findById(req.params.id).populate('user', 'username walletBalance');
    if (!wd) return res.status(404).json({ success: false, message: 'الطلب غير موجود' });

    if (action === 'approve') {
      if (wd.status !== 'pending') return res.status(400).json({ success: false, message: 'يمكن الموافقة على الطلبات المعلّقة فقط' });
      await WithdrawalRequest.findByIdAndUpdate(wd._id, { status: 'approved', processedBy: req.user.id });
      return res.json({ success: true, message: 'تمت الموافقة على طلب السحب' });
    }

    if (action === 'complete') {
      if (wd.status !== 'approved') return res.status(400).json({ success: false, message: 'الطلب يجب أن يكون موافقاً عليه أولاً' });
      await withTransaction(async (session) => {
        await User.findByIdAndUpdate(wd.user._id, {
          $inc: { walletBalance: -wd.amount, lockedBalance: -wd.amount, totalWithdrawn: wd.amount }
        }, { session });
        await WithdrawalRequest.findByIdAndUpdate(wd._id, {
          status: 'completed', txHash, processedAt: new Date(), processedBy: req.user.id
        }, { session });
        await Transaction.findOneAndUpdate(
          { relatedWithdrawal: wd._id },
          { $set: { status: 'completed', 'metadata.txHash': txHash } },
          { session }
        );
      });
      logger.info(`Withdrawal completed: ${wd.user.username} $${wd.amount} tx=${txHash}`);
      notify.withdrawalProcessed(wd.user._id, wd.amount, 'completed').catch(() => {});
      return res.json({ success: true, message: 'تم إتمام السحب وخصم الرصيد' });
    }

    if (action === 'reject') {
      await withTransaction(async (session) => {
        await User.findByIdAndUpdate(wd.user._id, { $inc: { lockedBalance: -wd.amount } }, { session });
        await WithdrawalRequest.findByIdAndUpdate(wd._id, {
          status: 'rejected', rejectedReason: rejectedReason || 'بدون سبب',
          processedAt: new Date(), processedBy: req.user.id
        }, { session });
        await Transaction.findOneAndUpdate(
          { relatedWithdrawal: wd._id },
          { $set: { status: 'reversed', reversedAt: new Date() } },
          { session }
        );
      });
      return res.json({ success: true, message: 'تم رفض الطلب وإعادة الرصيد للمستخدم' });
    }

    res.status(400).json({ success: false, message: 'action يجب أن يكون: approve | complete | reject' });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};
