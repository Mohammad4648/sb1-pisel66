const express = require('express');
const router  = express.Router();
const wallet  = require('../controllers/wallet.controller');
const { protect, authorize } = require('../middleware/auth.middleware');

// Binance Pay webhook (no auth — HMAC verified internally)
router.post('/webhook/binance', wallet.binancePayWebhook);

router.use(protect);

// المحفظة
router.get('/',                wallet.getWallet);
router.get('/transactions',    wallet.getTransactions);
router.get('/summary',         wallet.getWalletSummary);

// الإيداع
router.post('/deposit',        wallet.deposit);
router.post('/deposit/crypto', wallet.initiateCryptoDeposit);

// السحب
router.post('/withdraw',       wallet.withdraw);
router.get('/withdrawals',     wallet.getWithdrawals);
router.delete('/withdrawals/:id', wallet.cancelWithdrawal);

// PIN
router.post('/pin',            wallet.setPin);
router.delete('/pin',          wallet.removePin);

// التحويل
router.post('/transfer',       wallet.transfer);

// [Admin]
router.get('/admin/withdrawals',          authorize('admin'), wallet.adminGetWithdrawals);
router.post('/admin/withdrawals/:id',     authorize('admin'), wallet.adminProcessWithdrawal);

// خاصية الصدقة
router.patch('/sadaqa', protect, async (req, res) => {
  try {
    const { enabled } = req.body;
    const user = await require('../models/User').findByIdAndUpdate(
      req.user.id,
      { $set: { sadaqaEnabled: !!enabled } },
      { new: true, select: 'sadaqaEnabled totalSadaqa' }
    );
    const { SADAQA } = require('../config/islamic.config');
    res.json({
      success: true,
      sadaqaEnabled: user.sadaqaEnabled,
      totalSadaqa:   user.totalSadaqa,
      message: user.sadaqaEnabled
        ? `✅ خاصية الصدقة مفعّلة — ${SADAQA.description}`
        : '⭕ خاصية الصدقة معطّلة',
      note: SADAQA.note
    });
  } catch(e) { res.status(500).json({ success:false, message:e.message }); }
});

module.exports = router;
