/**
 * seeds/index.js — v4 (4 صناديق نهائية)
 *
 *  1. Trial Surprise Box   — 1$     رقمي، مرة واحدة فقط
 *  2. Daily Tech Box       — 6.99$  إلكترونيات
 *  3. Study & Creativity   — 5.49$  قرطاسية وإبداع
 *  4. Golden Box           — 49.99$ منتجات فاخرة
 */

const mongoose = require('mongoose');
require('dotenv').config();

const User   = require('../models/User');
const Box    = require('../models/Box');
const Item   = require('../models/Item');
const Coupon = require('../models/Coupon');
const { computeTransparency } = require('../services/roi.engine');

// ── مصنع المنتجات ──────────────────────────────────────────────────────────
const mk = (name, desc, type, cat, mv, cost, x = {}) => ({
  name,
  description: desc,
  image: `https://placehold.co/400x400/${x.color ?? '6366f1'}/white?text=${encodeURIComponent(name.slice(0,12))}`,
  type,
  productCategory: cat,
  marketValue:        mv,
  supplierCost:       cost,
  estimatedShipping:  x.ship  ?? 0.90,
  weight:             x.w     ?? 0.15,
  refundRiskScore:    x.risk  ?? 2,
  isBonus:            x.bonus ?? false,
  isActive:           true,
  selectionWeight:    100,
});

// ══════════════════════════════════════════════════════════════════════════
// TECH ITEMS — قيمة 4.80$–7.50$  (Bucket A/B/C)
// ══════════════════════════════════════════════════════════════════════════
const TECH_ITEMS = [
  mk('حامل هاتف مغناطيسي 360°',   'تثبيت قوي للسيارة والمكتب',           'electronics','حوامل هواتف',  6.5, 2.1, {risk:1,color:'4f46e5'}),
  mk('كابل USB-C شحن سريع 2م',    'كابل نايلون 3A مع مؤشر LED',          'electronics','كابلات',        6.5, 1.9, {risk:1,color:'4f46e5'}),
  mk('سماعة ستيريو مع ميكروفون',  'صوت واضح — مناسبة للاجتماعات',       'electronics','سماعات',        6.5, 2.3, {risk:2,color:'4f46e5'}),
  mk('مصباح LED USB مرن',          'إضاءة ذكية للكمبيوتر والقراءة',       'electronics','إضاءة',         6.5, 2.0, {risk:1,color:'4f46e5'}),
  mk('محوّل USB-C متعدد 4 منافذ', 'Hub USB-C→USB A×3+SD بجسم ألمنيوم',  'electronics','محولات',        7.5, 3.2, {risk:2,color:'4f46e5',ship:1.0}),
  mk('قلم شاشة لمس دقيق',          'يعمل على جميع الشاشات اللمسية',      'electronics','أقلام لمس',     6.5, 1.9, {risk:2,color:'4f46e5'}),
  mk('بطاقة ذاكرة MicroSD 32GB',   'Class 10 — للهاتف والكاميرا والدرون','electronics','تخزين',         6.5, 2.6, {risk:1,color:'4f46e5'}),
  mk('ماوس لاسلكي صامت',           'بطارية 12 شهر — تصميم مريح',          'electronics','ماوس',          7.0, 3.1, {risk:2,color:'4f46e5',w:0.2}),
  mk('شاحن لاسلكي Qi 10W',         'يشحن عبر الجراب — متوافق iOS/Android','electronics','شواحن',         7.5, 3.3, {risk:2,color:'4f46e5',ship:1.0}),
  mk('مضخة هواء USB للتنظيف',      'تنظيف لوحة المفاتيح والأجهزة بقوة',  'electronics','تنظيف',         6.5, 2.1, {risk:1,color:'4f46e5'}),
  mk('مقياس حرارة رقمي USB',       'يعرض درجة الحرارة والرطوبة فوراً',   'electronics','أجهزة قياس',    6.5, 2.5, {risk:2,color:'4f46e5'}),
  mk('سماعة بلوتوث صغيرة 5.0',     'صوت واضح — بطارية 6 ساعات',          'electronics','سماعات',        7.0, 2.9, {risk:2,color:'4f46e5'}),
  mk('منظّم كابلات مغناطيسي',     '3 حلقات سيليكون — تُثبّت على المكتب','electronics','تنظيم',         6.3, 1.7, {risk:1,color:'4f46e5'}),
  mk('حامل لابتوب ألمنيوم',        '6 مستويات — خفيف ومتين',             'electronics','حوامل',         7.5, 3.2, {risk:2,color:'4f46e5',ship:1.0,w:0.3}),
];

// ══════════════════════════════════════════════════════════════════════════
// STUDY ITEMS — قيمة 3.80$–6.50$
// ══════════════════════════════════════════════════════════════════════════
const STUDY_ITEMS = [
  mk('دفتر نوتبوك جلدي A5',        '200 ورقة مسطّرة — غلاف جلدي ناعم',  'stationery','دفاتر',         5.5, 2.2, {risk:1,color:'d97706',ship:1.0,w:0.25}),
  mk('طقم أقلام هندسية 6 ألوان',   'حبر جاف — ممتازة للرسم والكتابة',    'stationery','أقلام',         5.0, 1.9, {risk:1,color:'d97706'}),
  mk('مكعب روبيك 3×3 سريع',        'حركة سلسة — مناسب مبتدئين ومحترفين','stationery','ألعاب ذكاء',    5.5, 2.2, {risk:2,color:'d97706',w:0.2}),
  mk('أوراق ملاحظات لاصقة 5 ألوان','5×100 ورقة — للمنزل والمكتب',        'stationery','لوازم مكتبية',  5.0, 1.8, {risk:1,color:'d97706'}),
  mk('ربطة قلم معدنية + حبر ذهبي', 'قلم أنيق — مثالي للهدايا',           'stationery','أدوات كتابة',   5.8, 2.4, {risk:1,color:'d97706'}),
  mk('ألعاب تفكير خشبية صغيرة',    'لعبة ذكاء خشبية تعليمية ≥6 سنوات',  'stationery','ألعاب تعليمية', 5.5, 2.2, {risk:1,color:'d97706',w:0.2}),
  mk('بطاقات تعليمية لغوية 60 بطاقة','لتعلم المفردات بأسلوب ممتع',       'stationery','تعليم',         5.0, 1.9, {risk:1,color:'d97706',w:0.1}),
  mk('لوحة رسم مصغّرة مع أدوات',   '20×15 سم — أقلام + ممحاة',           'stationery','رسم وفن',       5.8, 2.4, {risk:2,color:'d97706',w:0.25,ship:1.0}),
  mk('مجموعة أختام تاريخ 3 قطع',   'أختام ذاتية الحبر للتحقق والتواريخ', 'stationery','أختام',         5.2, 2.0, {risk:1,color:'d97706'}),
  mk('دفتر رسم إسكتش A4',           '120 ورقة — ورق عالي الجودة',         'stationery','دفاتر',         5.8, 2.4, {risk:1,color:'d97706',ship:1.0,w:0.3}),
  mk('قاعدة كتب معدنية قابلة للطي','تُثبّت الكتب في أي زاوية',            'stationery','لوازم مكتبية',  5.9, 2.6, {risk:1,color:'d97706',ship:1.0,w:0.25}),
  mk('علبة تخزين أدوات مكتبية',    'صندوق شفاف بقسمات — لتنظيم المكتب',  'stationery','تنظيم',         5.5, 2.1, {risk:1,color:'d97706',w:0.2}),
];

// ══════════════════════════════════════════════════════════════════════════
// GOLDEN ITEMS — قيمة 35$–65$  (صندوق 49.99$)
// ══════════════════════════════════════════════════════════════════════════
const GOLDEN_ITEMS = [
  mk('ساعة ذكية Fitness Pro',       'شاشة AMOLED — قياس ضغط + أكسجين',   'electronics','ساعات ذكية',   52.0,26.0,{risk:2,color:'b45309',w:0.3,ship:2.5}),
  mk('سماعة بلوتوث Over-Ear',       'إلغاء ضوضاء نشط — بطارية 30 ساعة',  'electronics','سماعات',       54.0, 27.0,{risk:2,color:'b45309',w:0.35,ship:2.5}),
  mk('شاحن سريع GaN 65W 3 منافذ',   'USB-C+A — يشحن لابتوب + هاتفين',    'electronics','شواحن',        45.0,22.0,{risk:1,color:'b45309',ship:2.0}),
  mk('قلم ذكي بلوتوث للأجهزة',      'يعمل مع iPad + أندرويد بدقة عالية', 'electronics','أقلام لمس',    48.0,23.0,{risk:2,color:'b45309'}),
  mk('كاميرا ويب 4K للاجتماعات',    'دقة 4K — مع ميكروفون مدمج وغطاء',   'electronics','كاميرات',      52.0,26.0,{risk:2,color:'b45309',ship:2.0}),
  mk('مكبّر صوت بلوتوث مقاوم للماء','IPX7 — بطارية 24 ساعة — صوت نقي',  'electronics','مكبرات صوت',   48.0,23.0,{risk:2,color:'b45309',ship:2.0,w:0.4}),
  mk('ميزان إلكتروني ذكي 5 كيلو',   'دقة 1g — يتصل بالتطبيق عبر بلوتوث','home',        'موازين',       46.0, 21.0,{risk:1,color:'b45309',w:0.4,ship:2.0}),
  mk('مكواة شعر بروفشنال سيراميك',  'درجات حرارة 10 مستوى — سخون سريع',  'accessories','عناية شعر',    52.0,26.0,{risk:2,color:'b45309',ship:2.5}),
  mk('جهاز مساج عنق وكتف',          '4 رؤوس + تدفئة + 6 مستويات شدة',    'accessories','مساج',         50.0,24.0,{risk:1,color:'b45309',ship:2.0,w:0.4}),
  mk('طقم أدوات طبخ ستانلس ستيل',   '5 قطع — جودة مطاعم — مقاوم للحرارة','home',        'أدوات طبخ',    45.0,21.0,{risk:1,color:'b45309',ship:2.5,w:0.5}),
  mk('حقيبة ظهر لابتوب 15.6" جلد',  'جلد PU فاخر — مقصورات منظّمة',      'accessories','حقائب',        54.0, 27.0,{risk:2,color:'b45309',ship:2.5,w:0.7}),
  mk('محطة شحن لاسلكي 4 أجهزة',     'تشحن هاتف + ساعة + سماعة + آيباد',  'electronics','شواحن',        50.0,25.0,{risk:2,color:'b45309',ship:2.0}),
  mk('مرشّح هواء USB للمكتب',        'يزيل الغبار والبكتيريا — هادئ جداً','home',        'تنقية هواء',   45.0,21.0,{risk:1,color:'b45309',ship:2.0,w:0.4}),
  mk('نظارة قراءة ذكية ضد الضوء الأزرق','عدسات مصفّرة — تقليل إجهاد العين','accessories','نظارات',       46.0, 20.0,{risk:2,color:'b45309'}),
  mk('لوحة مفاتيح ميكانيكية RGB',   'ميني 75% — مفاتيح Blue — ضوء RGB',  'electronics','كيبورد',       54.0, 27.0,{risk:2,color:'b45309',ship:2.5,w:0.6}),
  mk('سكوتر يد USB قابل للشحن',     'لعبة سرعة وتوازن للأطفال والكبار',   'stationery', 'ألعاب',        48.0,23.0,{risk:3,color:'b45309',ship:2.5,w:0.5}),
];

// ══════════════════════════════════════════════════════════════════════════
// BONUS ITEMS — مشتركة بين Tech + Study فقط
// ══════════════════════════════════════════════════════════════════════════
const BONUS_ITEMS = [
  mk('قلم حبر معدني أنيق',       'للكتابة اليومية',          'stationery','أقلام',           2.5,0.9,{bonus:true,risk:1,color:'6366f1'}),
  mk('مفتاح USB LED صغير',       'مصباح USB للقراءة الليلية','electronics','إضاءة',           2.8,1.1,{bonus:true,risk:1,color:'6366f1'}),
  mk('مناديل تنظيف شاشات 20 قطعة','ألياف دقيقة للشاشات',      'electronics','تنظيف',           2.0,0.7,{bonus:true,risk:1,color:'6366f1'}),
  mk('ربطة شعر قطنية 5 قطع',     'لا تكسر الشعر',            'stationery','إكسسوارات',       2.2,0.8,{bonus:true,risk:1,color:'6366f1'}),
  mk('لاصق هلامي متعدد الاستخدام','لا يُفسد الأسطح',           'stationery','لوازم',           2.5,1.0,{bonus:true,risk:1,color:'6366f1'}),
  mk('مشابك ورق ملونة 12 قطعة',  'للمكتب والدراسة',          'stationery','لوازم مكتبية',    2.2,0.8,{bonus:true,risk:1,color:'6366f1'}),
  mk('ضفيرة مفاتيح سيليكون',     'مرنة لا تخدش',             'stationery','إكسسوارات',       2.5,1.0,{bonus:true,risk:1,color:'6366f1'}),
  mk('ملصقات ديكورية 50 قطعة',   'للدفاتر والأجهزة',         'stationery','ديكور',           2.0,0.7,{bonus:true,risk:1,color:'6366f1'}),
];

// ══════════════════════════════════════════════════════════════════════════
// TRIAL ITEMS — رقمي 100%
// ══════════════════════════════════════════════════════════════════════════
const TRIAL_ITEMS = [
  mk('كوبون خصم 10% — طلبك التالي', 'خصم حصري صالح 7 أيام',          'stationery','كوبونات',     1.0,0.05,{risk:1,color:'ef4444',ship:0}),
  mk('خلفية شاشة حصرية — أزرق',     '4K للموبايل والكمبيوتر',         'stationery','محتوى رقمي', 1.0,0.05,{risk:1,color:'ef4444',ship:0}),
  mk('خلفية شاشة حصرية — بنفسجي',   '4K للموبايل والكمبيوتر',         'stationery','محتوى رقمي', 1.0,0.05,{risk:1,color:'ef4444',ship:0}),
  mk('50 نقطة XP مجانية',            'تُضاف فوراً لرصيدك',             'stationery','مكافآت',     1.0,0.01,{risk:1,color:'ef4444',ship:0}),
  mk('100 نقطة XP مجانية',           'تُضاف فوراً لرصيدك',             'stationery','مكافآت',     1.0,0.01,{risk:1,color:'ef4444',ship:0}),
  mk('شارة مستكشف الحصرية',         'شارة رقمية لملفك الشخصي',        'stationery','محتوى رقمي', 1.0,0.01,{risk:1,color:'ef4444',ship:0}),
];

// ══════════════════════════════════════════════════════════════════════════
// buildBoxes
// ══════════════════════════════════════════════════════════════════════════
async function buildBoxes(docs) {
  const byName = name => docs.find(d => d.name === name)?._id;
  const ids    = arr  => arr.map(i => i._id).filter(Boolean);

  const techIds   = ids(docs.filter(d => TECH_ITEMS.some(t  => t.name === d.name)));
  const studyIds  = ids(docs.filter(d => STUDY_ITEMS.some(t => t.name === d.name)));
  const goldenIds = ids(docs.filter(d => GOLDEN_ITEMS.some(t=> t.name === d.name)));
  const bonusIds  = ids(docs.filter(d => BONUS_ITEMS.some(t => t.name === d.name)));
  const trialIds  = ids(docs.filter(d => TRIAL_ITEMS.some(t => t.name === d.name)));

  // حساب transparency
  const mkTransparency = (price, itemList) => {
    const vals = itemList.map(i => i.marketValue);
    return {
      totalProducts: itemList.length,
      minValue:      +Math.min(...vals).toFixed(2),
      maxValue:      +Math.max(...vals).toFixed(2),
      averageValue:  +(vals.reduce((a,b)=>a+b,0)/vals.length).toFixed(2),
      valueGuarantee:`كل منتج بقيمة ${Math.min(...vals).toFixed(0)}$–${Math.max(...vals).toFixed(0)}$ — مضمون`
    };
  };

  const techDocs   = docs.filter(d => TECH_ITEMS.some(t  => t.name === d.name));
  const studyDocs  = docs.filter(d => STUDY_ITEMS.some(t => t.name === d.name));
  const goldenDocs = docs.filter(d => GOLDEN_ITEMS.some(t=> t.name === d.name));
  const trialDocs  = docs.filter(d => TRIAL_ITEMS.some(t => t.name === d.name));

  return [
    // ── 1. Trial Box ─────────────────────────────────────────────────────
    {
      name:        'Trial Surprise Box',
      slug:        'trial-surprise-box',
      description: 'جرّب تجربة الصندوق المفاجئ بـ1$ فقط — محتوى رقمي فوري — مرة واحدة لكل حساب.',
      coverImage:  'https://placehold.co/600x400/ef4444/white?text=Trial+1%24',
      icon:        '🎯', color: '#ef4444',
      price:       1.00, currency: 'USD',
      category:    'mixed', boxType: 'digital',
      isTrial:     true, maxPerUser: 1, hasBonus: false, isFeatured: true,
      bucketDistribution: { A:100, B:0, C:0 },
      tags:        ['تجريبي','رقمي','1دولار'],
      items:       trialIds,
      transparency: mkTransparency(1.00, trialDocs),
      profitMargin: 0.50,
    },

    // ── 2. Daily Tech Box ────────────────────────────────────────────────
    {
      name:        'Daily Tech Box',
      slug:        'daily-tech-box',
      description: 'منتج تقني مفيد كل يوم + هدية صغيرة. إلكترونيات خفيفة ستستخدمها فعلاً.',
      coverImage:  'https://placehold.co/600x400/4f46e5/white?text=Daily+Tech',
      icon:        '📱', color: '#4f46e5',
      price:       6.99, currency: 'USD',
      category:    'electronics', boxType: 'physical',
      hasBonus:    true, isFeatured: true,
      bucketDistribution: { A:40, B:40, C:20 },
      tags:        ['تقنية','إلكترونيات','يومي'],
      items:       [...techIds, ...bonusIds],
      transparency: mkTransparency(6.99, techDocs),
      profitMargin: 0.20,
    },

    // ── 3. Study & Creativity Box ────────────────────────────────────────
    {
      name:        'Study & Creativity Box',
      slug:        'study-creativity-box',
      description: 'أداة دراسية أو إبداعية تجعل يومك أكثر إنتاجاً. قرطاسية ومكتبيات مميزة.',
      coverImage:  'https://placehold.co/600x400/d97706/white?text=Study',
      icon:        '📚', color: '#d97706',
      price:       5.49, currency: 'USD',
      category:    'mixed', boxType: 'physical',
      hasBonus:    true,
      bucketDistribution: { A:50, B:35, C:15 },
      tags:        ['قرطاسية','دراسة','إبداع'],
      items:       [...studyIds, ...bonusIds],
      transparency: mkTransparency(5.49, studyDocs),
      profitMargin: 0.22,
    },

    // ── 4. Golden Box ────────────────────────────────────────────────────
    {
      name:        'Golden Box',
      slug:        'golden-box',
      description: 'الصندوق الذهبي — منتجات فاخرة بقيمة 35$–65$. لمن يريد الأفضل دائماً.',
      coverImage:  'https://placehold.co/600x400/b45309/white?text=Golden+Box+%F0%9F%8F%85',
      icon:        '🏅', color: '#b45309',
      price:       49.99, currency: 'USD',
      category:    'mixed', boxType: 'physical',
      hasBonus:    false, isFeatured: true,
      bucketDistribution: { A:20, B:50, C:30 },
      tags:        ['ذهبي','فاخر','مميز','هدايا'],
      items:       goldenIds,
      transparency: mkTransparency(49.99, goldenDocs),
      profitMargin: 0.18,
    },
  ];
}

// ══════════════════════════════════════════════════════════════════════════
// SEED
// ══════════════════════════════════════════════════════════════════════════
const seed = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/mystery-boxes-pro');
    console.log('✅ MongoDB connected');

    await User.deleteMany({});
    await Box.deleteMany({});
    await Item.deleteMany({});
    await Coupon.deleteMany({});
    console.log('🗑️  Cleared existing data');

    // Admin
    const admin = await User.create({
      username: 'admin',
      email:    process.env.ADMIN_EMAIL    || 'admin@mysteryboxes.com',
      password: process.env.ADMIN_PASSWORD || 'Admin@123',
      role: 'admin', isVerified: true, walletBalance: 500
    });
    console.log(`👤 Admin: ${admin.email}`);

    // Test users
    await User.insertMany([
      { username:'ahmed',  email:'ahmed@test.com',  password:'Test@123', isVerified:true, walletBalance:100 },
      { username:'sara',   email:'sara@test.com',   password:'Test@123', isVerified:true, walletBalance:60  },
      { username:'khalid', email:'khalid@test.com', password:'Test@123', isVerified:true, walletBalance:200 },
    ]);
    console.log('👥 3 test users created');

    // Items
    const ALL_RAW = [...TRIAL_ITEMS, ...TECH_ITEMS, ...STUDY_ITEMS, ...GOLDEN_ITEMS, ...BONUS_ITEMS];
    const docs    = await Item.insertMany(ALL_RAW);

    const trialCount  = TRIAL_ITEMS.length;
    const techCount   = TECH_ITEMS.length;
    const studyCount  = STUDY_ITEMS.length;
    const goldenCount = GOLDEN_ITEMS.length;
    const bonusCount  = BONUS_ITEMS.length;
    console.log(`📦 Items: ${trialCount} trial + ${techCount} tech + ${studyCount} study + ${goldenCount} golden + ${bonusCount} bonus = ${docs.length} total`);

    // Boxes
    const boxDefs = await buildBoxes(docs);
    const boxes   = await Box.insertMany(boxDefs);
    console.log(`\n🎁 Boxes created:`);
    boxes.forEach(b => {
      const mainItems = b.items.length;
      const margin    = (b.profitMargin * 100).toFixed(0);
      console.log(`   ${b.icon} "${b.name}" — $${b.price} — ${mainItems} منتج — هامش ${margin}%`);
    });

    // Coupons
    await Coupon.insertMany([
      {
        code: 'WELCOME10', discountType: 'percentage', discountValue: 10,
        description: '10% خصم — للمستخدمين الجدد',
        maxUses: 1000, validUntil: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
      },
      {
        code: 'TECH5', discountType: 'fixed', discountValue: 1,
        description: 'خصم 1$ على Daily Tech Box',
        maxUses: 200, validUntil: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000)
      },
      {
        code: 'GOLDEN20', discountType: 'percentage', discountValue: 20,
        description: '20% خصم على Golden Box — محدود',
        maxUses: 50, validUntil: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
      },
    ]);
    console.log('\n🏷️  Coupons: WELCOME10 | TECH5 | GOLDEN20');

    // ── ملخص مالي ────────────────────────────────────────────────────────
    console.log('\n════════════════════════════════════════════');
    console.log('   📊 المراجعة المالية للصناديق');
    console.log('════════════════════════════════════════════');
    const models = [
      { name:'Trial Surprise Box', price:1.00,  cost:0.05, ship:0.00, digital:true  },
      { name:'Daily Tech Box',     price:6.99,  cost:2.50, ship:0.90, digital:false },
      { name:'Study & Creativity', price:5.49,  cost:2.00, ship:0.90, digital:false },
      { name:'Golden Box',         price:49.99, cost:24.0, ship:2.50, digital:false },
    ];
    models.forEach(m => {
      const payment   = +(m.price * 0.029 + 0.30).toFixed(2);
      const cs        = +(m.price * 0.03).toFixed(2);
      const reserve   = +(m.price * 0.05).toFixed(2);
      const totalCost = +(m.cost + m.ship + payment + cs + reserve).toFixed(2);
      const profit    = +(m.price - totalCost).toFixed(2);
      const margin    = +(profit / m.price * 100).toFixed(1);
      console.log(`\n   ${m.name} — $${m.price}`);
      console.log(`     المورد:          $${m.cost.toFixed(2)}`);
      console.log(`     الشحن:           $${m.ship.toFixed(2)}`);
      console.log(`     أجرة الدفع:     $${payment}`);
      console.log(`     خدمة عملاء 3%:  $${cs}`);
      console.log(`     احتياطي إرجاع:  $${reserve}`);
      console.log(`     ─────────────────────`);
      console.log(`     إجمالي تكاليف:  $${totalCost}`);
      console.log(`     الربح الصافي:   $${profit}  (${margin}%)`);
    });
    console.log('\n════════════════════════════════════════════');
    console.log(`\n🔑 Admin: ${admin.email} / ${process.env.ADMIN_PASSWORD || 'Admin@123'}`);
    console.log('✅ Seed v4 completed!\n');
    process.exit(0);
  } catch (err) {
    console.error('❌ Seed error:', err.message);
    process.exit(1);
  }
};

seed();
