const mongoose = require('mongoose');

const proofRecordSchema = new mongoose.Schema({
  user:  { type: mongoose.Schema.Types.ObjectId, ref: 'User',  required: true },
  order: { type: mongoose.Schema.Types.ObjectId, ref: 'Order', required: true },
  box:   { type: mongoose.Schema.Types.ObjectId, ref: 'Box',   required: true },

  // Commitment (sent to user BEFORE open)
  serverSeedHash: { type: String, required: true },

  // Revealed AFTER open
  serverSeed: { type: String, required: true, select: false }, // hidden until revealed
  clientSeed: { type: String, required: true },
  nonce:      { type: Number, required: true },

  // Result
  fairFloat:  { type: String, required: true }, // stored as string to preserve precision
  itemName:   { type: String },
  itemRarity: { type: String },

  // Whether user has requested reveal
  revealed: { type: Boolean, default: false },
  revealedAt: { type: Date }
}, { timestamps: true });

proofRecordSchema.index({ user: 1, order: 1 });
proofRecordSchema.index({ user: 1, createdAt: -1 });

module.exports = mongoose.model('ProofRecord', proofRecordSchema);
