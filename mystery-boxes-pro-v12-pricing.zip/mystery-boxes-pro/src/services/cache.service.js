/**
 * cache.service.js
 *
 * Lightweight in-memory cache using a Map with TTL expiry.
 * No Redis dependency needed — perfect for single-server deployments.
 * Automatically evicts expired entries on access.
 *
 * Usage:
 *   cache.set('boxes:all', data, 60);        // cache for 60 seconds
 *   const data = cache.get('boxes:all');      // null if expired/missing
 *   cache.del('boxes:all');                   // invalidate
 *   cache.delPattern('boxes:');               // invalidate all box caches
 */

class MemoryCache {
  constructor() {
    this.store = new Map();
    this.hits   = 0;
    this.misses = 0;

    // Cleanup sweep every 5 minutes
    setInterval(() => this._sweep(), 5 * 60 * 1000);
  }

  set(key, value, ttlSeconds = 300) {
    this.store.set(key, {
      value,
      expiresAt: Date.now() + ttlSeconds * 1000
    });
  }

  get(key) {
    const entry = this.store.get(key);
    if (!entry) { this.misses++; return null; }
    if (Date.now() > entry.expiresAt) {
      this.store.delete(key);
      this.misses++;
      return null;
    }
    this.hits++;
    return entry.value;
  }

  del(key) {
    this.store.delete(key);
  }

  // Delete all keys that start with a prefix
  delPattern(prefix) {
    for (const key of this.store.keys()) {
      if (key.startsWith(prefix)) this.store.delete(key);
    }
  }

  // Wrap an async function with caching
  async wrap(key, fn, ttlSeconds = 300) {
    const cached = this.get(key);
    if (cached !== null) return cached;
    const result = await fn();
    this.set(key, result, ttlSeconds);
    return result;
  }

  stats() {
    const total = this.hits + this.misses;
    return {
      keys:     this.store.size,
      hits:     this.hits,
      misses:   this.misses,
      hitRate:  total > 0 ? `${((this.hits / total) * 100).toFixed(1)}%` : '0%'
    };
  }

  _sweep() {
    const now = Date.now();
    for (const [key, entry] of this.store.entries()) {
      if (now > entry.expiresAt) this.store.delete(key);
    }
  }

  flush() {
    this.store.clear();
    this.hits = 0;
    this.misses = 0;
  }
}

// Export singleton
module.exports = new MemoryCache();
