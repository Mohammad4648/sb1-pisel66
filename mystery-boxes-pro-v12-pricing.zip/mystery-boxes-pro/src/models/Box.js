/**
 * Box.js — v2 (Retail Model)
 *
 * التغييرات من v1:
 *   - حذف: rarityDistribution (legendary/epic/rare — ميكانيكية كازينو)
 *   - حذف: pitySystem (ضمان legendary بعد N فتحات — ميكانيكية كازينو)
 *   - حذف: minOpenRequirement
 *   - إضافة: bucketDistribution — يتحكم في احتمال كل bucket (تكلفة فقط)
 *   - إضافة: transparency — معلومات شفافة تُعرض قبل الشراء
 *   - إضافة: hasBonus — هل يشمل الصندوق منتجاً إضافياً؟
 */

const mongoose = require('mongoose');

const boxSchema = new mongoose.Schema({
  name:        { type: String, required: true, trim: true, unique: true },
  slug:        { type: String, unique: true, lowercase: true },
  description: { type: String, required: true, maxlength: 1000 },
  coverImage:  { type: String, required: true },
  icon:        { type: String, default: '📦' },
  color:       { type: String, default: '#6366f1' },

  // ── التسعير ───────────────────────────────────────────────────────────────
  price:    { type: Number, required: true, min: 0.01 },
  currency: { type: String, default: 'USD' },
  discount: { type: Number, min: 0, max: 100, default: 0 },

  // ── الفئة ─────────────────────────────────────────────────────────────────
  category: {
    type: String, required: true,
    enum: ['electronics', 'accessories', 'clothing', 'home', 'mixed']
  },
  tags: [{ type: String, lowercase: true }],

  // ── المخزون والإحصائيات ───────────────────────────────────────────────────
  stock:         { type: Number, default: -1 },
  soldCount:     { type: Number, default: 0 },
  openingsCount: { type: Number, default: 0 },
  totalRevenue:  { type: Number, default: 0 },

  // ── المنتجات ──────────────────────────────────────────────────────────────
  items: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Item' }],

  // ── توزيع الـBuckets — تحكم في التكلفة، لا في "الحظ" ────────────────────
  // الجمع يجب أن يساوي 100
  bucketDistribution: {
    A: { type: Number, default: 50 },  // أرخص: 1.5$–2.2$
    B: { type: Number, default: 35 },  // متوسط: 2.2$–3$
    C: { type: Number, default: 15 }   // أغلى:  3$–3.8$
  },

  // ── Bonus item ────────────────────────────────────────────────────────────
  hasBonus:   { type: Boolean, default: true },

  // ── Trial Box ─────────────────────────────────────────────────────────────
  isTrial:    { type: Boolean, default: false },   // صندوق 1$ تجريبي
  maxPerUser: { type: Number,  default: -1 },      // -1 = unlimited, 1 = مرة واحدة فقط // هل يشمل منتجاً إضافياً صغيراً؟

  // ── شفافية كاملة — تُعرض قبل الشراء ─────────────────────────────────────
  // يُحسب ويُحفظ عند إنشاء/تعديل الصندوق
  transparency: {
    totalProducts:  { type: Number, default: 0 },
    minValue:       { type: Number, default: 0 },   // أدنى قيمة سوقية في القائمة
    maxValue:       { type: Number, default: 0 },   // أعلى قيمة سوقية
    averageValue:   { type: Number, default: 0 },   // المتوسط
    valueGuarantee: { type: String, default: '' }   // نص ضمان يُعرض للمستخدم
  },

  // ── الحالة ────────────────────────────────────────────────────────────────
  isActive:   { type: Boolean, default: true },
  isFeatured: { type: Boolean, default: false },

  // ── التقييم ───────────────────────────────────────────────────────────────
  averageRating: { type: Number, default: 0, min: 0, max: 5 },
  ratingCount:   { type: Number, default: 0 },

  // ── Provider ──────────────────────────────────────────────────────────────
  // ── Catalog Filter — بديل items:[IDs] للكتالوج الضخم ─────────────────────
  // إذا useCatalog=true: يتجاهل items[] ويختار من CatalogItem بالفلتر
  useCatalog:    { type: Boolean, default: false },
  catalogFilter: {
    categories:  [{ type: String, enum: ['electronics','accessories','clothing','home','stationery','other'] }],
    minPricePct: { type: Number, default: 0.85 },  // 85% من سعر الصندوق
    maxPricePct: { type: Number, default: 1.15 },  // 115% من سعر الصندوق
  },

  provider: { type: mongoose.Schema.Types.ObjectId, ref: 'Provider', default: null },
  boxType:  { type: String, enum: ['physical', 'digital', 'mixed'], default: 'physical' },

  // ── التحكم المالي الداخلي ─────────────────────────────────────────────────
  profitMargin: { type: Number, default: 0.20, min: 0.05, max: 0.50 },
  expectedCost: { type: Number, default: 0 },  // متوسط التكلفة المحسوبة

  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }

}, { timestamps: true, toJSON: { virtuals: true }, toObject: { virtuals: true } });

// ── Virtuals ──────────────────────────────────────────────────────────────────
boxSchema.virtual('finalPrice').get(function () {
  return this.discount > 0
    ? +( this.price * (1 - this.discount / 100) ).toFixed(2)
    : this.price;
});

boxSchema.virtual('isAvailable').get(function () {
  if (!this.isActive) return false;
  if (this.stock !== -1 && this.soldCount >= this.stock) return false;
  return true;
});

// Auto-generate slug
boxSchema.pre('save', function (next) {
  if (!this.slug && this.name) {
    this.slug = this.name.toLowerCase()
      .replace(/\s+/g, '-')
      .replace(/[^\w-]+/g, '');
  }
  next();
});

boxSchema.index({ isActive: 1, isFeatured: 1 });
boxSchema.index({ category: 1 });

module.exports = mongoose.model('Box', boxSchema);
