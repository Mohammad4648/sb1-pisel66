/**
 * developer.portal.controller.js
 *
 * Developer self-service portal (no admin involvement needed after approval).
 *
 * Routes (JWT auth with dev-specific token):
 *   POST /api/dev-portal/register     - Apply for developer account
 *   POST /api/dev-portal/login        - Login
 *   GET  /api/dev-portal/me           - Profile + API key info
 *   POST /api/dev-portal/rotate-key   - Regenerate API key
 *   PUT  /api/dev-portal/webhook      - Update webhook URL
 *   PUT  /api/dev-portal/ips          - Update IP whitelist
 */

const jwt       = require('jsonwebtoken');
const Developer = require('../models/Developer');
const { getDeveloperStats } = require('./commission.engine');
const logger = require('../utils/logger');

// JWT for developer portal (separate secret)
function devToken(developer) {
  return jwt.sign(
    { devId: developer._id, type: 'developer' },
    process.env.JWT_SECRET + '_dev',
    { expiresIn: '7d' }
  );
}

// ── Register ─────────────────────────────────────────────────────────────────
exports.register = async (req, res) => {
  try {
    const { name, email, password, companyName, website, webhookUrl } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ success: false, error: 'name, email, password required' });
    }

    const exists = await Developer.findOne({ email });
    if (exists) return res.status(409).json({ success: false, error: 'Email already registered' });

    const dev = new Developer({ name, email, passwordHash: password, companyName, website, webhookUrl });
    dev.generateApiCredentials();
    await dev.save();

    logger.info(`New developer registered: ${name} (${email}) — pending approval`);

    res.status(201).json({
      success: true,
      message: 'Application submitted. You will be notified once approved by our team.',
      developer: { id: dev._id, name: dev.name, email: dev.email, status: dev.status }
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};

// ── Login ─────────────────────────────────────────────────────────────────────
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    const dev = await Developer.findOne({ email }).select('+passwordHash +apiKey +apiSecret');

    if (!dev || !(await dev.comparePassword(password))) {
      return res.status(401).json({ success: false, error: 'Invalid credentials' });
    }
    if (dev.status === 'rejected') {
      return res.status(403).json({ success: false, error: 'Application rejected. Contact support.' });
    }

    res.json({
      success: true,
      token:   devToken(dev),
      developer: {
        id:             dev._id,
        name:           dev.name,
        email:          dev.email,
        status:         dev.status,
        balance:        +dev.balance.toFixed(2),
        totalEarnings:  +dev.totalEarnings.toFixed(2),
        commissionType: dev.commissionType,
        commissionValue:dev.commissionValue,
        // Only show partial key for security
        apiKeyPreview:  dev.status === 'active' ? dev.apiKey?.slice(0, 12) + '...' : null,
        webhookUrl:     dev.webhookUrl
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};

// ── Get full profile + credentials ───────────────────────────────────────────
exports.getMe = async (req, res) => {
  try {
    const dev = await Developer.findById(req.developerId).select('+apiKey +apiSecret +webhookSecret');
    if (!dev) return res.status(404).json({ success: false, error: 'Developer not found' });

    const stats = dev.status === 'active' ? await getDeveloperStats(dev._id, 30) : null;

    res.json({
      success: true,
      developer: {
        id:              dev._id,
        name:            dev.name,
        email:           dev.email,
        companyName:     dev.companyName,
        website:         dev.website,
        status:          dev.status,
        balance:         +dev.balance.toFixed(2),
        totalEarnings:   +dev.totalEarnings.toFixed(2),
        pendingPayout:   +dev.pendingPayout.toFixed(2),
        minPayout:       dev.minPayout,
        commissionType:  dev.commissionType,
        commissionValue: dev.commissionValue,
        webhookUrl:      dev.webhookUrl,
        allowedIPs:      dev.allowedIPs,
        apiKey:          dev.status === 'active' ? dev.apiKey : '[pending approval]',
        apiSecret:       dev.status === 'active' ? dev.apiSecret : '[pending approval]',
        webhookSecret:   dev.webhookSecret,
        rateLimitPerMin: dev.rateLimitPerMin,
        rateLimitPerHour:dev.rateLimitPerHour,
        totalBoxOpens:   dev.totalBoxOpens,
        lastActivityAt:  dev.lastActivityAt
      },
      stats
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};

// ── Rotate API key ────────────────────────────────────────────────────────────
exports.rotateKey = async (req, res) => {
  try {
    const dev = await Developer.findById(req.developerId).select('+passwordHash');
    const { password } = req.body;
    if (!password || !(await dev.comparePassword(password))) {
      return res.status(401).json({ success: false, error: 'Password confirmation required' });
    }
    const { apiKey, apiSecret } = dev.rotateApiKey();
    await dev.save({ validateBeforeSave: false });

    logger.warn(`API key rotated for developer: ${dev.name}`);
    res.json({ success: true, apiKey, apiSecret, message: 'API key rotated. Update your applications immediately.' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};

// ── Update webhook ────────────────────────────────────────────────────────────
exports.updateWebhook = async (req, res) => {
  try {
    const { webhookUrl } = req.body;
    const dev = await Developer.findByIdAndUpdate(
      req.developerId, { webhookUrl }, { new: true }
    );
    res.json({ success: true, webhookUrl: dev.webhookUrl });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};

// ── Update IP whitelist ───────────────────────────────────────────────────────
exports.updateIPs = async (req, res) => {
  try {
    const { allowedIPs } = req.body; // array of IP strings
    const dev = await Developer.findByIdAndUpdate(
      req.developerId, { allowedIPs: allowedIPs || [] }, { new: true }
    );
    res.json({ success: true, allowedIPs: dev.allowedIPs });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};

// ── Portal JWT middleware ─────────────────────────────────────────────────────
exports.protectPortal = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ success: false, error: 'No token' });
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET + '_dev');
    if (decoded.type !== 'developer') throw new Error('Invalid token type');
    req.developerId = decoded.devId;
    next();
  } catch (err) {
    res.status(401).json({ success: false, error: 'Invalid or expired token' });
  }
};
