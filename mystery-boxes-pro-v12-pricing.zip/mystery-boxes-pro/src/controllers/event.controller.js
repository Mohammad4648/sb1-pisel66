/**
 * event.controller.js
 *
 * GET  /events/active    — الحدث النشط حالياً (للمستخدمين)
 * GET  /events           — قائمة الأحداث (admin)
 * POST /events           — إنشاء حدث (admin)
 * PUT  /events/:id       — تعديل (admin)
 * DELETE /events/:id     — حذف (admin)
 * POST /events/:id/activate   — تفعيل يدوي (admin)
 * POST /events/:id/deactivate — إنهاء يدوي (admin)
 */

const SeasonalEvent = require('../models/SeasonalEvent');
const User          = require('../models/User');
const notify        = require('../services/notify.service');
const cache         = require('../services/cache.service');
const logger        = require('../utils/logger');

// ── الحدث النشط ───────────────────────────────────────────────────────────
exports.getActiveEvent = async (req, res) => {
  try {
    const event = await cache.wrap('event:active', async () => {
      const now = new Date();
      return SeasonalEvent.findOne({ isActive: true, startAt: { $lte: now }, endAt: { $gt: now } })
        .populate('eventBoxes', 'name price coverImage');
    }, 120);
    res.json({ success: true, event: event || null });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ── [Admin] قائمة الأحداث ─────────────────────────────────────────────────
exports.listEvents = async (req, res) => {
  try {
    const events = await SeasonalEvent.find().sort({ startAt: -1 }).limit(50)
      .populate('createdBy', 'username');
    res.json({ success: true, count: events.length, events });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ── [Admin] إنشاء حدث ─────────────────────────────────────────────────────
exports.createEvent = async (req, res) => {
  try {
    const event = await SeasonalEvent.create({ ...req.body, createdBy: req.user.id });
    cache.delPattern('event:');
    logger.info(`Event created: "${event.name}" by ${req.user.username}`);
    res.status(201).json({ success: true, event });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ── [Admin] تعديل حدث ────────────────────────────────────────────────────
exports.updateEvent = async (req, res) => {
  try {
    const event = await SeasonalEvent.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!event) return res.status(404).json({ success: false, message: 'الحدث غير موجود' });
    cache.delPattern('event:');
    res.json({ success: true, event });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ── [Admin] تفعيل حدث + إشعار المستخدمين ───────────────────────────────
exports.activateEvent = async (req, res) => {
  try {
    // إيقاف أي حدث نشط آخر أولاً
    await SeasonalEvent.updateMany({ isActive: true }, { $set: { isActive: false } });
    const event = await SeasonalEvent.findByIdAndUpdate(
      req.params.id, { $set: { isActive: true } }, { new: true }
    );
    if (!event) return res.status(404).json({ success: false, message: 'الحدث غير موجود' });
    cache.delPattern('event:');

    // إشعار جماعي لكل المستخدمين النشطين (async)
    _broadcastEvent(event).catch(() => {});

    logger.info(`Event activated: "${event.name}"`);
    res.json({ success: true, message: `تم تفعيل "${event.name}"`, event });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ── [Admin] إنهاء حدث ────────────────────────────────────────────────────
exports.deactivateEvent = async (req, res) => {
  try {
    await SeasonalEvent.findByIdAndUpdate(req.params.id, { $set: { isActive: false } });
    cache.delPattern('event:');
    res.json({ success: true, message: 'تم إنهاء الحدث' });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ── [Admin] حذف حدث ──────────────────────────────────────────────────────
exports.deleteEvent = async (req, res) => {
  try {
    await SeasonalEvent.findByIdAndDelete(req.params.id);
    cache.delPattern('event:');
    res.json({ success: true, message: 'تم حذف الحدث' });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ── Helper: إشعار جماعي ───────────────────────────────────────────────────
async function _broadcastEvent(event) {
  const since   = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
  const userIds = await User.distinct('_id', {
    isBanned: false, lastLogin: { $gte: since }
  });
  await notify.broadcast(userIds, 'event_started', {
    title:   `${event.emoji} حدث خاص: ${event.name}`,
    message: `ينتهي ${new Date(event.endAt).toLocaleDateString('ar')} — لا تفوّت الفرصة!`,
    data:    { eventId: event._id, eventName: event.name, endAt: event.endAt, boosts: event.boosts }
  });
  logger.info(`Event broadcast sent to ${userIds.length} users`);
}
