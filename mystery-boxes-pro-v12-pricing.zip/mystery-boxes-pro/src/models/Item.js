/**
 * Item.js — v2 (Retail Model)
 *
 * التغييرات من v1:
 *   - حذف: rarity (common/epic/legendary) — كان ميكانيكية كازينو
 *   - حذف: probability (كان يُستخدم لتفاوت الحظ)
 *   - إضافة: bucket A/B/C (فئة تكلفة فقط — للتحكم الداخلي)
 *   - إضافة: supplierCost, estimatedShipping, weight
 *   - إضافة: refundRiskScore (للـSmart Rotation)
 *   - إضافة: isBonus (منتج إضافي صغير)
 *   - إضافة: category فعلية للمنتجات الفيزيائية
 *
 * bucket هو أداة إدارية داخلية فقط — لا يُعرض للمستخدم.
 */

const mongoose = require('mongoose');

const itemSchema = new mongoose.Schema({
  name:        { type: String, required: true, trim: true },
  description: { type: String, required: true, maxlength: 500 },
  image:       { type: String, required: true },

  // ── نوع المنتج الفعلي ─────────────────────────────────────────────────────
  type: {
    type: String, required: true,
    enum: ['electronics', 'accessories', 'clothing', 'home', 'stationery', 'other'],
    default: 'other'
  },

  // فئة تفصيلية ظاهرة للمستخدم (مثل "حامل هاتف" أو "جوارب")
  productCategory: { type: String, trim: true },

  // ── التسعير والتكلفة ──────────────────────────────────────────────────────
  // marketValue = القيمة السوقية المعروضة للمستخدم (قريبة من سعر الصندوق دائماً)
  marketValue:  { type: Number, required: true, min: 0 },

  // حقول داخلية للإدارة فقط — لا تُعرض للمستخدم
  supplierCost:      { type: Number, required: true, min: 0 },  // ما ندفعه للمورد
  estimatedShipping: { type: Number, default: 0.90 },           // تكلفة شحن مقدرة
  weight:            { type: Number, default: 0.2 },            // الوزن بالكيلو

  // ── Bucket — فئة التكلفة الداخلية ─────────────────────────────────────────
  // A: 1.5$–2.2$   B: 2.2$–3$   C: 3$–3.8$
  // يُحدَّد تلقائياً من supplierCost إذا لم يُحدَّد يدوياً
  bucket: {
    type: String,
    enum: ['A', 'B', 'C'],
    required: true
  },

  // ── Smart Rotation ────────────────────────────────────────────────────────
  // كلما ارتفع refundRiskScore → يقل وزن المنتج في السحب العشوائي
  refundRiskScore: { type: Number, default: 2, min: 1, max: 5 },
  // وزن السحب الحالي (يُعدَّل تلقائياً بواسطة Smart Rotation job)
  selectionWeight: { type: Number, default: 100 },
  avgRating:       { type: Number, default: 0, min: 0, max: 5 },
  ratingCount:     { type: Number, default: 0 },
  droppedCount:    { type: Number, default: 0 },

  // ── منتج إضافي صغير ──────────────────────────────────────────────────────
  // isBonus = true → هذا المنتج يُختار دائماً كالإضافي (Bucket A فقط)
  isBonus: { type: Boolean, default: false },

  // ── المخزون والحالة ───────────────────────────────────────────────────────
  stock:    { type: Number, default: -1 }, // -1 = unlimited
  isActive: { type: Boolean, default: true },

  // ── Provider ──────────────────────────────────────────────────────────────
  provider:   { type: mongoose.Schema.Types.ObjectId, ref: 'Provider', default: null },
  externalId: { type: String },

  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }

}, { timestamps: true });

// Auto-assign bucket from supplierCost if not set
itemSchema.pre('save', function (next) {
  if (!this.bucket && this.supplierCost) {
    if      (this.supplierCost < 2.2) this.bucket = 'A';
    else if (this.supplierCost < 3.0) this.bucket = 'B';
    else                               this.bucket = 'C';
  }
  next();
});

// الهامش الداخلي (للأدمن فقط)
itemSchema.virtual('internalMargin').get(function () {
  const cost  = this.supplierCost + this.estimatedShipping;
  const price = this.marketValue;
  return price > 0 ? +((price - cost) / price * 100).toFixed(1) : 0;
});

itemSchema.index({ bucket: 1, isActive: 1, isBonus: 1 });
itemSchema.index({ refundRiskScore: 1 });
itemSchema.index({ type: 1 });

module.exports = mongoose.model('Item', itemSchema);
