const mongoose = require('mongoose');

const developerPayoutSchema = new mongoose.Schema({
  developer: { type: mongoose.Schema.Types.ObjectId, ref: 'Developer', required: true },
  amount:    { type: Number, required: true, min: 1 },

  method:  { type: String, enum: ['crypto', 'bank', 'paypal'], default: 'crypto' },
  address: { type: String, required: true }, // wallet address or bank details

  status: {
    type:    String,
    enum:    ['pending', 'processing', 'completed', 'rejected'],
    default: 'pending'
  },

  txHash:     { type: String },  // blockchain tx hash
  processedAt:{ type: Date },
  processedBy:{ type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  rejectedReason: { type: String },
  notes:      { type: String }
}, { timestamps: true });

developerPayoutSchema.index({ developer: 1, createdAt: -1 });
developerPayoutSchema.index({ status: 1 });

module.exports = mongoose.model('DeveloperPayout', developerPayoutSchema);
