/**
 * notify.service.js — Unified Notification System
 *
 * كل حدث في المنصة يمر عبر هذا الملف.
 * يحفظ الإشعار في DB، يرسله real-time عبر Socket.IO، ويرسل email اختياريًا.
 *
 * الاستخدام:
 *   const notify = require('./notify.service');
 *   await notify.send(userId, 'item_won', { title, message, data });
 *   await notify.itemWon(user, item, boxName);
 */

const Notification = require('../models/Notification');
const logger       = require('../utils/logger');
const { LANG, PLATFORM } = require('../config/islamic.config');

// Icon map per type
const ICONS = {
  item_won:            '🎁',
  box_opened:          '📦',
  commission_earned:   '💰',
  milestone_reached:   '🏆',
  deposit_confirmed:   '✅',
  withdrawal_processed:'🏦',
  gift_received:       '🎀',
  gift_sent:           '📤',
  mission_completed:   '⚡',
  level_up:            '⬆️',
  tier_upgrade:        '💎',
  stop_loss_triggered: '🛑',
  event_started:       '🎉',
  event_ending:        '⏳',
  system:              '🔔'
};

// ── Core: create + emit ───────────────────────────────────────────────────────
async function send(userId, type, { title, message, data = {} } = {}) {
  try {
    const notif = await Notification.create({
      user: userId, type,
      title, message,
      icon: ICONS[type] || '🔔',
      data
    });

    // Real-time via Socket.IO (if available)
    const app = global._expressApp;
    if (app) {
      const io = app.get('io');
      if (io) {
        io.to(`user:${userId.toString()}`).emit('notification', {
          id:      notif._id,
          type, title, message,
          icon:    notif.icon,
          data,
          createdAt: notif.createdAt
        });
      }
    }

    return notif;
  } catch (err) {
    logger.error(`Notification failed [${type}]: ${err.message}`);
    return null;
  }
}

// ── Pre-built notification senders ───────────────────────────────────────────

async function itemWon(user, item, boxName) {
  return send(user._id, 'item_won', {
    title:   `📦 ${LANG.itemReceived(item.name)}`,
    message: `من ${LANG.boxOpened(boxName)} — القيمة: $${item.value} — ${LANG.goodWishes}`,
    data:    { item, boxName }
  });
}

async function commissionEarned(userId, amount, fromUsername) {
  return send(userId, 'commission_earned', {
    title:   `🤝 مكافأة إحالة $${amount}`,
    message: `من فتح ${fromUsername} للصندوق`,
    data:    { amount, fromUsername }
  });
}

async function milestoneReached(userId, milestone, reward) {
  return send(userId, 'milestone_reached', {
    title:   `🏆 مبروك! وصلت ${milestone} إحالة نشطة`,
    message: reward > 0 ? `مكافأتك: $${reward} أُضيفت لمحفظتك` : 'تم تسجيل الإنجاز',
    data:    { milestone, reward }
  });
}

async function depositConfirmed(userId, amount, method) {
  return send(userId, 'deposit_confirmed', {
    title:   `✅ تم إيداع $${amount}`,
    message: `عبر ${method} — محفظتك جاهزة الآن`,
    data:    { amount, method }
  });
}

async function withdrawalProcessed(userId, amount, status) {
  return send(userId, 'withdrawal_processed', {
    title:   status === 'completed' ? `🏦 تم تحويل $${amount}` : `❌ رُفض طلب السحب $${amount}`,
    message: status === 'completed' ? 'تم الإتمام — تحقق من محفظتك الخارجية' : 'راجع بريدك للتفاصيل',
    data:    { amount, status }
  });
}

async function giftReceived(receiverId, senderName, itemName, giftId) {
  return send(receiverId, 'gift_received', {
    title:   `🎀 هدية من ${senderName}`,
    message: `أرسل لك "${itemName}" — اقبل الهدية من المخزون`,
    data:    { senderName, itemName, giftId }
  });
}

async function missionCompleted(userId, missionLabel, xp, cash) {
  const rewardText = [xp > 0 && `${xp} XP`, cash > 0 && `$${cash}`].filter(Boolean).join(' + ');
  return send(userId, 'mission_completed', {
    title:   `⚡ مهمة مكتملة!`,
    message: `${missionLabel} — مكافأة: ${rewardText}`,
    data:    { missionLabel, xp, cash }
  });
}

async function levelUp(userId, newLevel, loyaltyDiscount = 0) {
  return send(userId, 'level_up', {
    title:   `⬆️ وصلت المستوى ${newLevel}!`,
    message: `خصم الولاء: ${(loyaltyDiscount * 100).toFixed(1)}% على طلبك التالي`,  // خصم تجاري مشروع
    data:    { newLevel, loyaltyDiscount }
  });
}

async function tierUpgrade(userId, oldTier, newTier, newRate) {
  return send(userId, 'tier_upgrade', {
    title:   `💎 ترقية إلى ${newTier.toUpperCase()}!`,
    message: `معدل عمولتك الآن ${(newRate * 100).toFixed(0)}% — استمر في الإحالة`,
    data:    { oldTier, newTier, newRate }
  });
}

async function eventStarted(userId, eventName, endAt) {
  return send(userId, 'event_started', {
    title:   `🎉 حدث خاص: ${eventName}`,
    message: `ينتهي ${new Date(endAt).toLocaleDateString('ar')} — فرصة محدودة!`,
    data:    { eventName, endAt }
  });
}

async function stopLossTriggered(adminId, boxName) {
  return send(adminId, 'stop_loss_triggered', {
    title:   `🛑 إيقاف تلقائي: ${boxName}`,
    message: `الصندوق تم إيقافه لانخفاض ROI — راجع لوحة التحكم`,
    data:    { boxName }
  });
}

// ── Bulk: notify all active users (for events) ────────────────────────────────
async function broadcast(userIds, type, payload) {
  const results = await Promise.allSettled(
    userIds.map(uid => send(uid, type, payload))
  );
  const succeeded = results.filter(r => r.status === 'fulfilled').length;
  logger.info(`Broadcast [${type}]: ${succeeded}/${userIds.length} delivered`);
  return succeeded;
}

module.exports = {
  send, broadcast,
  itemWon, commissionEarned, milestoneReached,
  depositConfirmed, withdrawalProcessed,
  giftReceived, missionCompleted, levelUp, tierUpgrade,
  eventStarted, stopLossTriggered
};
