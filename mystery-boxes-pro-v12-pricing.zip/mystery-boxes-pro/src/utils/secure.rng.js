/**
 * secure.rng.js — Cryptographically secure RNG
 *
 * FIXED: secureRandomInt previously used modulo (%) which introduces bias
 * when 2^32 is not evenly divisible by range. Fixed with rejection sampling.
 */
const crypto = require('crypto');

/** Secure float in [0, 1) */
function secureRandom() {
  const buf = crypto.randomBytes(4);
  return buf.readUInt32BE(0) / 0x100000000;
}

/**
 * Secure integer in [min, max] inclusive — NO modulo bias.
 * Uses rejection sampling: discards values in the biased tail.
 */
function secureRandomInt(min, max) {
  if (min > max) throw new Error('min must be <= max');
  const range = max - min + 1;
  // Largest multiple of range that fits in uint32
  const limit = Math.floor(0x100000000 / range) * range;
  let val;
  do {
    val = crypto.randomBytes(4).readUInt32BE(0);
  } while (val >= limit); // reject biased tail — expected iterations < 2
  return min + (val % range);
}

/** Pick a random element from an array — unbiased */
function securePickFrom(arr) {
  if (!arr || arr.length === 0) return null;
  if (arr.length === 1) return arr[0];
  return arr[secureRandomInt(0, arr.length - 1)];
}

/** Secure hex token */
function secureToken(bytes = 32) {
  return crypto.randomBytes(bytes).toString('hex');
}

/**
 * Weighted random pick — uses secureRandom() not Math.random().
 * items: [{ value, weight }, ...]
 */
function weightedRandom(items) {
  const total = items.reduce((s, i) => s + i.weight, 0);
  let rand    = secureRandom() * total;
  for (const item of items) {
    rand -= item.weight;
    if (rand <= 0) return item.value;
  }
  return items[items.length - 1].value;
}

module.exports = { secureRandom, secureRandomInt, securePickFrom, secureToken, weightedRandom };
