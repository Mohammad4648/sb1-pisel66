const express = require('express');
const router  = express.Router();
const box     = require('../controllers/box.controller');
const { protect } = require('../middleware/auth.middleware');

// Verify a specific order's provably fair result (requires auth)
router.get('/verify/:orderId', protect, box.verifyOpen);

module.exports = router;
