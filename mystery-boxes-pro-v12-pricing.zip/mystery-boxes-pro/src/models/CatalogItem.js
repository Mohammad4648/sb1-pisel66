/**
 * CatalogItem.js — كتالوج المنتجات (1K–50K منتج)
 *
 * يختلف عن Item.js في شيء واحد:
 *   الصندوق يحتوي catalogFilter (فئة + نطاق سعر)
 *   بدلاً من items:[IDs]
 *   → MongoDB $sample يختار عشوائياً وقت الفتح
 *
 * الأدمن يُضيف المنتجات مباشرة عبر API key خاص به.
 */
const mongoose = require('mongoose');

const catalogItemSchema = new mongoose.Schema({
  name:        { type: String, required: true, trim: true, maxlength: 200 },
  description: { type: String, maxlength: 500 },
  image:       { type: String },
  sku:         { type: String, trim: true },  // رقم مرجعي داخلي

  // التصنيف — يطابق category الصندوق
  category: {
    type:     String,
    required: true,
    enum:     ['electronics','accessories','clothing','home','stationery','other'],
    index:    true,
  },
  subCategory: { type: String },

  // التسعير — مُدقَّق عند الإضافة (85%–115% من سعر الصندوق)
  marketValue:       { type: Number, required: true, min: 0, index: true },
  supplierCost:      { type: Number, required: true, min: 0 },
  estimatedShipping: { type: Number, default: 0.90 },

  // الجودة
  selectionWeight: { type: Number, default: 100, min: 1, max: 100 },
  refundRiskScore: { type: Number, default: 2, min: 1, max: 5 },
  avgRating:       { type: Number, default: 0 },
  ratingCount:     { type: Number, default: 0 },

  // الحلال
  halalVerified: { type: Boolean, default: true },   // الأدمن يضيفه مباشرة = موثوق
  halalRejected: { type: Boolean, default: false },

  isActive: { type: Boolean, default: true, index: true },
  source:     { type: String, enum: ['manual','cj','aliexpress'], default: 'manual', index: true },
  externalId: { type: String },  // ID في المصدر الخارجي
  externalUrl:{ type: String },  // رابط المنتج الأصلي
  pendingReview: { type: Boolean, default: false }, // true للمنتجات الخارجية
  addedBy:    { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  notes:    { type: String },

}, { timestamps: true });

// Index مركّب للـ$sample السريع
catalogItemSchema.index({ category: 1, isActive: 1, marketValue: 1 });
catalogItemSchema.index({ source: 1, isActive: 1 });
catalogItemSchema.index({ externalId: 1, source: 1 }, { unique: true, sparse: true });
catalogItemSchema.index(
  { category: 1, marketValue: 1, selectionWeight: -1 },
  { partialFilterExpression: { isActive: true, halalRejected: false } }
);

module.exports = mongoose.model('CatalogItem', catalogItemSchema);
