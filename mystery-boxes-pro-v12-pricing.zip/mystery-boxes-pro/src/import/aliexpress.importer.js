/**
 * aliexpress.importer.js — استيراد من AliExpress
 *
 * AliExpress Affiliate API (Admitad / AliExpress DS API):
 *   https://developers.aliexpress.com/doc.htm
 *
 * طريقتان:
 *   A) AliExpress Dropshipping API (DS) — للـdropshipping المباشر
 *   B) AliExpress Affiliate API       — للبحث عن المنتجات
 *
 * يُفعَّل عبر:
 *   ALIEXPRESS_APP_KEY + ALIEXPRESS_APP_SECRET في .env
 *
 * OR نُستخدم scraping/RSS إذا لم يتوفر مفتاح API
 */

const axios   = require('axios');
const crypto  = require('crypto');
const CatalogItem      = require('../models/CatalogItem');
const { validateItemHalal } = require('../services/halal.service');
const { catalogFilter: getPriceFilter, validateProductCost, validateMarketValue } = require('../services/pricing.engine.v2');
const logger  = require('../utils/logger');

const AE_BASE    = 'https://api-sg.aliexpress.com/sync';
const APP_KEY    = process.env.ALIEXPRESS_APP_KEY;
const APP_SECRET = process.env.ALIEXPRESS_APP_SECRET;

// ── خريطة تصنيفات AliExpress → تصنيفاتنا ─────────────────────────────────
const CATEGORY_MAP = {
  200000346: 'electronics',   // Consumer Electronics
  200000855: 'electronics',   // Phones & Accessories
  100003070: 'electronics',   // Computer, Office & Security
  200001075: 'clothing',      // Women's Clothing
  200000636: 'clothing',      // Men's Clothing
  200000534: 'accessories',   // Luggage, Bags & Shoes
  200001492: 'accessories',   // Watches, Jewelry
  200000527: 'home',          // Home & Garden
  200000789: 'home',          // Kitchen, Dining & Bar
  200000126: 'stationery',    // Office & School Supplies
  200000147: 'stationery',    // Toys & Hobbies
  200000784: 'accessories',   // Sports, Fitness
  200000342: 'accessories',   // Beauty & Health
};

// ── توقيع AliExpress API ────────────────────────────────────────────────────
function signRequest(params) {
  const sorted = Object.keys(params).sort().map(k => `${k}${params[k]}`).join('');
  return crypto.createHmac('md5', APP_SECRET)
    .update(APP_SECRET + sorted + APP_SECRET)
    .digest('hex').toUpperCase();
}

function buildParams(method, extra = {}) {
  const base = {
    method,
    app_key:    APP_KEY,
    timestamp:  new Date().toISOString().replace('T', ' ').slice(0, 19),
    sign_method:'md5',
    format:     'json',
    v:          '2.0',
    ...extra,
  };
  base.sign = signRequest(base);
  return base;
}

// ── تحويل منتج AliExpress → نموذجنا ────────────────────────────────────────
function transformAEProduct(p, boxPrice) {
  const price = parseFloat(
    p.target_sale_price || p.sale_price || p.original_price || '0'
  );
  const supplierCost = price;
  const shipping     = parseFloat(p.ship_to_days ? 1.5 : 0.9);
  const marketValue  = +(supplierCost * 1.75).toFixed(2);

  // تحقق من تكلفة المورد
  if (boxPrice) {
    const costCheck = validateProductCost(supplierCost, boxPrice);
    if (!costCheck.valid) return null;

    const mvCheck = validateMarketValue(marketValue, boxPrice);
    if (!mvCheck.valid) {
      if (marketValue < mvCheck.range.min) return null;
      if (marketValue > mvCheck.range.max) marketValue = mvCheck.range.max;
    }
  }

  const catId = p.first_level_category_id;
  const category = CATEGORY_MAP[catId] || 'other';

  return {
    name:              (p.product_title || '').trim().slice(0, 200),
    description:       '',
    image:             p.product_main_image_url || '',
    sku:               String(p.product_id || ''),
    category,
    subCategory:       p.second_level_category_name || '',
    marketValue,
    supplierCost,
    estimatedShipping: shipping,
    selectionWeight:   Math.min(100, Math.round((parseFloat(p.evaluate_rate || '50') / 100) * 100)),
    avgRating:         parseFloat((p.evaluate_rate || '0').replace('%', '')) / 20, // 0-5
    ratingCount:       0,
    refundRiskScore:   2,
    source:            'aliexpress',
    externalId:        String(p.product_id),
    externalUrl:       p.product_detail_url || `https://aliexpress.com/item/${p.product_id}.html`,
    isActive:          false,
    halalVerified:     false,
    pendingReview:     true,
  };
}

// ── استيراد حسب كلمة بحث أو تصنيف ─────────────────────────────────────────
async function importByKeyword(keyword, opts = {}) {
  const { boxPrice = null, limit = 500, pageSize = 50 } = opts;

  if (!APP_KEY || !APP_SECRET)
    throw new Error('ALIEXPRESS_APP_KEY + ALIEXPRESS_APP_SECRET مطلوبان في .env');

  const stats = { fetched: 0, imported: 0, skipped: 0, haram: 0, outOfRange: 0 };
  let page = 1;

  logger.info(`AE Import: keyword="${keyword}" limit=${limit}`);

  while (stats.imported < limit) {
    const batchSize = Math.min(pageSize, limit - stats.imported, 50);

    let res;
    try {
      res = await axios.get(AE_BASE, {
        params: buildParams('aliexpress.affiliate.product.query', {
          keywords:          keyword,
          page_no:           page,
          page_size:         batchSize,
          fields:            'product_id,product_title,target_sale_price,sale_price,product_main_image_url,evaluate_rate,first_level_category_id,second_level_category_name,product_detail_url',
          target_currency:   'USD',
          target_language:   'EN',
          sort:              'SALE_PRICE_ASC',
          // supplierCost range من محرك التسعير
          ...(() => { const pf = boxPrice ? getPriceFilter(boxPrice) : { priceMin:1, priceMax:500 }; return { min_sale_price: Math.floor(pf.priceMin), max_sale_price: Math.ceil(pf.priceMax) }; })(),
        }),
      });
    } catch (e) {
      logger.error(`AE API error p${page}: ${e.message}`);
      break;
    }

    const list = res.data?.aliexpress_affiliate_product_query_response?.resp_result?.result?.products?.product || [];
    if (!list.length) break;
    stats.fetched += list.length;

    const docs = [];
    for (const p of list) {
      const halal = validateItemHalal({ name: p.product_title, description: '', productCategory: '' });
      if (!halal.halal) { stats.haram++; continue; }

      const doc = transformAEProduct(p, boxPrice);
      if (!doc)              { stats.outOfRange++; continue; }
      if (!doc.name || doc.supplierCost <= 0) { stats.skipped++; continue; }

      docs.push(doc);
    }

    if (docs.length) {
      await CatalogItem.insertMany(docs, { ordered: false }).catch(() => {});
      stats.imported += docs.length;
    }

    page++;
    await new Promise(r => setTimeout(r, 800)); // AE rate limit أبطأ من CJ
  }

  logger.info(`AE Import done: ${JSON.stringify(stats)}`);
  return stats;
}

// ── استيراد حسب تصنيف AliExpress ────────────────────────────────────────────
async function importByCategory(categoryId, opts = {}) {
  const { boxPrice = null, limit = 500, pageSize = 50 } = opts;

  if (!APP_KEY || !APP_SECRET)
    throw new Error('ALIEXPRESS_APP_KEY + ALIEXPRESS_APP_SECRET مطلوبان في .env');

  const stats = { fetched: 0, imported: 0, skipped: 0, haram: 0, outOfRange: 0 };
  let page = 1;

  while (stats.imported < limit) {
    let res;
    try {
      res = await axios.get(AE_BASE, {
        params: buildParams('aliexpress.affiliate.category.get', {
          app_signature: '',
        }),
      });
      // ثم استخدم category_id في query
      res = await axios.get(AE_BASE, {
        params: buildParams('aliexpress.affiliate.product.query', {
          category_ids:  categoryId,
          page_no:       page,
          page_size:     Math.min(pageSize, 50),
          fields:        'product_id,product_title,target_sale_price,sale_price,product_main_image_url,evaluate_rate,first_level_category_id,second_level_category_name',
          target_currency: 'USD',
          sort:          'LAST_VOLUME_DESC',
        }),
      });
    } catch (e) {
      logger.error(`AE category import error: ${e.message}`);
      break;
    }

    const list = res.data?.aliexpress_affiliate_product_query_response?.resp_result?.result?.products?.product || [];
    if (!list.length) break;
    stats.fetched += list.length;

    const docs = [];
    for (const p of list) {
      const halal = validateItemHalal({ name: p.product_title, description: '', productCategory: '' });
      if (!halal.halal) { stats.haram++; continue; }
      const doc = transformAEProduct(p, boxPrice);
      if (!doc) { stats.outOfRange++; continue; }
      docs.push(doc);
    }

    if (docs.length) {
      await CatalogItem.insertMany(docs, { ordered: false }).catch(() => {});
      stats.imported += docs.length;
    }
    if (stats.imported >= limit) break;
    page++;
    await new Promise(r => setTimeout(r, 800));
  }

  logger.info(`AE category import done: ${JSON.stringify(stats)}`);
  return stats;
}

// ── مزامنة أسعار ──────────────────────────────────────────────────────────
async function syncPrices() {
  const items = await CatalogItem.find({ source: 'aliexpress', isActive: true })
    .select('externalId supplierCost marketValue').limit(500);

  const ids = items.map(i => i.externalId).join(',');
  if (!ids) return { updated: 0 };

  try {
    const res = await axios.get(AE_BASE, {
      params: buildParams('aliexpress.affiliate.product.detail.get', {
        product_ids:     ids,
        fields:          'product_id,target_sale_price',
        target_currency: 'USD',
      }),
    });

    const products = res.data?.aliexpress_affiliate_product_detail_get_response?.resp_result?.result?.products?.product || [];
    let updated = 0;

    for (const p of products) {
      const item = items.find(i => i.externalId === String(p.product_id));
      if (!item) continue;
      const newCost = parseFloat(p.target_sale_price || 0);
      if (Math.abs(newCost - item.supplierCost) > 0.10) {
        await CatalogItem.findByIdAndUpdate(item._id, {
          supplierCost: newCost,
          marketValue:  +(newCost * 1.75).toFixed(2),
        });
        updated++;
      }
    }

    return { updated, total: items.length };
  } catch (e) {
    logger.error(`AE syncPrices: ${e.message}`);
    return { updated: 0, error: e.message };
  }
}

module.exports = { importByKeyword, importByCategory, syncPrices, CATEGORY_MAP };
