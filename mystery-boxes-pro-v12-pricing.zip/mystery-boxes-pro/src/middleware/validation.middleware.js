const { body } = require('express-validator');

exports.registerValidation = [
  body('username')
    .trim()
    .isLength({ min: 3, max: 30 })
    .withMessage('Username must be 3-30 characters'),
  body('email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email'),
  body('password')
    .isLength({ min: 6 })
    .withMessage('Password must be at least 6 characters')
];

exports.loginValidation = [
  body('email').isEmail().normalizeEmail().withMessage('Valid email required'),
  body('password').notEmpty().withMessage('Password required')
];

exports.depositValidation = [
  body('amount')
    .isFloat({ min: 1, max: 10000 })
    .withMessage('Amount must be between $1 and $10,000')
];

exports.withdrawValidation = [
  body('amount')
    .isFloat({ min: 5 })
    .withMessage('Minimum withdrawal is $5'),
  body('method')
    .optional()
    .isIn(['bank', 'paypal', 'crypto'])
    .withMessage('Invalid withdrawal method')
];
