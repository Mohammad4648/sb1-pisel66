/**
 * AdminCatalogKey.js — مفتاح API واحد للأدمن
 *
 * مفتاح واحد فقط — الأدمن يستخدمه لإدارة الكتالوج
 * من أي أداة خارجية (Postman / script / Excel plugin)
 *
 * التوليد: POST /admin/catalog/generate-key
 * الاستخدام: Authorization: Bearer ck_xxxxxxxxxxxx
 */
const mongoose = require('mongoose');
const crypto   = require('crypto');

const adminKeySchema = new mongoose.Schema({
  label:     { type: String, default: 'Admin Catalog Key' },
  keyHash:   { type: String, required: true, select: false },
  keyPrefix: { type: String, required: true },  // ck_AbCd... للتعرف
  isActive:  { type: Boolean, default: true },
  lastUsedAt:{ type: Date },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
}, { timestamps: true });

adminKeySchema.statics.generate = function () {
  const raw    = 'ck_' + crypto.randomBytes(28).toString('base64url');
  const hash   = crypto.createHash('sha256').update(raw).digest('hex');
  const prefix = raw.slice(0, 10) + '...';
  return { raw, hash, prefix };
};

adminKeySchema.statics.verify = async function (rawKey) {
  if (!rawKey?.startsWith('ck_')) return null;
  const hash = crypto.createHash('sha256').update(rawKey).digest('hex');
  const key  = await this.findOne({ keyHash: hash, isActive: true }).select('+keyHash');
  if (key) await this.findByIdAndUpdate(key._id, { lastUsedAt: new Date() });
  return key;
};

module.exports = mongoose.model('AdminCatalogKey', adminKeySchema);
