const express = require('express');
const router  = express.Router();
const box     = require('../controllers/box.controller');
const { protect, authorize } = require('../middleware/auth.middleware');
const { limitOpenBox }       = require('../middleware/rateLimiter.middleware');

router.get('/',    box.getBoxes);
router.get('/trial/eligibility', protect, box.getTrialEligibility);
router.get('/:id', box.getBox);

router.post('/:id/open', protect, limitOpenBox, box.openBox);
router.get('/verify/:orderId', protect, box.verifyOpen);

// Admin
router.post('/',                 protect, authorize('admin'), box.createBox);
router.put('/:id',               protect, authorize('admin'), box.updateBox);
router.delete('/:id',            protect, authorize('admin'), box.deleteBox);
router.post('/pricing/preview',  protect, authorize('admin'), box.previewPricing);
router.get('/:id/roi',           protect, authorize('admin'), box.getBoxROI);

module.exports = router;
