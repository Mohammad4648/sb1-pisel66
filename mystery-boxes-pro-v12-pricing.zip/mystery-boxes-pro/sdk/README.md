# MysteryBox SDK

JavaScript/Node.js SDK for the Mystery Rewards Platform B2B API.

## Install

```bash
# Copy mysterybox-sdk.js to your project, or:
npm install mysterybox-sdk  # (when published)
```

## Quick Start

```javascript
const { MysteryBox } = require('./mysterybox-sdk')

const mb = new MysteryBox(
  'mbp_your_api_key',
  'sec_your_api_secret',
  { baseUrl: 'https://your-platform.com/api/dev' }
)

// Open a box
const result = await mb.openBox({
  userId:    'player_123',
  boxId:     '64abc123...',
  sourceApp: 'MyGame'
})

console.log(result.reward)
// { name: 'Steam Gift Card', rarity: 'rare', value: 10 }
```

## API Reference

### `mb.openBox({ userId, boxId, clientSeed?, sourceApp? })`
Open a mystery box for a user in your system.

```javascript
const result = await mb.openBox({
  userId:     'player_123',   // Required: user ID in your system
  boxId:      '64abc123',     // Required: box ID from listBoxes()
  clientSeed: 'custom-seed',  // Optional: for provably fair verification
  sourceApp:  'TelegramBot'   // Optional: identify your app in reports
})
// Returns: { reward, orderId, fairness, commission }
```

### `mb.listBoxes({ category?, boxType? })`
```javascript
const { boxes } = await mb.listBoxes({ boxType: 'digital' })
```

### `mb.getStats(days = 30)`
```javascript
const { developer, stats } = await mb.getStats(7)
// stats: { opens, revenue, commission, dailyChart }
```

### `mb.requestWithdraw({ amount, method, address })`
```javascript
await mb.requestWithdraw({ amount: 50, method: 'crypto', address: 'TRX...' })
```

### `MysteryBox.verifyWebhook(secret, timestamp, body, signature)`
Verify incoming webhooks are authentic.

---

## Webhook Events

Your `webhookUrl` receives POST requests for these events:

| Event | When |
|-------|------|
| `box_opened` | Every successful box open |
| `commission_credited` | Commission added to your balance |
| `payout_processed` | Your withdrawal was completed |

### Verify webhooks

```javascript
app.post('/webhook', express.json(), (req, res) => {
  const valid = MysteryBox.verifyWebhook(
    process.env.MB_WEBHOOK_SECRET,
    req.headers['x-webhook-timestamp'],
    req.body,
    req.headers['x-webhook-signature']
  )
  if (!valid) return res.sendStatus(401)

  const { event, externalUserId, reward } = req.body
  if (event === 'box_opened') {
    // Credit reward in your game
  }
  res.sendStatus(200)
})
```

---

## Signing Requests

All requests are signed with HMAC-SHA256:

```
Signature = HMAC-SHA256(apiSecret, timestamp + '.' + JSON.stringify(body))
```

Headers sent automatically by the SDK:
- `x-api-key`
- `x-timestamp`
- `x-signature`

---

## Telegram Bot Example

```javascript
const { Telegraf } = require('telegraf')
const { MysteryBox } = require('./mysterybox-sdk')

const bot = new Telegraf(process.env.BOT_TOKEN)
const mb  = new MysteryBox(process.env.API_KEY, process.env.API_SECRET)

bot.command('open', async (ctx) => {
  const result = await mb.openBox({
    userId:    String(ctx.from.id),
    boxId:     process.env.DEFAULT_BOX_ID,
    sourceApp: 'TelegramBot'
  })
  const { name, rarity, value } = result.reward
  ctx.reply(`🎉 You won *${name}* (${rarity}) — $${value}!`, { parse_mode: 'Markdown' })
})

bot.launch()
```

---

## Commission Model

```
Box Price:   $1.00
Item Cost:   $0.60  (prize value)
Platform Profit: $0.40

Your commission (20% of profit): $0.08 per open
100 opens/day → $8/day → $240/month
```
