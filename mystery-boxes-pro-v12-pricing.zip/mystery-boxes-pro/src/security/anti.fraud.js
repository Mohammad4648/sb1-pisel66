/**
 * anti.fraud.js
 *
 * Detects and blocks fraud patterns:
 *   1. Multi-account from same IP
 *   2. Self-referral
 *   3. Velocity abuse (too many opens in short time)
 *   4. Device fingerprint tracking (optional — from frontend header)
 *
 * Middleware + service functions for use in routes.
 */

const User   = require('../models/User');
const logger = require('../utils/logger');

// In-memory store for fraud signals (can be upgraded to Redis)
const ipRegistry    = new Map(); // ip → [userId, ...]
const deviceRegistry = new Map(); // fingerprint → [userId, ...]

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

function getClientIP(req) {
  return (req.headers['x-forwarded-for'] || '').split(',')[0].trim()
    || req.headers['x-real-ip']
    || req.connection?.remoteAddress
    || req.ip
    || 'unknown';
}

function getFingerprint(req) {
  return req.headers['x-device-fingerprint'] || null;
}

// ─────────────────────────────────────────────────────────────────────────────
// Register a new user's IP/device (call on register)
// ─────────────────────────────────────────────────────────────────────────────
function registerUserDevice(userId, ip, fingerprint) {
  const uid = userId.toString();

  const ipUsers = ipRegistry.get(ip) || new Set();
  ipUsers.add(uid);
  ipRegistry.set(ip, ipUsers);

  if (fingerprint) {
    const fpUsers = deviceRegistry.get(fingerprint) || new Set();
    fpUsers.add(uid);
    deviceRegistry.set(fingerprint, fpUsers);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Checks
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Check if IP already has too many accounts (max 3 by default).
 */
function ipHasTooManyAccounts(ip, maxAccounts = 3) {
  const users = ipRegistry.get(ip);
  return users && users.size >= maxAccounts;
}

/**
 * Check if referral code is being used by someone on the same device/IP.
 * Prevents self-referral.
 */
async function isSelfReferral(referralCode, newUserId, ip, fingerprint) {
  const referrer = await User.findOne({ referralCode }).select('_id');
  if (!referrer) return false;

  const referrerId = referrer._id.toString();

  // Direct user ID match
  if (referrerId === newUserId.toString()) return true;

  // Same IP as referrer
  const ipUsers = ipRegistry.get(ip) || new Set();
  if (ipUsers.has(referrerId)) {
    logger.warn(`Self-referral detected via IP: ${ip}`);
    return true;
  }

  // Same device fingerprint
  if (fingerprint) {
    const fpUsers = deviceRegistry.get(fingerprint) || new Set();
    if (fpUsers.has(referrerId)) {
      logger.warn(`Self-referral detected via fingerprint`);
      return true;
    }
  }

  return false;
}

// ─────────────────────────────────────────────────────────────────────────────
// Middleware
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Block registration if IP already has too many accounts.
 */
const blockMultiAccount = (maxPerIP = 3) => async (req, res, next) => {
  const ip = getClientIP(req);
  if (ipHasTooManyAccounts(ip, maxPerIP)) {
    logger.warn(`Multi-account block: IP ${ip} has ≥${maxPerIP} accounts`);
    return res.status(403).json({
      success: false,
      message: 'Account creation limit reached from this network.'
    });
  }
  req.clientIP       = ip;
  req.deviceFingerprint = getFingerprint(req);
  next();
};

/**
 * Attach IP + fingerprint to request for downstream use.
 */
const attachDeviceInfo = (req, res, next) => {
  req.clientIP          = getClientIP(req);
  req.deviceFingerprint = getFingerprint(req);
  next();
};

/**
 * Check for suspicious open velocity — flag if >50 opens in 5 minutes
 * (beyond the rate limiter, this logs a fraud signal).
 */
const openVelocity = new Map(); // userId → [timestamps]

const checkOpenVelocity = (req, res, next) => {
  const uid  = req.user?.id?.toString();
  const now  = Date.now();
  const window = 5 * 60 * 1000; // 5 min
  const maxOpens = 50;

  const hits = (openVelocity.get(uid) || []).filter(t => now - t < window);
  hits.push(now);
  openVelocity.set(uid, hits);

  if (hits.length > maxOpens) {
    logger.warn(`🚨 Velocity abuse detected: user ${uid} opened ${hits.length} boxes in 5 min`);
    // Log but don't block — let rate limiter handle it
    req.fraudSignal = { type: 'velocity_abuse', opens: hits.length };
  }
  next();
};

module.exports = {
  registerUserDevice,
  ipHasTooManyAccounts,
  isSelfReferral,
  blockMultiAccount,
  attachDeviceInfo,
  checkOpenVelocity,
  getClientIP
};
