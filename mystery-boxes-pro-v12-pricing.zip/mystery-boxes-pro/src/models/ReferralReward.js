const mongoose = require('mongoose');

const referralRewardSchema = new mongoose.Schema({
  user:       { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  milestone:  { type: Number, required: true },
  rewardType: { type: String, enum: ['cash', 'coupon', 'xp'], required: true },
  amount:     { type: Number },
  couponCode: { type: String },
  claimed:    { type: Boolean, default: false },
  claimedAt:  { type: Date }
}, { timestamps: true });

referralRewardSchema.index({ user: 1, milestone: 1 }, { unique: true });
module.exports = mongoose.model('ReferralReward', referralRewardSchema);
