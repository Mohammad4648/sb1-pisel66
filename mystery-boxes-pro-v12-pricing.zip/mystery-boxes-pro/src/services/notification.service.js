/**
 * notification.service.js — v3 الإصدار الإسلامي
 */

const nodemailer = require('nodemailer');
const logger     = require('../utils/logger');
const { PLATFORM, LANG } = require('../config/islamic.config');

let transporter = null;

function getTransporter() {
  if (transporter) return transporter;
  if (!process.env.SMTP_HOST || !process.env.SMTP_USER) {
    logger.warn('SMTP not configured — emails logged to console');
    return null;
  }
  transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: parseInt(process.env.SMTP_PORT) || 587,
    secure: process.env.SMTP_PORT === '465',
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
  });
  return transporter;
}

async function send(to, subject, html) {
  const transport = getTransporter();
  if (!transport) { logger.info(`[EMAIL dev] To:${to} | ${subject}`); return; }
  try {
    await transport.sendMail({
      from: `"${PLATFORM.nameAr}" <${process.env.FROM_EMAIL || process.env.SMTP_USER}>`,
      to, subject, html
    });
  } catch (err) { logger.error(`Email failed ${to}: ${err.message}`); }
}

const base = (content) => `
<div dir="rtl" style="font-family:'Segoe UI',Tahoma,sans-serif;max-width:540px;margin:0 auto;background:#f0fdf4;border-radius:16px;overflow:hidden;border:2px solid #16a34a">
  <div style="background:linear-gradient(135deg,#15803d,#166534);padding:28px;text-align:center">
    <p style="margin:0 0 4px;font-size:12px;color:#bbf7d0">${PLATFORM.bismillah}</p>
    <h1 style="margin:0;font-size:22px;color:#fff">🏡 ${PLATFORM.nameAr}</h1>
    <p style="margin:4px 0 0;font-size:12px;color:#86efac">${PLATFORM.taglineAr}</p>
  </div>
  <div style="padding:32px;background:#fff">
    <p style="margin:0 0 20px;font-size:14px;color:#15803d">${PLATFORM.greeting}</p>
    ${content}
  </div>
  <div style="padding:14px;background:#f0fdf4;border-top:1px solid #bbf7d0;text-align:center">
    <p style="margin:0;font-size:12px;color:#16a34a">${PLATFORM.closing}</p>
    <p style="margin:4px 0 0;font-size:11px;color:#6b7280">© ${new Date().getFullYear()} ${PLATFORM.nameAr} — تسوّق حلال بلا قلق</p>
  </div>
</div>`;

exports.sendWelcome = async (user) => {
  const html = base(`
    <h2 style="color:#15803d">${LANG.welcome(user.username)} 🌿</h2>
    <p>حسابك جاهز — يمكنك شحن محفظتك واختيار صندوقك الأول.</p>
    <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:12px;padding:16px;margin:20px 0;text-align:center">
      <p style="margin:0 0 4px;color:#6b7280;font-size:12px">كود الإحالة</p>
      <p style="margin:0;font-size:22px;font-weight:700;color:#15803d;font-family:monospace">${user.referralCode}</p>
    </div>
    <p style="font-size:13px;color:#6b7280">📦 كل منتج معروض قبل الشراء — لا غرر ولا مجهول.</p>
    <p style="font-size:13px;color:#6b7280">🤲 فعّل خاصية الصدقة من إعداداتك لإضافة مبلغ صغير لصندوق الجمعية.</p>
  `);
  await send(user.email, `${PLATFORM.nameAr} — أهلاً بك`, html);
};

exports.sendBoxOpened = async (user, item, boxName) => {
  const html = base(`
    <h2 style="color:#15803d">الحمد لله — ${LANG.congrats} 🎁</h2>
    <p>${LANG.boxOpened(boxName)}</p>
    <div style="background:#f0fdf4;border:2px solid #16a34a;border-radius:14px;padding:24px;text-align:center;margin:16px 0">
      <p style="font-size:40px;margin:0">📦</p>
      <p style="font-size:20px;font-weight:700;color:#15803d;margin:10px 0 4px">${item.name}</p>
      <p style="color:#6b7280;font-size:14px">القيمة: <b style="color:#15803d">$${item.value}</b></p>
    </div>
    <p style="font-size:13px;color:#6b7280">سيتم التواصل معك لتنسيق الشحن إن شاء الله.</p>
    <p style="color:#15803d;text-align:center">${LANG.goodWishes} 🌿</p>
  `);
  await send(user.email, `${PLATFORM.nameAr} — ${LANG.itemReceived(item.name)}`, html);
};

exports.sendDepositConfirmed = async (user, amount, method = 'Binance Pay') => {
  const html = base(`
    <h2 style="color:#15803d">✅ ${LANG.depositMsg(amount)}</h2>
    <div style="background:#f0fdf4;border-radius:12px;padding:20px;text-align:center;margin:16px 0">
      <p style="font-size:36px;font-weight:700;color:#15803d;margin:0">+$${amount}</p>
      <p style="color:#6b7280;margin:6px 0 0;font-size:13px">عبر ${method}</p>
    </div>
    <p>رصيدك: <b style="color:#15803d">$${(user.walletBalance || amount).toFixed?.(2) || amount}</b></p>
  `);
  await send(user.email, `${PLATFORM.nameAr} — تم شحن المحفظة`, html);
};

exports.sendCommissionEarned = async (user, commission, fromUser) => {
  const html = base(`
    <h2 style="color:#15803d">🤝 ${LANG.commissionMsg(commission)}</h2>
    <div style="background:#f0fdf4;border-radius:12px;padding:20px;text-align:center;margin:16px 0">
      <p style="font-size:36px;font-weight:700;color:#15803d;margin:0">+$${commission}</p>
      <p style="color:#6b7280;margin:6px 0 0;font-size:13px">مكافأة إحالة من ${fromUser}</p>
    </div>
    <p style="font-size:13px;color:#6b7280">جزاك الله خيراً على دعوتك.</p>
  `);
  await send(user.email, `${PLATFORM.nameAr} — مكافأة إحالة $${commission}`, html);
};

exports.sendWithdrawalProcessed = async (user, amount, method) => {
  const html = base(`
    <h2 style="color:#15803d">🏦 ${LANG.withdrawMsg(amount)}</h2>
    <div style="background:#f0fdf4;border-radius:12px;padding:20px;text-align:center;margin:16px 0">
      <p style="font-size:36px;font-weight:700;color:#15803d;margin:0">$${amount}</p>
      <p style="color:#6b7280;margin:6px 0 0">${method}</p>
    </div>
    <p style="font-size:13px;color:#6b7280">قد يستغرق 1–3 أيام عمل بإذن الله.</p>
  `);
  await send(user.email, `${PLATFORM.nameAr} — تمت معالجة السحب`, html);
};

exports.sendSadaqaConfirmed = async (user, amount) => {
  const html = base(`
    <h2 style="color:#15803d">🤲 ${LANG.sadaqaMsg(amount)}</h2>
    <div style="background:#f0fdf4;border-radius:12px;padding:20px;text-align:center;margin:16px 0">
      <p style="font-size:40px;margin:0">🤲</p>
      <p style="font-size:28px;font-weight:700;color:#15803d;margin:8px 0">$${amount}</p>
      <p style="font-size:13px;color:#6b7280">وصلت للجمعية الخيرية المعتمدة</p>
    </div>
    <p style="font-size:13px;color:#6b7280;text-align:center">"إِنَّ الصَّدَقَاتِ لِلْفُقَرَاءِ وَالْمَسَاكِينِ" — التوبة ٦٠</p>
  `);
  await send(user.email, `${PLATFORM.nameAr} — صدقتك وصلت 🤲`, html);
};
