/**
 * import.controller.js — Admin API لإدارة الاستيراد
 *
 * POST /admin/catalog/import/run         ← تشغيل pipeline كامل
 * POST /admin/catalog/import/run-box     ← صندوق محدد فقط
 * POST /admin/catalog/import/sync-prices ← مزامنة أسعار
 * POST /admin/catalog/import/clean       ← تنظيف الكتالوج
 * GET  /admin/catalog/import/status      ← حالة الاستيراد + إحصاءات
 * GET  /admin/catalog/import/plan        ← خطة الاستيراد الكاملة
 */

const { runPipeline, cleanCatalog, syncAllPrices, IMPORT_PLAN } = require('../import/catalog.pipeline');
const CatalogItem = require('../models/CatalogItem');
const logger      = require('../utils/logger');

// حالة الـpipeline (في الذاكرة — يُعاد عند restart)
let pipelineState = { running: false, lastRun: null, lastReport: null };

// POST /admin/catalog/import/run
exports.runImport = async (req, res) => {
  if (pipelineState.running)
    return res.status(409).json({ success: false, message: 'الاستيراد يعمل الآن — انتظر انتهاءه' });

  const { sources, boxes, dryRun = false } = req.body;

  res.json({
    success: true,
    message: dryRun ? 'Dry run بدأ' : 'الاستيراد بدأ في الخلفية',
    note:    'استخدم GET /admin/catalog/import/status للمتابعة',
    estimatedTime: '5–30 دقيقة حسب الكمية',
  });

  // يعمل في الخلفية
  pipelineState.running = true;
  runPipeline({ sources, boxes, dryRun })
    .then(report => {
      pipelineState.running    = false;
      pipelineState.lastRun    = new Date();
      pipelineState.lastReport = report;
      logger.info('Pipeline finished: ' + report.duration);
    })
    .catch(e => {
      pipelineState.running = false;
      logger.error('Pipeline error: ' + e.message);
    });
};

// POST /admin/catalog/import/run-box
exports.runBoxImport = async (req, res) => {
  const { box, source, limit = 200 } = req.body;
  if (!box) return res.status(400).json({ success: false, message: 'box مطلوب' });

  try {
    const report = await runPipeline({
      boxes:   [box],
      sources: source ? [source] : ['cj', 'ae'],
    });
    res.json({ success: true, report });
  } catch (e) {
    res.status(500).json({ success: false, message: e.message });
  }
};

// POST /admin/catalog/import/sync-prices
exports.syncPrices = async (req, res) => {
  try {
    const result = await syncAllPrices();
    res.json({ success: true, result });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// POST /admin/catalog/import/clean
exports.clean = async (req, res) => {
  try {
    const result = await cleanCatalog();
    res.json({ success: true, result });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// GET /admin/catalog/import/status
exports.getStatus = async (req, res) => {
  try {
    const [total, active, pending, rejected, bySource, byBox] = await Promise.all([
      CatalogItem.countDocuments({}),
      CatalogItem.countDocuments({ isActive: true }),
      CatalogItem.countDocuments({ pendingReview: true }),
      CatalogItem.countDocuments({ halalRejected: true }),
      CatalogItem.aggregate([
        { $group: { _id: '$source', count: { $sum: 1 }, active: { $sum: { $cond: ['$isActive', 1, 0] } } } },
        { $sort: { count: -1 } }
      ]),
      CatalogItem.aggregate([
        { $match: { isActive: true } },
        { $group: { _id: '$category', count: { $sum: 1 }, avgValue: { $avg: '$marketValue' } } },
        { $sort: { count: -1 } }
      ]),
    ]);

    res.json({
      success: true,
      pipeline: pipelineState,
      catalog: { total, active, pending, rejected },
      bySource,
      byCategory: byBox,
    });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// GET /admin/catalog/import/plan
exports.getPlan = (req, res) => {
  res.json({
    success: true,
    plan: IMPORT_PLAN.map(p => ({
      box:         p.box,
      boxPrice:    p.boxPrice,
      targetCount: p.targetCount,
      shariahRange: { min: +(p.boxPrice * 0.85).toFixed(2), max: +(p.boxPrice * 1.15).toFixed(2) },
      jobs: p.jobs.map(j => ({ source: j.source, keyword: j.arg, limit: j.limit })),
    })),
  });
};
