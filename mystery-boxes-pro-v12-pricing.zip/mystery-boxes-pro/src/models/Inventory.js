const mongoose = require('mongoose');

const inventorySchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  item: { type: mongoose.Schema.Types.ObjectId, ref: 'Item', required: true },
  order: { type: mongoose.Schema.Types.ObjectId, ref: 'Order', required: true },

  // Snapshot of item at time of winning
  itemName:   { type: String, required: true },
  itemRarity: { type: String, required: true },
  itemValue:  { type: Number, required: true },
  itemImage:  { type: String },

  // Redemption
  status: {
    type: String,
    enum: ['pending', 'delivered', 'redeemed', 'sold'],
    default: 'pending'
  },
  deliveryCode: { type: String, select: false }, // game key / gift card code
  deliveredAt:  { type: Date },
  redeemedAt:   { type: Date },

  rated: { type: Boolean, default: false }, // صحيح إذا قيّم المستخدم المنتج

  // If user sells back to platform
  soldForAmount: { type: Number },
  soldAt:        { type: Date }
}, { timestamps: true });

inventorySchema.index({ user: 1, createdAt: -1 });
inventorySchema.index({ user: 1, status: 1 });
inventorySchema.index({ itemRarity: 1 });

module.exports = mongoose.model('Inventory', inventorySchema);
