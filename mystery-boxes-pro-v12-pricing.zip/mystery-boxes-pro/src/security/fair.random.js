/**
 * fair.random.js — Verified Random Selection
 *
 * اسم جديد بدلاً من "provably.fair" — لأن هذا ليس نظام قمار.
 * الهدف: ضمان أن الاختيار العشوائي حقيقي وغير مُتلاعب به.
 *
 * كيف يعمل:
 *   1. يُولَّد serverSeed عشوائي (مخفي)
 *   2. clientSeed يختاره المستخدم (اختياري)
 *   3. HMAC-SHA256(serverSeed, clientSeed:nonce) → يُحدد المنتج
 *   4. بعد الفتح: يُكشف serverSeed حتى يتأكد المستخدم
 *
 * الفرق عن الكازينو: نتيجة الـhash تختار منتجاً من قائمة بأوزان متساوية تقريباً،
 * وليس من rarity pyramid (legendary 0.5% و common 60%).
 */

const crypto = require('crypto');

function generateServerSeed() {
  const serverSeed     = crypto.randomBytes(32).toString('hex');
  const serverSeedHash = crypto.createHash('sha256').update(serverSeed).digest('hex');
  return { serverSeed, serverSeedHash };
}

// يُولِّد float [0,1) من الـseeds — يُحدد أي منتج يُختار
function generateFloat(serverSeed, clientSeed, nonce) {
  const hmac = crypto.createHmac('sha256', serverSeed);
  hmac.update(`${clientSeed}:${nonce}`);
  const hash   = hmac.digest('hex');
  const intVal = parseInt(hash.slice(0, 8), 16);
  return intVal / 0x100000000; // [0, 1)
}

// اختيار منتج بناءً على الـfloat + أوزان المنتجات
// الأوزان تعكس توزيع الـbuckets فقط — لا تفاوت كبير
function pickItemFromFloat(fairFloat, weightedItems) {
  const total  = weightedItems.reduce((s, i) => s + (i.selectionWeight || 100), 0);
  let   cursor = fairFloat * total;
  for (const item of weightedItems) {
    cursor -= (item.selectionWeight || 100);
    if (cursor <= 0) return item;
  }
  return weightedItems[weightedItems.length - 1];
}

// التحقق من أن النتيجة لم تُتلاعب بها
function verifyResult(proof) {
  const computed  = generateFloat(proof.serverSeed, proof.clientSeed, proof.nonce);
  const hashCheck = crypto.createHash('sha256').update(proof.serverSeed).digest('hex');
  return {
    hashValid:  hashCheck === proof.serverSeedHash,
    floatValid: Math.abs(computed - parseFloat(proof.fairFloat)) < 1e-9,
    verified:   hashCheck === proof.serverSeedHash &&
                Math.abs(computed - parseFloat(proof.fairFloat)) < 1e-9
  };
}

module.exports = { generateServerSeed, generateFloat, pickItemFromFloat, verifyResult };
