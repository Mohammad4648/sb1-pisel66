/**
 * cj.importer.js — استيراد من CJ Dropshipping
 *
 * CJ Dropshipping API v2:
 *   https://developers.cjdropshipping.com/api2.0/v1
 *
 * الاستخدام:
 *   const cj = require('./cj.importer');
 *   await cj.importByCategory('phone accessories', { boxPrice: 6.99, limit: 500 });
 *
 * يعمل تلقائياً في jobs/catalog.sync.js
 */

const axios   = require('axios');
const CatalogItem      = require('../models/CatalogItem');
const { validateItemHalal } = require('../services/halal.service');
const { catalogFilter: getPriceFilter, validateProductCost, validateMarketValue } = require('../services/pricing.engine.v2');
const logger  = require('../utils/logger');

const CJ_BASE = process.env.CJ_API_URL || 'https://developers.cjdropshipping.com/api2.0/v1';
const CJ_KEY  = process.env.CJ_API_KEY;

// ── خريطة تصنيفات CJ → تصنيفاتنا ─────────────────────────────────────────
const CATEGORY_MAP = {
  'Phone Accessories':     'electronics',
  'Electronics':           'electronics',
  'Computer & Office':     'electronics',
  'Smart Devices':         'electronics',
  'Women Clothing':        'clothing',
  'Men Clothing':          'clothing',
  'Bags & Shoes':          'accessories',
  'Jewelry & Watches':     'accessories',
  'Home & Garden':         'home',
  'Kitchen':               'home',
  'Sports & Outdoors':     'accessories',
  'Office & School':       'stationery',
  'Toys & Hobbies':        'stationery',
  'Health & Beauty':       'accessories',
};

function mapCategory(cjCategory = '') {
  for (const [cjKey, ourCat] of Object.entries(CATEGORY_MAP)) {
    if (cjCategory.toLowerCase().includes(cjKey.toLowerCase())) return ourCat;
  }
  return 'other';
}

// ── مصادقة CJ (Token يتجدد كل 24 ساعة) ──────────────────────────────────
let _cjToken = null;
let _cjTokenExpiry = 0;

async function getCJToken() {
  if (_cjToken && Date.now() < _cjTokenExpiry) return _cjToken;

  const res = await axios.post(`${CJ_BASE}/authentication/getAccessToken`, {
    email:    process.env.CJ_EMAIL,
    password: process.env.CJ_PASSWORD,
  });

  if (!res.data?.data?.accessToken)
    throw new Error('CJ Auth failed: ' + JSON.stringify(res.data));

  _cjToken = res.data.data.accessToken;
  _cjTokenExpiry = Date.now() + 23 * 60 * 60 * 1000; // 23 ساعة
  return _cjToken;
}

function cjHeaders(token) {
  return { 'CJ-Access-Token': token, 'Content-Type': 'application/json' };
}

// ── جلب منتج واحد بالتفصيل ────────────────────────────────────────────────
async function fetchProductDetail(token, pid) {
  try {
    const r = await axios.get(`${CJ_BASE}/product/query`, {
      headers: cjHeaders(token),
      params:  { pid },
    });
    return r.data?.data || null;
  } catch { return null; }
}

// ── تحويل منتج CJ إلى نموذجنا ─────────────────────────────────────────────
function transformCJProduct(p, boxPrice) {
  // CJ يرجع السعر بالدولار
  const supplierCost = parseFloat(p.sellPrice || p.price || 0);
  const shipping     = parseFloat(p.shippingPrice || 1.2);
  const marketValue  = +(supplierCost * 1.8).toFixed(2); // هامش عرض 80%

  // تحقق من تكلفة المورد مقابل ميزانية الصندوق
  if (boxPrice) {
    const costCheck = validateProductCost(supplierCost, boxPrice);
    if (!costCheck.valid) return null; // تكلفة المورد خارج الميزانية

    // تحقق من marketValue للشفافية مع المستخدم
    const mvCheck = validateMarketValue(marketValue, boxPrice);
    if (!mvCheck.valid) {
      // عدّل marketValue لتكون ضمن النطاق المقبول
      const { min, max } = mvCheck.range;
      if (marketValue < min) return null; // قيمة أقل من السعر = غرر
      // إذا أكثر من 2.5x، نُقلّص
      if (marketValue > max) marketValue = max;
    }
  }

  const category = mapCategory(p.categoryName);

  return {
    name:              p.productNameEn?.trim().slice(0, 200) || p.productName?.trim().slice(0, 200),
    description:       p.description?.slice(0, 500) || '',
    image:             p.productImageUrl || p.productImage || '',
    sku:               p.pid || '',
    category,
    subCategory:       p.categoryName || '',
    marketValue,
    supplierCost,
    estimatedShipping: shipping,
    selectionWeight:   Math.min(100, Math.round((parseFloat(p.reviewCount || 1) / 10) + 50)),
    avgRating:         parseFloat(p.reviewStar || 0),
    ratingCount:       parseInt(p.reviewCount  || 0),
    refundRiskScore:   2,
    source:            'cj',
    externalId:        p.pid,
    externalUrl:       `https://cjdropshipping.com/product/${p.pid}.html`,
    isActive:          false, // تنتظر موافقة الأدمن
    halalVerified:     false,
    pendingReview:     true,
  };
}

// ── الاستيراد الرئيسي ──────────────────────────────────────────────────────
async function importByCategory(cjCategory, opts = {}) {
  const { boxPrice = null, limit = 200, pageSize = 20 } = opts;

  if (!CJ_KEY && !process.env.CJ_EMAIL)
    throw new Error('CJ_API_KEY أو CJ_EMAIL غير مُعيَّن في .env');

  const token = await getCJToken();
  const stats = { fetched: 0, imported: 0, skipped: 0, haram: 0, outOfRange: 0 };
  let page = 1;

  logger.info(`CJ Import: category="${cjCategory}" limit=${limit}`);

  while (stats.imported < limit) {
    const batchSize = Math.min(pageSize, limit - stats.imported);

    let res;
    try {
      res = await axios.get(`${CJ_BASE}/product/list`, {
        headers: cjHeaders(token),
        // احسب نطاق supplierCost من محرك التسعير
        const pf = boxPrice ? getPriceFilter(boxPrice) : { priceMin: 0, priceMax: 999 };
        params:  {
          categoryName: cjCategory,
          pageNum:      page,
          pageSize:     batchSize,
          priceMin:     pf.priceMin,
          priceMax:     pf.priceMax,
        },
      });
    } catch (e) {
      logger.error(`CJ API error p${page}: ${e.message}`);
      break;
    }

    const products = res.data?.data?.list || [];
    if (!products.length) break;
    stats.fetched += products.length;

    const docs = [];

    for (const p of products) {
      // فحص حلال
      const halal = validateItemHalal({ name: p.productNameEn || p.productName, description: p.description, productCategory: cjCategory });
      if (!halal.halal) { stats.haram++; continue; }

      // تحويل
      const doc = transformCJProduct(p, boxPrice);
      if (!doc) { stats.outOfRange++; continue; }
      if (!doc.name || doc.supplierCost <= 0) { stats.skipped++; continue; }

      docs.push(doc);
    }

    if (docs.length) {
      await CatalogItem.insertMany(docs, { ordered: false })
        .catch(() => {}); // تجاهل duplicates
      stats.imported += docs.length;
    }

    page++;
    await new Promise(r => setTimeout(r, 500)); // تأخير لحد Rate limit
  }

  logger.info(`CJ Import done: ${JSON.stringify(stats)}`);
  return stats;
}

// ── مزامنة أسعار منتجات CJ الحالية ─────────────────────────────────────────
async function syncPrices() {
  const token = await getCJToken();
  const items = await CatalogItem.find({ source: 'cj', isActive: true }).select('externalId supplierCost');
  let updated = 0;

  for (const item of items) {
    const p = await fetchProductDetail(token, item.externalId);
    if (!p) continue;

    const newCost = parseFloat(p.sellPrice || p.price || 0);
    if (Math.abs(newCost - item.supplierCost) > 0.10) {
      item.supplierCost = newCost;
      item.marketValue  = +(newCost * 1.8).toFixed(2);
      await item.save();
      updated++;
    }
    await new Promise(r => setTimeout(r, 200));
  }

  logger.info(`CJ syncPrices: ${updated} prices updated`);
  return { updated, total: items.length };
}

module.exports = { importByCategory, syncPrices, mapCategory };
