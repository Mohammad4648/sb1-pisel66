/**
 * admin.controller.js — Full Dashboard v4
 *
 * Covers:
 *   - Real-time platform stats
 *   - Provider management + health
 *   - Sync provider prices
 *   - Pricing tools + ROI engine
 *   - Analytics (revenue chart, rarity dist, top spenders)
 *   - User management (ban, unban, adjust balance)
 *   - Box emergency stop
 *   - Fraud flags management
 *   - Cache management
 */

const Provider   = require('../models/Provider');
const Box        = require('../models/Box');
const Item       = require('../models/Item');
const Order      = require('../models/Order');
const User       = require('../models/User');
const Transaction= require('../models/Transaction');
const ProofRecord= require('../models/ProofRecord');

const { pingProvider }                  = require('../services/provider.service');
const { syncProviderItems, syncAllProviders } = require('../services/sync.service');
const { validateBoxPricing, projectRevenue, DEFAULT_MARGIN,
        getBoxROI, checkStopLoss }       = require('../services/roi.engine');
const analytics  = require('../services/analytics.service');
const cache      = require('../services/cache.service');
const logger     = require('../utils/logger');

// ── Dashboard summary ─────────────────────────────────────────────────────────
exports.getDashboardStats = async (req, res) => {
  try {
    const data = await cache.wrap('admin:dashboard', async () => {
      const [totalUsers, totalOrders, revData, totalBoxes, recentOrders, topBoxes, flaggedUsers] = await Promise.all([
        User.countDocuments({ role: 'user' }),
        Order.countDocuments({ status: 'completed' }),
        Order.aggregate([{ $match: { status: 'completed' } }, { $group: { _id: null, total: { $sum: '$price' }, payouts: { $sum: '$totalValue' } } }]),
        Box.countDocuments({ isActive: true }),
        Order.find({ status: 'completed' }).sort({ createdAt: -1 }).limit(10).populate('user', 'username').populate('box', 'name'),
        Box.find({ isActive: true }).sort({ totalRevenue: -1 }).limit(5).select('name totalRevenue openingsCount price'),
        User.countDocuments({ isFlaggedForFraud: true })
      ]);
      const revenue = revData[0]?.total || 0;
      const payouts = revData[0]?.payouts || 0;
      const opens   = totalOrders;
      return {
        stats: {
          totalUsers, totalOrders, flaggedUsers,
          totalRevenue:    +revenue.toFixed(2),
          totalPayouts:    +payouts.toFixed(2),
          estimatedProfit: +(revenue - payouts).toFixed(2),
          actualMargin:    opens > 0 ? `${(((revenue - payouts) / revenue) * 100).toFixed(1)}%` : '0%',
          totalBoxes
        },
        recentOrders, topBoxes
      };
    }, 60); // cache 1 min

    res.json({ success: true, ...data });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ── Providers ─────────────────────────────────────────────────────────────────
exports.getProviders = async (req, res) => {
  try {
    const providers = await Provider.find().sort({ createdAt: -1 });
    res.json({ success: true, providers });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.createProvider = async (req, res) => {
  try {
    req.body.createdBy = req.user.id;
    const provider = await Provider.create(req.body);
    res.status(201).json({ success: true, provider });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.updateProvider = async (req, res) => {
  try {
    const provider = await Provider.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!provider) return res.status(404).json({ success: false, message: 'Provider not found' });
    res.json({ success: true, provider });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.deleteProvider = async (req, res) => {
  try {
    await Provider.findByIdAndUpdate(req.params.id, { isActive: false });
    res.json({ success: true, message: 'Provider deactivated' });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.pingProviderHealth = async (req, res) => {
  try {
    const result = await pingProvider(req.params.id);
    res.json({ success: true, ...result });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ── Sync ──────────────────────────────────────────────────────────────────────
exports.syncProvider = async (req, res) => {
  try {
    const result = await syncProviderItems(req.params.id);
    res.json({ success: true, ...result });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.syncAll = async (req, res) => {
  try {
    const results = await syncAllProviders();
    res.json({ success: true, results });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ── Pricing / ROI ─────────────────────────────────────────────────────────────
exports.checkBoxPricing = async (req, res) => {
  try {
    const { price, itemIds, profitMargin = DEFAULT_MARGIN } = req.body;
    const items  = await Item.find({ _id: { $in: itemIds } }).select('name baseValue probability rarity');
    const result = validateBoxPricing(price, items, profitMargin);
    res.json({ success: true, pricing: result, items });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.revenueProjection = async (req, res) => {
  try {
    const { usersPerDay = 100, opensPerUser = 3, boxPrice = 1, margin = DEFAULT_MARGIN } = req.query;
    const result = projectRevenue(+usersPerDay, +opensPerUser, +boxPrice, +margin);
    res.json({ success: true, projection: result });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.getBoxROIReport = async (req, res) => {
  try {
    const roi = await getBoxROI(req.params.id, parseInt(req.query.days) || 3);
    res.json({ success: true, roi });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ── Update box profit margin directly ────────────────────────────────────────
exports.updateBoxMargin = async (req, res) => {
  try {
    const { profitMargin } = req.body;
    if (!profitMargin || profitMargin < 0.10 || profitMargin > 0.90) {
      return res.status(400).json({ success: false, message: 'profitMargin must be between 0.10 and 0.90' });
    }
    const box = await Box.findByIdAndUpdate(req.params.id, { profitMargin }, { new: true });
    if (!box) return res.status(404).json({ success: false, message: 'Box not found' });
    cache.delPattern('boxes:');
    logger.info(`Admin updated box "${box.name}" margin to ${(profitMargin * 100).toFixed(0)}%`);
    res.json({ success: true, box });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ── Emergency stop a box ──────────────────────────────────────────────────────
exports.emergencyStopBox = async (req, res) => {
  try {
    const box = await Box.findByIdAndUpdate(req.params.id, { isActive: false }, { new: true });
    if (!box) return res.status(404).json({ success: false, message: 'Box not found' });
    cache.delPattern('boxes:');
    logger.warn(`🛑 EMERGENCY STOP: Box "${box.name}" deactivated by admin ${req.user.id}`);
    res.json({ success: true, message: `Box "${box.name}" stopped immediately` });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ── Run stop-loss check on a box ─────────────────────────────────────────────
exports.runStopLoss = async (req, res) => {
  try {
    const box = await Box.findById(req.params.id);
    if (!box) return res.status(404).json({ success: false, message: 'Box not found' });
    const result = await checkStopLoss(box);
    res.json({ success: true, result });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ── User management ───────────────────────────────────────────────────────────
exports.getUsers = async (req, res) => {
  try {
    const { page = 1, limit = 20, search, flagged } = req.query;
    const query = { role: 'user' };
    if (search) query.$or = [{ username: new RegExp(search, 'i') }, { email: new RegExp(search, 'i') }];
    if (flagged === 'true') query.isFlaggedForFraud = true;
    const skip = (page - 1) * limit;
    const [users, total] = await Promise.all([
      User.find(query).select('-password').sort({ createdAt: -1 }).skip(skip).limit(parseInt(limit)),
      User.countDocuments(query)
    ]);
    res.json({ success: true, count: users.length, total, pages: Math.ceil(total / limit), users });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.banUser = async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(req.params.id, { isBanned: true, isFlaggedForFraud: true }, { new: true });
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });
    logger.warn(`🔨 User ${user.username} banned by admin ${req.user.id}`);
    res.json({ success: true, message: `User ${user.username} banned` });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.unbanUser = async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(req.params.id, { isBanned: false, isFlaggedForFraud: false, fraudScore: 0 }, { new: true });
    res.json({ success: true, message: `User ${user.username} unbanned` });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.adjustUserBalance = async (req, res) => {
  try {
    const { amount, reason } = req.body;
    if (!amount || !reason) return res.status(400).json({ success: false, message: 'amount and reason required' });
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });
    const before = user.walletBalance;
    user.walletBalance = Math.max(0, user.walletBalance + amount);
    await user.save({ validateBeforeSave: false });
    await Transaction.create({
      user: user._id, type: amount > 0 ? 'deposit' : 'withdrawal',
      amount, balanceBefore: before, balanceAfter: user.walletBalance,
      description: `Admin adjustment: ${reason}`, status: 'completed'
    });
    logger.info(`Admin adjusted ${user.username} balance by ${amount}: ${reason}`);
    res.json({ success: true, newBalance: user.walletBalance });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ── Analytics ─────────────────────────────────────────────────────────────────
exports.getPlatformSummary = async (req, res) => {
  try {
    const data = await cache.wrap('analytics:summary', () => analytics.platformSummary(), 300);
    res.json({ success: true, ...data });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.getRevenueChart = async (req, res) => {
  try {
    const days  = parseInt(req.query.days) || 30;
    const chart = await analytics.revenueChart(days);
    res.json({ success: true, days, chart });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.getBoxPerformance = async (req, res) => {
  try {
    const data = await cache.wrap('analytics:boxes', () => analytics.boxPerformance(), 300);
    res.json({ success: true, boxes: data });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.getRarityDistribution = async (req, res) => {
  try {
    const data = await analytics.rarityDistribution(req.query.boxId);
    res.json({ success: true, distribution: data });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.getTopSpenders = async (req, res) => {
  try {
    const data = await analytics.topSpenders(parseInt(req.query.limit) || 10);
    res.json({ success: true, users: data });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ── Cache ─────────────────────────────────────────────────────────────────────
exports.getCacheStats = async (req, res) => res.json({ success: true, cache: cache.stats() });
exports.flushCache    = async (req, res) => { cache.flush(); res.json({ success: true, message: 'Cache flushed' }); };

// ── Audit log: all orders ─────────────────────────────────────────────────────
exports.getAllOrders = async (req, res) => {
  try {
    const { page = 1, limit = 20, status, userId } = req.query;
    const query = {};
    if (status) query.status = status;
    if (userId) query.user   = userId;
    const skip = (page - 1) * limit;
    const [orders, total] = await Promise.all([
      Order.find(query).sort({ createdAt: -1 }).skip(skip).limit(parseInt(limit))
        .populate('user', 'username email').populate('box', 'name'),
      Order.countDocuments(query)
    ]);
    res.json({ success: true, count: orders.length, total, orders });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ── Fraud: view flagged users + proof records ─────────────────────────────────
exports.getFraudReport = async (req, res) => {
  try {
    const [flaggedUsers, highVelocity] = await Promise.all([
      User.find({ isFlaggedForFraud: true }).select('username email fraudScore registrationIP lastLoginIP createdAt'),
      Order.aggregate([
        { $match: { createdAt: { $gte: new Date(Date.now() - 24 * 60 * 60 * 1000) } } },
        { $group: { _id: '$user', opens: { $sum: 1 } } },
        { $match: { opens: { $gte: 30 } } },
        { $sort: { opens: -1 } },
        { $limit: 20 }
      ])
    ]);
    res.json({ success: true, flaggedUsers, highVelocityUsers: highVelocity });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};
