/**
 * referral.service.js
 *
 * المحرك الموحد لكل عمليات الإحالة والعمولة والكاشباك.
 *
 * الميزات:
 *   - حساب العمولة: tier مباشر بدون double-write
 *   - عمولة ثانية (L2): عمولة رمزية لمن أحال المُحيل
 *   - مايلستونز: مكافأة نقدية عند 5,10,25,50,100 إحالة نشطة
 *   - كاشباك: % من سعر الصندوق للمستخدم حسب مستواه
 *   - مكافأة أول إيداع: بونص مرة واحدة فقط
 *   - كل العمليات ذرية داخل session
 */

const User           = require('../models/User');
const Referral       = require('../models/Referral');
const ReferralReward = require('../models/ReferralReward');
const Transaction    = require('../models/Transaction');
const Order          = require('../models/Order');
const Coupon         = require('../models/Coupon');
const logger         = require('../utils/logger');
const notify         = require('./notify.service');
const { COMMISSION_RATES } = require('../models/User');

// ── مايلستونز: (activeReferrals → مكافأة) ──────────────────────────────────
const MILESTONES = [
  { at: 5,   type: 'cash',   amount: 5,    label: '🎉 5 إحالات نشطة — $5 مكافأة' },
  { at: 10,  type: 'cash',   amount: 15,   label: '🏆 10 إحالات — $15 مكافأة' },
  { at: 25,  type: 'cash',   amount: 50,   label: '💎 25 إحالة — $50 مكافأة' },
  { at: 50,  type: 'cash',   amount: 150,  label: '🚀 50 إحالة — $150 مكافأة' },
  { at: 100, type: 'cash',   amount: 500,  label: '👑 100 إحالة — $500 مكافأة' }
];

// كاشباك حسب المستوى: +0.1% لكل مستوى، حد أقصى 5%
function getCashbackRate(level) {
  return Math.min((level - 1) * 0.001, 0.05);
}

// ══════════════════════════════════════════════════════════════════════════════
// processReferralCommission
// يُستدعى من box.controller داخل withTransaction
// ══════════════════════════════════════════════════════════════════════════════
async function processReferralCommission(referredUser, purchaseAmount, orderId, session) {
  if (!referredUser.referredBy) return;

  // قراءة المُحيل قبل التعديل لمعرفة رصيده الحالي
  const referrer = await User.findById(referredUser.referredBy).session(session);
  if (!referrer || referrer.isBanned) return;

  // حساب العمولة بناءً على tier المُحيل الفعلي — دفعة واحدة، لا double-write
  const rate       = COMMISSION_RATES[referrer.tier] || COMMISSION_RATES.bronze;
  const commission = +Math.max(0, purchaseAmount * rate).toFixed(4);
  if (commission <= 0) return;

  const balanceBefore = referrer.walletBalance;

  // تحديث ذري واحد فقط
  await User.findByIdAndUpdate(referrer._id, {
    $inc: {
      walletBalance:         commission,
      totalEarned:           commission,
      totalCommissionEarned: commission
    }
  }, { session });

  // سجل المعاملة
  await Transaction.create([{
    user:         referrer._id,
    type:         'commission',
    amount:       commission,
    balanceBefore,
    balanceAfter: balanceBefore + commission,
    description:  `عمولة إحالة — فتح ${referredUser.username}`,
    relatedOrder: orderId,
    status:       'completed',
    method:       'referral'
  }], { session });

  // تحديث Order
  await Order.findByIdAndUpdate(orderId, {
    $set: { commissionPaidTo: referrer._id, commissionAmount: commission }
  }, { session });

  // تحديث سجل الإحالة
  const referralDoc = await Referral.findOneAndUpdate(
    { referrer: referrer._id, referredUser: referredUser._id },
    {
      $inc:  { totalCommissionEarned: commission, totalReferredSpent: purchaseAmount, purchaseCount: 1 },
      $push: { purchases: { $each: [{ order: orderId, amount: purchaseAmount, commission }], $slice: -100 } },
      $set:  { isActive: true }
    },
    { session, new: true }
  );

  // إذا أول شراء → تحديث firstPurchase + activeReferrals للمُحيل
  if (referralDoc && referralDoc.purchaseCount === 1) {
    await Referral.findByIdAndUpdate(referralDoc._id, {
      $set: { firstPurchaseAt: new Date(), firstPurchaseAmt: purchaseAmount }
    }, { session });

    await User.findByIdAndUpdate(referrer._id, {
      $inc: { activeReferrals: 1 }
    }, { session });

    // تحقق من tier جديد بعد زيادة activeReferrals
    await _checkAndUpgradeTier(referrer._id, session);
  }

  // ── L2 Commission: محذوف — العمولة للمُحيل المباشر فقط (ضابط شرعي)
  // لا يجوز أخذ عمولة من شخص لم تتعامل معه مباشرة

    logger.info(`Commission: referrer=${referrer.username} amount=$${commission} tier=${referrer.tier} order=${orderId}`);

  // إشعار للمُحيل (خارج الـsession — async)
  process.nextTick(() => {
    notify.commissionEarned(referrer._id, commission, referredUser.username).catch(() => {});
  });
}

// ── تحقق من المايلستونز (خارج transaction — مكافأة لا تمس balance الشراء) ──
async function checkMilestones(referrerId) {
  const user = await User.findById(referrerId).select('activeReferrals walletBalance totalEarned totalCommissionEarned username');
  if (!user) return;

  for (const m of MILESTONES) {
    if (user.activeReferrals < m.at) continue;

    // atomic: احجز المايلستون بشرط عدم الوجود
    const existing = await ReferralReward.findOne({ user: user._id, milestone: m.at });
    if (existing) continue;

    try {
      await ReferralReward.create({
        user: user._id, milestone: m.at, rewardType: m.type,
        amount: m.amount, claimed: true, claimedAt: new Date()
      });
    } catch (e) {
      if (e.code === 11000) continue; // unique index — سبق منح المكافأة
    }

    if (m.type === 'cash') {
      await User.findByIdAndUpdate(user._id, {
        $inc: { walletBalance: m.amount, totalEarned: m.amount, totalCommissionEarned: m.amount }
      });
      await Transaction.create({
        user: user._id, type: 'bonus', amount: m.amount,
        balanceBefore: user.walletBalance, balanceAfter: user.walletBalance + m.amount,
        description: m.label, status: 'completed', method: 'milestone_bonus'
      });
      logger.info(`Milestone bonus: ${user.username} reached ${m.at} referrals → $${m.amount}`);
      // إشعار
      notify.milestoneReached(user._id, m.at, m.amount).catch(() => {});
    }
  }
}

// ── كاشباك للمستخدم عند فتح الصندوق ──────────────────────────────────────
// processCashback: مُعاد تصميمها كـ loyaltyDiscount مُطبّق مباشرة على السعر
// السبب: الكاشباك بعد الشراء يشجع الاستمرار، أما الخصم المسبق = بيع بسعر أقل = مشروع
async function processCashback(userId, boxPrice, userLevel, session) {
  // الخصم يُحسب ويُطبَّق في box.controller مباشرة على السعر النهائي
  // لا يُضاف رصيد بعد الشراء — لا تحفيز للاستمرار
  return 0;
}

// ── مكافأة أول إيداع ─────────────────────────────────────────────────────
const FIRST_DEPOSIT_RATES = [
  { min: 50,  bonus: 0.25, label: '+25% مكافأة أول إيداع' },
  { min: 20,  bonus: 0.20, label: '+20% مكافأة أول إيداع' },
  { min: 10,  bonus: 0.15, label: '+15% مكافأة أول إيداع' },
  { min: 1,   bonus: 0.10, label: '+10% مكافأة أول إيداع' }
];

// processFirstDepositBonus: محذوفة
// السبب: مكافأة مالية على الإيداع تشبه الفائدة (ربا) — محظورة شرعاً.
// البديل: كوبون ترحيبي بخصم على أول صندوق (خصم على السلعة لا على المال).
async function processFirstDepositBonus() { return null; } // deprecated — halal compliance


async function _checkAndUpgradeTier(userId, session) {
  const u = await User.findById(userId).session(session);
  if (!u) return;
  const prevTier = u.tier;
  u.updateTier();
  if (u.tier !== prevTier) {
    await u.save({ session });
    logger.info(`Tier upgrade: ${u.username} ${prevTier} → ${u.tier} (rate: ${(u.getCommissionRate()*100).toFixed(0)}%)`);
    // مكافأة ترقية tier
    await checkMilestones(userId); // check milestones async after session
  }
}

// ── إحصائيات المُحيل الكاملة (للـdashboard) ─────────────────────────────
async function getReferralStats(userId, days = 30) {
  const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);

  const [user, referrals, recentCommissions, milestones, chartData] = await Promise.all([
    User.findById(userId).select(
      'tier activeReferrals referralCount totalCommissionEarned pendingCommission referralCode level'
    ),
    Referral.find({ referrer: userId })
      .populate('referredUser', 'username level tier createdAt totalBoxesOpened')
      .sort({ createdAt: -1 }),
    Transaction.aggregate([
      { $match: { user: userId, type: 'commission', createdAt: { $gte: since } } },
      { $group: { _id: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } }, total: { $sum: '$amount' }, count: { $sum: 1 } } },
      { $sort: { _id: 1 } }
    ]),
    ReferralReward.find({ user: userId }).sort({ milestone: 1 }),
    Transaction.aggregate([
      { $match: { user: userId, type: 'commission', status: 'completed', createdAt: { $gte: since } } },
      { $group: { _id: null, total: { $sum: '$amount' }, count: { $sum: 1 } } }
    ])
  ]);

  const periodEarnings = chartData[0]?.total || 0;
  const nextTierInfo   = user.getNextTierInfo();
  const claimedMilestones = new Set(milestones.map(m => m.milestone));
  const pendingMilestones = MILESTONES.filter(m =>
    user.activeReferrals >= m.at && !claimedMilestones.has(m.at)
  );

  return {
    overview: {
      tier:                 user.tier,
      commissionRate:       `${(user.getCommissionRate() * 100).toFixed(0)}%`,
      totalReferrals:       user.referralCount,
      activeReferrals:      user.activeReferrals,
      totalEarned:          +user.totalCommissionEarned.toFixed(2),
      periodEarnings:       +periodEarnings.toFixed(2),
      referralCode:         user.referralCode,
      nextTier:             nextTierInfo.nextTier,
      nextTierRate:         nextTierInfo.nextRate ? `${(nextTierInfo.nextRate * 100).toFixed(0)}%` : null,
      referralsUntilNextTier: nextTierInfo.referralsNeeded
    },
    referrals: referrals.map(r => ({
      user:        r.referredUser?.username,
      level:       r.referredUser?.level,
      joinedAt:    r.createdAt,
      isActive:    r.isActive,
      totalSpent:  +r.totalReferredSpent.toFixed(2),
      commission:  +r.totalCommissionEarned.toFixed(2),
      opens:       r.purchaseCount,
      firstPurchase: r.firstPurchaseAt
    })),
    milestones: {
      claimed: milestones.map(m => ({ at: m.milestone, amount: m.amount, date: m.claimedAt })),
      pending: pendingMilestones
    },
    chart: recentCommissions
  };
}

module.exports = {
  processReferralCommission,
  checkMilestones,
  processCashback,
  processFirstDepositBonus,
  getReferralStats,
  getCashbackRate,
  MILESTONES,
  FIRST_DEPOSIT_RATES
};
