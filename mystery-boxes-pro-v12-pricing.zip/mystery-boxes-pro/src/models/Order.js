const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  box: { type: mongoose.Schema.Types.ObjectId, ref: 'Box', required: true },
  boxName: { type: String, required: true },
  price: { type: Number, required: true },

  // Items received from opening
  itemsReceived: [{
    item: { type: mongoose.Schema.Types.ObjectId, ref: 'Item' },
    name: String,
    rarity: String,
    value: Number,
    image: String
  }],

  totalValue: { type: Number, default: 0 },

  status: {
    type: String,
    enum: ['pending', 'completed', 'refunded', 'failed'],
    default: 'pending'
  },

  // Referral commission
  commissionPaidTo: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  commissionAmount: { type: Number, default: 0 },

  // Payment
  paymentMethod: { type: String, enum: ['wallet', 'stripe', 'paypal'], default: 'wallet' },
  paymentReference: { type: String },

  completedAt: { type: Date }
}, { timestamps: true });

orderSchema.index({ user: 1, createdAt: -1 });
orderSchema.index({ status: 1 });

module.exports = mongoose.model('Order', orderSchema);
