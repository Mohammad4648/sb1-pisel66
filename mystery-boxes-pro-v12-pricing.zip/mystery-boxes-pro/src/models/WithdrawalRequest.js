const mongoose = require('mongoose');

const withdrawalSchema = new mongoose.Schema({
  user:     { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  amount:   { type: Number, required: true, min: 1 },
  method:   { type: String, enum: ['crypto_usdt', 'crypto_btc', 'bank', 'paypal'], required: true },
  address:  { type: String, required: true },
  network:  { type: String },
  fee:      { type: Number, default: 0 },
  netAmount:{ type: Number },
  status: {
    type:    String,
    enum:    ['pending', 'approved', 'processing', 'completed', 'rejected', 'cancelled'],
    default: 'pending'
  },
  txHash:         { type: String },
  rejectedReason: { type: String },
  processedAt:    { type: Date },
  processedBy:    { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  autoApproved:   { type: Boolean, default: false },
  ipAddress:      { type: String }
}, { timestamps: true });

withdrawalSchema.index({ user: 1, createdAt: -1 });
withdrawalSchema.index({ status: 1 });
module.exports = mongoose.model('WithdrawalRequest', withdrawalSchema);
