/**
 * rateLimiter.middleware.js
 *
 * Per-user in-memory rate limiters to prevent abuse:
 *   - openBox: max 30 opens per minute per user (anti-spam)
 *   - deposit:  max 5 deposit attempts per 10 minutes per user
 *   - auth:     max 10 login attempts per 15 minutes per IP
 */

const logger = require('../utils/logger');

// Generic sliding-window counter
class SlidingWindow {
  constructor(maxRequests, windowMs) {
    this.maxRequests = maxRequests;
    this.windowMs    = windowMs;
    this.buckets     = new Map(); // key → [timestamps]

    // Cleanup old entries every 5 minutes
    setInterval(() => this._cleanup(), 5 * 60 * 1000);
  }

  isAllowed(key) {
    const now  = Date.now();
    const hits = (this.buckets.get(key) || []).filter(t => now - t < this.windowMs);
    hits.push(now);
    this.buckets.set(key, hits);
    return hits.length <= this.maxRequests;
  }

  remaining(key) {
    const now  = Date.now();
    const hits = (this.buckets.get(key) || []).filter(t => now - t < this.windowMs);
    return Math.max(0, this.maxRequests - hits.length);
  }

  _cleanup() {
    const now = Date.now();
    for (const [key, hits] of this.buckets.entries()) {
      const active = hits.filter(t => now - t < this.windowMs);
      if (active.length === 0) this.buckets.delete(key);
      else this.buckets.set(key, active);
    }
  }
}

// Limiters
const openBoxLimiter  = new SlidingWindow(30, 60 * 1000);       // 30/min
const depositLimiter  = new SlidingWindow(5,  10 * 60 * 1000);  // 5/10min
const authLimiter     = new SlidingWindow(10, 15 * 60 * 1000);  // 10/15min

// Middleware factories
exports.limitOpenBox = (req, res, next) => {
  const key = `open:${req.user?.id || req.ip}`;
  if (!openBoxLimiter.isAllowed(key)) {
    logger.warn(`Rate limit hit – openBox – user ${req.user?.id}`);
    return res.status(429).json({
      success: false,
      message: 'Too many box opens. Please wait a moment.',
      retryAfter: '60s'
    });
  }
  res.setHeader('X-RateLimit-Remaining-Opens', openBoxLimiter.remaining(key));
  next();
};

exports.limitDeposit = (req, res, next) => {
  const key = `deposit:${req.user?.id || req.ip}`;
  if (!depositLimiter.isAllowed(key)) {
    return res.status(429).json({
      success: false,
      message: 'Too many deposit attempts. Try again in 10 minutes.',
      retryAfter: '600s'
    });
  }
  next();
};

exports.limitAuth = (req, res, next) => {
  const key = `auth:${req.ip}`;
  if (!authLimiter.isAllowed(key)) {
    logger.warn(`Auth rate limit hit – IP ${req.ip}`);
    return res.status(429).json({
      success: false,
      message: 'Too many login attempts. Try again in 15 minutes.',
      retryAfter: '900s'
    });
  }
  next();
};
