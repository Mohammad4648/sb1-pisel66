const express = require('express');
const router  = express.Router();
const item    = require('../controllers/item.controller');
const { protect, authorize } = require('../middleware/auth.middleware');

// Public
router.get('/',            item.getItems);
router.get('/categories',  item.getCategories);
router.get('/:id',         item.getItem);

// User — بعد تسجيل الدخول
router.post('/:id/rate',   protect, item.rateItem);

// Admin
router.post('/',           protect, authorize('admin'), item.createItem);
router.put('/:id',         protect, authorize('admin'), item.updateItem);
router.delete('/:id',      protect, authorize('admin'), item.deleteItem);
router.put('/:id/risk',    protect, authorize('admin'), item.updateRisk);
router.get('/admin/stats', protect, authorize('admin'), item.getItemStats);

module.exports = router;
