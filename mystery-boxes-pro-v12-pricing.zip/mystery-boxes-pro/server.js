/**
 * server.js — Mystery Rewards Platform v4.0
 */

const express   = require('express');
const mongoose  = require('mongoose');
const cors      = require('cors');
const helmet    = require('helmet');
const rateLimit = require('express-rate-limit');
const { createServer } = require('http');
const { Server }       = require('socket.io');
const path      = require('path');
require('dotenv').config();

const logger        = require('./src/utils/logger');
const { errorHandler, notFound } = require('./src/middleware/error.middleware');
const routes        = require('./src/routes');
const { startJobs } = require('./src/jobs');
const { startWorkers } = require('./src/queue/queue.manager');

const app        = express();
const httpServer = createServer(app);
const io         = new Server(httpServer, {
  cors: { origin: process.env.CLIENT_URL || 'http://localhost:3000', credentials: true }
});

// ── Security middleware ───────────────────────────────────────────────────────
app.use(helmet());
app.use(cors({ origin: process.env.CLIENT_URL || '*', credentials: true }));
app.set('trust proxy', 1); // for accurate IP behind reverse proxy

// Global rate limit (200 req/15min)
app.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 200, standardHeaders: true }));

// ── Body parser ───────────────────────────────────────────────────────────────
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// ── Request logging ───────────────────────────────────────────────────────────
app.use((req, res, next) => {
  logger.info(`${req.method} ${req.path}`, { ip: req.ip });
  next();
});

// ── Routes ────────────────────────────────────────────────────────────────────
app.use('/api/v1', routes);

// ── Health check ──────────────────────────────────────────────────────────────
app.get('/health', (req, res) => {
  const cache = require('./src/services/cache.service');
  const { bullAvailable } = require('./src/queue/queue.manager');
  res.json({
    status:    'OK',
    version:   '4.0.0',
    platform:  'Mystery Rewards Platform',
    uptime:    `${Math.floor(process.uptime())}s`,
    database:  mongoose.connection.readyState === 1 ? 'connected' : 'disconnected',
    queue:     bullAvailable ? 'BullMQ/Redis' : 'inline (no Redis)',
    cache:     cache.stats()
  });
});

// ── Socket.IO ─────────────────────────────────────────────────────────────────
io.on('connection', (socket) => {
  socket.on('joinRoom', (userId) => {
    socket.join(`user:${userId}`);
    logger.info(`Socket joined user:${userId}`);
  });
});
app.set('io', io);
global._expressApp = app; // needed by notify.service for real-time emit

// ── Error handlers ────────────────────────────────────────────────────────────
app.use(notFound);
app.use(errorHandler);

// ── Start ─────────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 5000;
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/mystery-rewards')
  .then(() => {
    logger.info('✅ MongoDB connected');
    httpServer.listen(PORT, () => {
      logger.info(`🚀 Mystery Rewards Platform v4.0 running on port ${PORT}`);
      startJobs();    // cron jobs
      startWorkers(); // BullMQ workers (no-op if Redis unavailable)
    });
  })
  .catch((err) => { logger.error('❌ MongoDB connection failed:', err); process.exit(1); });

process.on('unhandledRejection', (err) => { logger.error('UnhandledRejection:', err.message); });
module.exports = app;

// Dev API mounted at top level (no /v1 prefix for cleaner SDK URLs)
const { apiRouter, portalRouter } = require('./src/routes/developer.routes');
app.use('/api/dev',        apiRouter);
app.use('/api/dev-portal', portalRouter);
