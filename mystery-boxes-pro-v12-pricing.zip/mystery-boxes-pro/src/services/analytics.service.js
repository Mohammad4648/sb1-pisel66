/**
 * analytics.service.js
 *
 * Aggregates platform analytics without a separate analytics DB.
 * Queries MongoDB for on-demand insights.
 *
 * Key metrics:
 *   - Revenue per box
 *   - Rarity distribution (actual vs expected)
 *   - User retention (returning openers)
 *   - Top earners (referral leaderboard)
 *   - Daily/weekly/monthly revenue charts
 */

const Order       = require('../models/Order');
const User        = require('../models/User');
const Box         = require('../models/Box');
const Transaction = require('../models/Transaction');
const Inventory   = require('../models/Inventory');

// Revenue over time (grouped by day)
async function revenueChart(days = 30) {
  const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
  const data = await Order.aggregate([
    { $match: { status: 'completed', createdAt: { $gte: since } } },
    {
      $group: {
        _id: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } },
        revenue: { $sum: '$price' },
        opens:   { $sum: 1 }
      }
    },
    { $sort: { _id: 1 } }
  ]);
  return data.map(d => ({ date: d._id, revenue: +d.revenue.toFixed(2), opens: d.opens }));
}

// Per-box performance
async function boxPerformance() {
  const boxes = await Box.find({ isActive: true }).select('name price profitMargin openingsCount totalRevenue expectedValue');
  return boxes.map(b => ({
    name:          b.name,
    price:         b.price,
    opens:         b.openingsCount,
    revenue:       +b.totalRevenue.toFixed(2),
    estimatedProfit: +(b.totalRevenue * (b.profitMargin || 0.30)).toFixed(2),
    avgRevenuePerOpen: b.openingsCount > 0 ? +(b.totalRevenue / b.openingsCount).toFixed(2) : 0
  }));
}

// Rarity distribution – actual results vs configured probabilities
async function rarityDistribution(boxId) {
  const match = { status: 'completed' };
  if (boxId) match.box = boxId;

  const data = await Order.aggregate([
    { $match: match },
    { $unwind: '$itemsReceived' },
    { $group: { _id: '$itemsReceived.rarity', count: { $sum: 1 } } },
    { $sort: { count: -1 } }
  ]);

  const total = data.reduce((s, d) => s + d.count, 0);
  return data.map(d => ({
    rarity:  d._id,
    count:   d.count,
    percent: total > 0 ? +((d.count / total) * 100).toFixed(2) : 0
  }));
}

// User retention – % of users who opened more than once in last 30 days
async function userRetention() {
  const since = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
  const data = await Order.aggregate([
    { $match: { status: 'completed', createdAt: { $gte: since } } },
    { $group: { _id: '$user', opens: { $sum: 1 } } },
    { $group: {
      _id: null,
      total:     { $sum: 1 },
      returning: { $sum: { $cond: [{ $gt: ['$opens', 1] }, 1, 0] } }
    }}
  ]);

  if (!data.length) return { total: 0, returning: 0, retentionRate: '0%' };
  const { total, returning } = data[0];
  return { total, returning, retentionRate: `${((returning / total) * 100).toFixed(1)}%` };
}

// Top spending users
async function topSpenders(limit = 10) {
  return User.find({ role: 'user' })
    .select('username totalSpent totalBoxesOpened tier')
    .sort({ totalSpent: -1 })
    .limit(limit);
}

// Platform summary – single object for the admin dashboard
async function platformSummary() {
  const [
    totalUsers,
    activeToday,
    revData,
    retention,
    rarities
  ] = await Promise.all([
    User.countDocuments({ role: 'user' }),
    Order.distinct('user', { createdAt: { $gte: new Date(Date.now() - 86400000) } }),
    Order.aggregate([
      { $match: { status: 'completed' } },
      { $group: { _id: null, total: { $sum: '$price' }, opens: { $sum: 1 } } }
    ]),
    userRetention(),
    rarityDistribution()
  ]);

  const revenue = revData[0]?.total || 0;
  const opens   = revData[0]?.opens || 0;

  return {
    totalUsers,
    activeToday:   activeToday.length,
    totalRevenue:  +revenue.toFixed(2),
    estimatedProfit: +(revenue * 0.30).toFixed(2),
    totalOpens:    opens,
    avgRevenuePerOpen: opens > 0 ? +(revenue / opens).toFixed(2) : 0,
    retention,
    rarityDistribution: rarities
  };
}

module.exports = { revenueChart, boxPerformance, rarityDistribution, userRetention, topSpenders, platformSummary };
