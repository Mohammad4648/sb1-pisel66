const express   = require('express');
const router    = express.Router();
const inventory = require('../controllers/inventory.controller');
const { protect } = require('../middleware/auth.middleware');

router.use(protect);
router.get('/',           inventory.getMyInventory);
router.get('/:id',        inventory.getInventoryItem);
router.post('/:id/sell',  inventory.sellItem);
router.post('/:id/gift',  inventory.giftFromInventory);  // NEW

module.exports = router;
