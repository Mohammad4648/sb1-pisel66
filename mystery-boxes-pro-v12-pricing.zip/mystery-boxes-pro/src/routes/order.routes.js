const express = require('express');
const router = express.Router();
const { getMyOrders, getOrder, getAllOrders } = require('../controllers/order.controller');
const { protect, authorize } = require('../middleware/auth.middleware');

router.use(protect);

router.get('/', getMyOrders);
router.get('/all', authorize('admin'), getAllOrders);
router.get('/:id', getOrder);

module.exports = router;
