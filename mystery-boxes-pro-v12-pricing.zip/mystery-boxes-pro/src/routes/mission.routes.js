const express = require('express');
const router  = express.Router();
const m       = require('../controllers/mission.controller');
const { protect } = require('../middleware/auth.middleware');

router.use(protect);
router.get('/',         m.getMissions);
router.get('/history',  m.getMissionHistory);

module.exports = router;
