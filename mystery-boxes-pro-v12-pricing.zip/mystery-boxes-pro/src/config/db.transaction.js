/**
 * db.transaction.js
 *
 * Wraps critical financial operations in a Mongoose session + transaction.
 * Prevents double-spend: if ANY step fails, ALL steps roll back atomically.
 *
 * Usage:
 *   const result = await withTransaction(async (session) => {
 *     await user.subtractFromWallet(price, session);
 *     const order = await Order.create([{...}], { session });
 *     await Transaction.create([{...}], { session });
 *     return order[0];
 *   });
 */

const mongoose = require('mongoose');
const logger   = require('../utils/logger');

async function withTransaction(fn) {
  const session = await mongoose.startSession();
  session.startTransaction();
  try {
    const result = await fn(session);
    await session.commitTransaction();
    return result;
  } catch (err) {
    await session.abortTransaction();
    logger.error(`Transaction rolled back: ${err.message}`);
    throw err;
  } finally {
    session.endSession();
  }
}

module.exports = { withTransaction };
