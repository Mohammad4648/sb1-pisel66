const Coupon = require('../models/Coupon');
const { validationResult } = require('express-validator');

// Validate a coupon code (public – checked before purchase)
exports.validateCoupon = async (req, res) => {
  try {
    const { code, boxId, boxPrice } = req.body;
    const coupon = await Coupon.findOne({ code: code?.toUpperCase() });
    if (!coupon) return res.status(404).json({ success: false, message: 'Invalid coupon code' });

    const check = coupon.isValid(req.user.id, boxPrice, boxId);
    if (!check.valid) return res.status(400).json({ success: false, message: check.reason });

    const discountedPrice = coupon.applyDiscount(boxPrice);
    res.json({
      success: true,
      coupon: {
        code:   coupon.code,
        type:   coupon.type,
        value:  coupon.value,
        originalPrice:  boxPrice,
        discountedPrice: +discountedPrice.toFixed(2),
        savings: +(boxPrice - discountedPrice).toFixed(2)
      }
    });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// Admin: create coupon
exports.createCoupon = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ success: false, errors: errors.array() });
    req.body.createdBy = req.user.id;
    const coupon = await Coupon.create(req.body);
    res.status(201).json({ success: true, coupon });
  } catch (e) {
    if (e.code === 11000) return res.status(400).json({ success: false, message: 'Coupon code already exists' });
    res.status(500).json({ success: false, message: e.message });
  }
};

// Admin: list all coupons
exports.getCoupons = async (req, res) => {
  try {
    const { active } = req.query;
    const query = {};
    if (active === 'true') query.isActive = true;
    if (active === 'false') query.isActive = false;
    const coupons = await Coupon.find(query).sort({ createdAt: -1 });
    res.json({ success: true, count: coupons.length, coupons });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// Admin: toggle coupon active status
exports.toggleCoupon = async (req, res) => {
  try {
    const coupon = await Coupon.findById(req.params.id);
    if (!coupon) return res.status(404).json({ success: false, message: 'Coupon not found' });
    coupon.isActive = !coupon.isActive;
    await coupon.save();
    res.json({ success: true, isActive: coupon.isActive });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// Admin: delete coupon
exports.deleteCoupon = async (req, res) => {
  try {
    await Coupon.findByIdAndDelete(req.params.id);
    res.json({ success: true, message: 'Coupon deleted' });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};
