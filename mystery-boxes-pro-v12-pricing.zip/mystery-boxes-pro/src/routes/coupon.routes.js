// coupon.routes.js
const express = require('express');
const router  = express.Router();
const coupon  = require('../controllers/coupon.controller');
const { protect, authorize } = require('../middleware/auth.middleware');

// Public (but requires auth to validate against user)
router.post('/validate', protect, coupon.validateCoupon);

// Admin only
router.get('/',         protect, authorize('admin'), coupon.getCoupons);
router.post('/',        protect, authorize('admin'), coupon.createCoupon);
router.patch('/:id',    protect, authorize('admin'), coupon.toggleCoupon);
router.delete('/:id',   protect, authorize('admin'), coupon.deleteCoupon);

module.exports = router;
