/**
 * gift.controller.js
 *
 * POST /gifts/send                  — إرسال عنصر من المخزون كهدية
 * GET  /gifts/received              — الهدايا الواردة
 * GET  /gifts/sent                  — الهدايا المرسلة
 * POST /gifts/:id/accept            — قبول هدية
 * POST /gifts/:id/decline           — رفض هدية
 * DELETE /gifts/:id                 — إلغاء هدية معلّقة (من المُرسِل)
 */

const Gift      = require('../models/Gift');
const Inventory = require('../models/Inventory');
const User      = require('../models/User');
const notify    = require('../services/notify.service');
const { withTransaction } = require('../config/db.transaction');
const logger = require('../utils/logger');

// ── إرسال هدية ────────────────────────────────────────────────────────────
exports.sendGift = async (req, res) => {
  try {
    const { inventoryId, receiverWalletId, message } = req.body;
    if (!inventoryId || !receiverWalletId) {
      return res.status(400).json({ success: false, message: 'inventoryId و receiverWalletId مطلوبان' });
    }

    // التحقق من المستلم
    const receiver = await User.findOne({ walletId: receiverWalletId.toUpperCase(), isBanned: false });
    if (!receiver) return res.status(404).json({ success: false, message: 'المستخدم غير موجود' });
    if (receiver._id.equals(req.user.id)) return res.status(400).json({ success: false, message: 'لا يمكنك إرسال هدية لنفسك' });

    // التحقق من العنصر — atomic claim: نغيّر حالته لـ'gifted' حتى لا يُباع أو يُهدى مرة أخرى
    const inv = await Inventory.findOneAndUpdate(
      { _id: inventoryId, user: req.user.id, status: 'pending' },
      { $set: { status: 'gifted' } },
      { new: true }
    );
    if (!inv) {
      return res.status(404).json({ success: false, message: 'العنصر غير موجود أو تم التصرف فيه مسبقاً' });
    }

    const gift = await Gift.create({
      sender:    req.user.id,
      receiver:  receiver._id,
      inventory: inv._id,
      itemName:  inv.itemName,
      itemRarity:inv.itemRarity,
      itemValue: inv.itemValue,
      itemImage: inv.itemImage,
      message:   message?.slice(0, 200) || null
    });

    // إشعار للمستلم
    notify.giftReceived(receiver._id, req.user.username, inv.itemName, gift._id).catch(() => {});

    logger.info(`Gift sent: ${req.user.username} → ${receiver.username} item="${inv.itemName}"`);
    res.status(201).json({
      success: true,
      message: `تم إرسال "${inv.itemName}" كهدية إلى ${receiver.username}`,
      gift: { id: gift._id, itemName: gift.itemName, itemRarity: gift.itemRarity, expiresAt: gift.expiresAt }
    });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ── قبول هدية ─────────────────────────────────────────────────────────────
exports.acceptGift = async (req, res) => {
  try {
    const gift = await Gift.findOne({ _id: req.params.id, receiver: req.user.id, status: 'pending' });
    if (!gift) return res.status(404).json({ success: false, message: 'الهدية غير موجودة أو منتهية الصلاحية' });

    await withTransaction(async (session) => {
      // نقل ملكية عنصر المخزون للمستلم
      await Inventory.findByIdAndUpdate(gift.inventory, {
        $set: { user: req.user.id, status: 'pending' }
      }, { session });

      await Gift.findByIdAndUpdate(gift._id, {
        $set: { status: 'accepted', respondedAt: new Date() }
      }, { session });
    });

    notify.send(gift.sender, 'gift_sent', {
      title:   `🎀 قَبِل ${req.user.username} هديتك`,
      message: `"${gift.itemName}" وصلت بأمان`,
      data:    { itemName: gift.itemName, receiverUsername: req.user.username }
    }).catch(() => {});

    logger.info(`Gift accepted: ${gift.itemName} → ${req.user.username}`);
    res.json({ success: true, message: `تم قبول هدية "${gift.itemName}" وإضافتها لمخزونك` });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ── رفض هدية ──────────────────────────────────────────────────────────────
exports.declineGift = async (req, res) => {
  try {
    const gift = await Gift.findOne({ _id: req.params.id, receiver: req.user.id, status: 'pending' });
    if (!gift) return res.status(404).json({ success: false, message: 'الهدية غير موجودة' });

    await withTransaction(async (session) => {
      // إعادة العنصر للمُرسِل
      await Inventory.findByIdAndUpdate(gift.inventory, {
        $set: { user: gift.sender, status: 'pending' }
      }, { session });
      await Gift.findByIdAndUpdate(gift._id, {
        $set: { status: 'declined', respondedAt: new Date() }
      }, { session });
    });

    notify.send(gift.sender, 'gift_sent', {
      title:   `❌ رفض ${req.user.username} هديتك`,
      message: `"${gift.itemName}" عادت لمخزونك`,
      data:    { itemName: gift.itemName }
    }).catch(() => {});

    res.json({ success: true, message: 'تم رفض الهدية وإعادة العنصر للمُرسِل' });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ── إلغاء هدية (من المُرسِل) ─────────────────────────────────────────────
exports.cancelGift = async (req, res) => {
  try {
    const gift = await Gift.findOne({ _id: req.params.id, sender: req.user.id, status: 'pending' });
    if (!gift) return res.status(404).json({ success: false, message: 'لا يمكن إلغاء هذه الهدية' });

    await withTransaction(async (session) => {
      await Inventory.findByIdAndUpdate(gift.inventory, { $set: { user: req.user.id, status: 'pending' } }, { session });
      await Gift.findByIdAndUpdate(gift._id, { $set: { status: 'cancelled' } }, { session });
    });

    res.json({ success: true, message: 'تم إلغاء الهدية واسترداد العنصر' });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ── الهدايا الواردة ────────────────────────────────────────────────────────
exports.getReceived = async (req, res) => {
  try {
    const { status = 'pending' } = req.query;
    const gifts = await Gift.find({ receiver: req.user.id, status })
      .populate('sender', 'username level tier')
      .sort({ createdAt: -1 }).limit(50);
    res.json({ success: true, count: gifts.length, gifts });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ── الهدايا المرسلة ────────────────────────────────────────────────────────
exports.getSent = async (req, res) => {
  try {
    const gifts = await Gift.find({ sender: req.user.id })
      .populate('receiver', 'username')
      .sort({ createdAt: -1 }).limit(50);
    res.json({ success: true, count: gifts.length, gifts });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};
