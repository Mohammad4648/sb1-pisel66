/**
 * admin.developer.controller.js
 *
 * Admin tools for managing developer accounts:
 *   - List all developers (filter by status)
 *   - Approve / reject applications
 *   - Update commission rates
 *   - Process payouts
 *   - View developer fraud signals
 */

const Developer      = require('../models/Developer');
const Commission     = require('../models/Commission');
const DeveloperPayout= require('../models/DeveloperPayout');
const { dispatchPayoutProcessed } = require('./webhook.service');
const logger = require('../utils/logger');

exports.getDevelopers = async (req, res) => {
  try {
    const { status, page = 1, limit = 20 } = req.query;
    const query = {};
    if (status) query.status = status;
    const skip = (page - 1) * limit;
    const [devs, total] = await Promise.all([
      Developer.find(query).sort({ createdAt: -1 }).skip(skip).limit(parseInt(limit)),
      Developer.countDocuments(query)
    ]);
    res.json({ success: true, count: devs.length, total, developers: devs });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.getDeveloper = async (req, res) => {
  try {
    const dev = await Developer.findById(req.params.id).select('+apiKey');
    if (!dev) return res.status(404).json({ success: false, message: 'Developer not found' });
    const recentCommissions = await Commission.find({ developer: dev._id }).sort({ createdAt: -1 }).limit(20);
    res.json({ success: true, developer: dev, recentCommissions });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.approveDeveloper = async (req, res) => {
  try {
    const dev = await Developer.findById(req.params.id);
    if (!dev) return res.status(404).json({ success: false, message: 'Developer not found' });
    if (dev.status === 'active') return res.status(400).json({ success: false, message: 'Already active' });

    dev.status      = 'active';
    dev.approvedAt  = new Date();
    dev.approvedBy  = req.user.id;
    await dev.save({ validateBeforeSave: false });

    logger.info(`✅ Developer approved: ${dev.name} by admin ${req.user.id}`);
    res.json({ success: true, message: `Developer "${dev.name}" approved and activated` });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.rejectDeveloper = async (req, res) => {
  try {
    const { reason } = req.body;
    const dev = await Developer.findByIdAndUpdate(
      req.params.id,
      { status: 'rejected', rejectedReason: reason || 'Not specified' },
      { new: true }
    );
    if (!dev) return res.status(404).json({ success: false, message: 'Developer not found' });
    logger.warn(`❌ Developer rejected: ${dev.name}`);
    res.json({ success: true, message: `Developer "${dev.name}" rejected` });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.suspendDeveloper = async (req, res) => {
  try {
    const dev = await Developer.findByIdAndUpdate(req.params.id, { status: 'suspended' }, { new: true });
    logger.warn(`🔒 Developer suspended: ${dev?.name}`);
    res.json({ success: true, message: `Developer suspended` });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.updateCommission = async (req, res) => {
  try {
    const { commissionType, commissionValue } = req.body;
    const dev = await Developer.findByIdAndUpdate(
      req.params.id,
      { commissionType, commissionValue },
      { new: true }
    );
    if (!dev) return res.status(404).json({ success: false, message: 'Not found' });
    logger.info(`Commission updated for ${dev.name}: ${commissionValue}${commissionType === 'percentage' ? '%' : '$'}`);
    res.json({ success: true, developer: dev });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ── Payout management ─────────────────────────────────────────────────────────
exports.getPendingPayouts = async (req, res) => {
  try {
    const payouts = await DeveloperPayout.find({ status: 'pending' })
      .populate('developer', 'name email balance')
      .sort({ createdAt: 1 });
    const total = payouts.reduce((s, p) => s + p.amount, 0);
    res.json({ success: true, count: payouts.length, totalAmount: +total.toFixed(2), payouts });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.processPayout = async (req, res) => {
  try {
    const { txHash } = req.body;
    const payout = await DeveloperPayout.findById(req.params.id).populate('developer');
    if (!payout) return res.status(404).json({ success: false, message: 'Payout not found' });
    if (payout.status !== 'pending') return res.status(400).json({ success: false, message: 'Payout already processed' });

    payout.status       = 'completed';
    payout.txHash       = txHash;
    payout.processedAt  = new Date();
    payout.processedBy  = req.user.id;
    await payout.save();

    await dispatchPayoutProcessed(payout.developer, payout);

    logger.info(`💸 Payout processed: dev=${payout.developer.name} amount=$${payout.amount} tx=${txHash}`);
    res.json({ success: true, message: 'Payout marked as completed', payout });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.rejectPayout = async (req, res) => {
  try {
    const { reason } = req.body;
    const payout = await DeveloperPayout.findById(req.params.id);
    if (!payout) return res.status(404).json({ success: false, message: 'Not found' });

    // Refund balance
    await Developer.findByIdAndUpdate(payout.developer, {
      $inc: { balance: payout.amount, pendingPayout: payout.amount }
    });
    payout.status = 'rejected';
    payout.rejectedReason = reason;
    await payout.save();

    res.json({ success: true, message: 'Payout rejected and balance refunded' });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

// ── Platform commission summary ───────────────────────────────────────────────
exports.getCommissionOverview = async (req, res) => {
  try {
    const days  = parseInt(req.query.days) || 30;
    const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);

    const [summary, topDevs] = await Promise.all([
      Commission.aggregate([
        { $match: { createdAt: { $gte: since }, status: 'credited' } },
        { $group: { _id: null, totalPaid: { $sum: '$commissionAmount' }, totalRevenue: { $sum: '$boxPrice' }, opens: { $sum: 1 } } }
      ]),
      Commission.aggregate([
        { $match: { createdAt: { $gte: since }, status: 'credited' } },
        { $group: { _id: '$developer', totalCommission: { $sum: '$commissionAmount' }, opens: { $sum: 1 } } },
        { $sort: { totalCommission: -1 } },
        { $limit: 10 },
        { $lookup: { from: 'developers', localField: '_id', foreignField: '_id', as: 'dev' } },
        { $unwind: '$dev' }
      ])
    ]);

    res.json({
      success: true,
      period: `${days}d`,
      summary: summary[0] || { totalPaid: 0, totalRevenue: 0, opens: 0 },
      topDevelopers: topDevs.map(d => ({
        name:        d.dev.name,
        opens:       d.opens,
        commission:  +d.totalCommission.toFixed(2)
      }))
    });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};
