/**
 * MysteryBox SDK — JavaScript/Node.js
 * Version: 1.0.0
 *
 * Usage:
 *   const { MysteryBox } = require('mysterybox-sdk')
 *   // or: import { MysteryBox } from 'mysterybox-sdk'
 *
 * Quick start:
 *   const mb = new MysteryBox('mbp_your_api_key', 'sec_your_api_secret')
 *   const result = await mb.openBox({ userId: 'player123', boxId: 'abc123' })
 *   console.log(result.reward) // { name, rarity, value }
 */

const crypto = require('crypto');

// Works in Node.js; for browser use, replace require('crypto') with Web Crypto API
const http = typeof window === 'undefined'
  ? require('https')   // Node.js
  : null;              // Browser (uses fetch)

class MysteryBox {
  /**
   * @param {string} apiKey    - Your API key (mbp_...)
   * @param {string} apiSecret - Your API secret (sec_...)
   * @param {Object} options
   * @param {string} [options.baseUrl] - API base URL (default: https://your-platform.com/api/dev)
   */
  constructor(apiKey, apiSecret, options = {}) {
    if (!apiKey)    throw new Error('apiKey is required');
    if (!apiSecret) throw new Error('apiSecret is required');

    this.apiKey    = apiKey;
    this.apiSecret = apiSecret;
    this.baseUrl   = (options.baseUrl || 'https://your-platform.com/api/dev').replace(/\/$/, '');
    this.timeout   = options.timeout || 10000;
  }

  // ── Signature ──────────────────────────────────────────────────────────────
  _sign(timestamp, body) {
    const bodyStr  = typeof body === 'string' ? body : JSON.stringify(body);
    const payload  = `${timestamp}.${bodyStr}`;
    return crypto.createHmac('sha256', this.apiSecret).update(payload).digest('hex');
  }

  _headers(body = {}) {
    const timestamp = Date.now().toString();
    const signature = this._sign(timestamp, body);
    return {
      'Content-Type':  'application/json',
      'x-api-key':     this.apiKey,
      'x-timestamp':   timestamp,
      'x-signature':   signature
    };
  }

  // ── HTTP request ───────────────────────────────────────────────────────────
  async _request(method, path, body = null) {
    const url      = `${this.baseUrl}${path}`;
    const bodyStr  = body ? JSON.stringify(body) : null;
    const headers  = this._headers(body || {});

    const res = await fetch(url, {
      method,
      headers,
      body: bodyStr,
      signal: AbortSignal.timeout(this.timeout)
    });

    const data = await res.json();
    if (!res.ok || !data.success) {
      const err = new Error(data.error || data.message || `HTTP ${res.status}`);
      err.status = res.status;
      err.data   = data;
      throw err;
    }
    return data;
  }

  // ── Open a box ─────────────────────────────────────────────────────────────
  /**
   * Open a mystery box for an external user.
   * @param {Object} params
   * @param {string} params.userId   - User ID in your system
   * @param {string} params.boxId    - Box ID to open
   * @param {string} [params.clientSeed] - Optional client seed for provably fair
   * @param {string} [params.sourceApp]  - App identifier for your records
   * @returns {{ reward: { name, rarity, value, image }, orderId, fairness, commission }}
   */
  async openBox({ userId, boxId, clientSeed, sourceApp }) {
    if (!userId) throw new Error('userId is required');
    if (!boxId)  throw new Error('boxId is required');

    return this._request('POST', '/open-box', {
      externalUserId: userId,
      boxId,
      clientSeed: clientSeed || `${userId}-${Date.now()}`,
      sourceApp
    });
  }

  // ── List available boxes ───────────────────────────────────────────────────
  /**
   * @param {{ category?: string, boxType?: string }} filters
   */
  async listBoxes(filters = {}) {
    const qs = new URLSearchParams(filters).toString();
    return this._request('GET', `/boxes${qs ? '?' + qs : ''}`);
  }

  // ── Get stats ──────────────────────────────────────────────────────────────
  /**
   * @param {number} [days=30]
   */
  async getStats(days = 30) {
    return this._request('GET', `/stats?days=${days}`);
  }

  // ── Get commission history ─────────────────────────────────────────────────
  async getCommissions(page = 1) {
    return this._request('GET', `/commissions?page=${page}`);
  }

  // ── Request payout ─────────────────────────────────────────────────────────
  /**
   * @param {{ amount: number, method: 'crypto'|'bank'|'paypal', address: string }}
   */
  async requestWithdraw({ amount, method, address }) {
    return this._request('POST', '/withdraw', { amount, method, address });
  }

  // ── Verify a webhook signature ─────────────────────────────────────────────
  /**
   * Use this in your webhook handler to verify it's from the platform.
   * @param {string} webhookSecret - Your webhook secret from the portal
   * @param {string} timestamp     - X-Webhook-Timestamp header
   * @param {Object} body          - Parsed request body
   * @param {string} signature     - X-Webhook-Signature header
   */
  static verifyWebhook(webhookSecret, timestamp, body, signature) {
    const bodyStr  = JSON.stringify(body);
    const payload  = `${timestamp}.${bodyStr}`;
    const expected = crypto.createHmac('sha256', webhookSecret).update(payload).digest('hex');
    try {
      return crypto.timingSafeEqual(Buffer.from(expected, 'hex'), Buffer.from(signature, 'hex'));
    } catch { return false; }
  }
}

module.exports = { MysteryBox };

// ── Example: Telegram Bot ─────────────────────────────────────────────────────
/*
const { Telegraf } = require('telegraf')
const { MysteryBox } = require('./sdk')

const bot = new Telegraf(process.env.BOT_TOKEN)
const mb  = new MysteryBox(process.env.MB_API_KEY, process.env.MB_API_SECRET)

bot.command('open', async (ctx) => {
  const userId = String(ctx.from.id)
  try {
    const result = await mb.openBox({ userId, boxId: 'YOUR_BOX_ID', sourceApp: 'TelegramBot' })
    const { name, rarity, value } = result.reward
    await ctx.reply(`🎉 You won: *${name}* (${rarity}) — Value: $${value}`, { parse_mode: 'Markdown' })
  } catch (err) {
    await ctx.reply(`❌ Error: ${err.message}`)
  }
})
bot.launch()
*/

// ── Example: Express webhook handler ─────────────────────────────────────────
/*
app.post('/mb-webhook', express.json(), (req, res) => {
  const valid = MysteryBox.verifyWebhook(
    process.env.MB_WEBHOOK_SECRET,
    req.headers['x-webhook-timestamp'],
    req.body,
    req.headers['x-webhook-signature']
  )
  if (!valid) return res.status(401).send('Invalid signature')

  const { event, externalUserId, reward } = req.body
  if (event === 'box_opened') {
    // Add reward to your game/app for externalUserId
    console.log(`User ${externalUserId} won: ${reward.name}`)
  }
  res.sendStatus(200)
})
*/
