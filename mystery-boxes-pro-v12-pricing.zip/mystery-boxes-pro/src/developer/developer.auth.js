/**
 * developer.auth.js
 *
 * Middleware for external developer API requests.
 *
 * Every request must include:
 *   x-api-key:   Developer's API key (mbp_...)
 *   x-timestamp: Unix timestamp (ms) — rejects if >5min old
 *   x-signature: HMAC-SHA256(apiSecret, timestamp + '.' + JSON.stringify(body))
 *
 * Also enforces:
 *   - Per-developer rate limits (in-memory sliding window)
 *   - IP whitelist (if configured)
 *   - Status check (must be 'active')
 */

const crypto    = require('crypto');
const Developer = require('../models/Developer');
const logger    = require('../utils/logger');

// Per-developer request counters
const perMinCounter  = new Map();  // devId → [timestamps]
const perHourCounter = new Map();

function slidingCount(map, key, windowMs) {
  const now  = Date.now();
  const hits = (map.get(key) || []).filter(t => now - t < windowMs);
  hits.push(now);
  map.set(key, hits);
  return hits.length;
}

// Cleanup every 10 min
setInterval(() => {
  const now = Date.now();
  for (const [k, v] of perMinCounter)  if (v.every(t => now - t > 60000))       perMinCounter.delete(k);
  for (const [k, v] of perHourCounter) if (v.every(t => now - t > 3600000))     perHourCounter.delete(k);
}, 10 * 60 * 1000);

// ─────────────────────────────────────────────────────────────────────────────
// HMAC Signature Verification
// Signature = HMAC-SHA256(apiSecret, timestamp + '.' + bodyString)
// ─────────────────────────────────────────────────────────────────────────────
function verifySignature(apiSecret, timestamp, body, signature) {
  const bodyStr  = typeof body === 'string' ? body : JSON.stringify(body);
  const payload  = `${timestamp}.${bodyStr}`;
  const expected = crypto.createHmac('sha256', apiSecret).update(payload).digest('hex');
  // Constant-time comparison
  try {
    return crypto.timingSafeEqual(Buffer.from(expected, 'hex'), Buffer.from(signature, 'hex'));
  } catch {
    return false;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Main middleware
// ─────────────────────────────────────────────────────────────────────────────
const authenticateDeveloper = async (req, res, next) => {
  const apiKey    = req.headers['x-api-key'];
  const timestamp = req.headers['x-timestamp'];
  const signature = req.headers['x-signature'];

  if (!apiKey) {
    return res.status(401).json({ success: false, error: 'Missing x-api-key header' });
  }

  try {
    // Find developer by API key (requires +apiKey +apiSecret select)
    const dev = await Developer.findOne({ apiKey }).select('+apiKey +apiSecret +webhookSecret');

    if (!dev) return res.status(401).json({ success: false, error: 'Invalid API key' });
    if (dev.status !== 'active') {
      return res.status(403).json({ success: false, error: `Account ${dev.status}. Contact support.` });
    }

    // ── Timestamp check (replay protection) ──────────────────────────────
    if (timestamp) {
      const ts  = parseInt(timestamp);
      const age = Math.abs(Date.now() - ts);
      if (age > 5 * 60 * 1000) {
        return res.status(401).json({ success: false, error: 'Request timestamp too old (>5 min). Check your clock.' });
      }
    }

    // ── HMAC signature verification ──────────────────────────────────────
    if (signature && timestamp) {
      const valid = verifySignature(dev.apiSecret, timestamp, req.body, signature);
      if (!valid) {
        logger.warn(`Invalid HMAC signature — developer: ${dev.name} (${dev._id})`);
        return res.status(401).json({ success: false, error: 'Invalid request signature' });
      }
    }

    // ── IP whitelist ──────────────────────────────────────────────────────
    if (dev.allowedIPs && dev.allowedIPs.length > 0) {
      const clientIP = (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.ip;
      if (!dev.allowedIPs.includes(clientIP)) {
        logger.warn(`IP not whitelisted: ${clientIP} for developer ${dev.name}`);
        return res.status(403).json({ success: false, error: 'IP not whitelisted' });
      }
    }

    // ── Rate limiting ─────────────────────────────────────────────────────
    const devId  = dev._id.toString();
    const perMin  = slidingCount(perMinCounter,  devId, 60 * 1000);
    const perHour = slidingCount(perHourCounter, devId, 60 * 60 * 1000);

    if (perMin > (dev.rateLimitPerMin || 60)) {
      return res.status(429).json({ success: false, error: 'Rate limit exceeded (per minute)' });
    }
    if (perHour > (dev.rateLimitPerHour || 1000)) {
      return res.status(429).json({ success: false, error: 'Rate limit exceeded (per hour)' });
    }

    // Set rate limit headers
    res.setHeader('X-RateLimit-Limit-Min',   dev.rateLimitPerMin  || 60);
    res.setHeader('X-RateLimit-Remaining-Min', Math.max(0, (dev.rateLimitPerMin || 60) - perMin));

    req.developer = dev;
    next();
  } catch (err) {
    logger.error('Developer auth error:', err.message);
    res.status(500).json({ success: false, error: 'Authentication error' });
  }
};

module.exports = { authenticateDeveloper, verifySignature };
