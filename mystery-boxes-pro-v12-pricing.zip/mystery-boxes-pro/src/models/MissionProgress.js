const mongoose = require('mongoose');

// تعريف المهام الثابتة — يمكن للأدمن تعديلها
const missionDefinitions = [
  // يومية
  { id: 'daily_open_1',    period: 'daily',  type: 'open_boxes',    target: 1,  xp: 20,  cash: 0,    label: 'افتح صندوقاً واحداً' },
  { id: 'daily_open_3',    period: 'daily',  type: 'open_boxes',    target: 3,  xp: 60,  cash: 0.05, label: 'افتح 3 صناديق اليوم' },
  { id: 'daily_open_5',    period: 'daily',  type: 'open_boxes',    target: 5,  xp: 120, cash: 0.10, label: 'افتح 5 صناديق اليوم' },
  { id: 'daily_deposit',   period: 'daily',  type: 'deposit',       target: 1,  xp: 30,  cash: 0,    label: 'أودع للمرة الأولى اليوم' },
  { id: 'daily_open2',     period: 'daily',  type: 'open_boxes',    target: 2,      xp: 80, cash: 0, label: 'افتح صندوقين اليوم' },
  // أسبوعية
  { id: 'weekly_open_20',  period: 'weekly', type: 'open_boxes',    target: 20, xp: 400, cash: 0.50, label: 'افتح 20 صندوقاً هذا الأسبوع' },
  { id: 'weekly_spend_5',  period: 'weekly', type: 'spend_amount',  target: 5,  xp: 200, cash: 0.25, label: 'أنفق $5 هذا الأسبوع' },
  { id: 'weekly_referral', period: 'weekly', type: 'refer_active',  target: 1,  xp: 300, cash: 1.00, label: 'احصل على إحالة نشطة هذا الأسبوع' },
  { id: 'weekly_open10',   period: 'weekly', type: 'open_boxes',    target: 10,     xp: 500, cash: 0, label: 'افتح 10 صناديق هذا الأسبوع' },
];

const missionProgressSchema = new mongoose.Schema({
  user:        { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  missionId:   { type: String, required: true },
  period:      { type: String, enum: ['daily', 'weekly'], required: true },
  periodKey:   { type: String, required: true }, // e.g. "2024-01-15" or "2024-W03"
  progress:    { type: Number, default: 0 },
  target:      { type: Number, required: true },
  isCompleted: { type: Boolean, default: false },
  completedAt: { type: Date },
  rewardXP:    { type: Number, default: 0 },
  rewardCash:  { type: Number, default: 0 },
  rewardClaimed: { type: Boolean, default: false }
}, { timestamps: true });

missionProgressSchema.index({ user: 1, missionId: 1, periodKey: 1 }, { unique: true });
missionProgressSchema.index({ user: 1, period: 1, periodKey: 1 });

module.exports = mongoose.model('MissionProgress', missionProgressSchema);
module.exports.missionDefinitions = missionDefinitions;
