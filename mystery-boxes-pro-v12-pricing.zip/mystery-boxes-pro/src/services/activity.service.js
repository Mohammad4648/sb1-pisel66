/**
 * activity.service.js
 *
 * فيد النشاط العام — يعرض آخر الفائزين في المنصة.
 * يُعزز ثقة المستخدمين ويزيد التحويلات (social proof).
 *
 * يُستدعى من box.controller بعد كل فتح ناجح.
 * مخزون في Redis (إن وُجد) أو في-memory مع حد 100 حدث.
 */

const cache = require('./cache.service');

const FEED_KEY   = 'activity:feed';
const FEED_LIMIT = 100;

// رموز الندرة
const RARITY_EMOJI = {
  common:    '⚪',
  uncommon:  '🟢',
  rare:      '🔵',
  epic:      '🟣',
  // rarity emojis محذوفة — لا rarity في النموذج الحالي
  mythical:  '🔴'
};

// ── إضافة حدث للفيد ───────────────────────────────────────────────────────
async function pushPurchaseEvent({ username, itemName, itemValue, boxName, userId }) {
  const event = {
    id:         `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    username:   maskUsername(username),
    itemName,
    itemRarity,
    itemValue,
    boxName,
    emoji:      RARITY_EMOJI[itemRarity] || '🎁',
    
    timestamp:  new Date().toISOString()
  };

  // جلب الفيد الحالي وإضافة الحدث في الأول
  const current = cache.get(FEED_KEY) || [];
  const updated = [event, ...current].slice(0, FEED_LIMIT);
  cache.set(FEED_KEY, updated, 60 * 60 * 24); // 24 ساعة

  return event;
}

// ── جلب الفيد ─────────────────────────────────────────────────────────────
function getFeed(limit = 20) {
  const all = cache.get(FEED_KEY) || [];
  return all.slice(0, Math.min(limit, FEED_LIMIT));
}

// ── جلب أحداث rare+ فقط ──────────────────────────────────────────────────
function getEpicFeed(limit = 10) {
  const all = cache.get(FEED_KEY) || [];
  return all.filter(e => e.isEpic).slice(0, limit);
}

// ── إخفاء جزء من الاسم للخصوصية ──────────────────────────────────────────
function maskUsername(username) {
  if (!username || username.length <= 3) return username;
  const visible = Math.ceil(username.length / 2);
  return username.slice(0, visible) + '*'.repeat(username.length - visible);
}

module.exports = { pushPurchaseEvent, getFeed };
