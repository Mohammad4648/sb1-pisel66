const express = require('express');
const router  = express.Router();
const levels  = require('../controllers/levels.controller');
const { protect } = require('../middleware/auth.middleware');

router.get('/me',          protect, levels.getMyLevel);
router.get('/leaderboard', levels.getLeaderboard);

module.exports = router;
