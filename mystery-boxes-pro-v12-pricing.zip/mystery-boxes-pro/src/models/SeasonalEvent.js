const mongoose = require('mongoose');

const seasonalEventSchema = new mongoose.Schema({
  name:        { type: String, required: true },
  description: { type: String },
  emoji:       { type: String, default: '🎉' },
  theme:       { type: String, enum: ['eid', 'ramadan', 'christmas', 'halloween', 'summer', 'new_year', 'custom'], default: 'custom' },

  startAt:  { type: Date, required: true },
  endAt:    { type: Date, required: true },
  isActive: { type: Boolean, default: false },

  // Which boxes are part of this event (empty = all)
  eventBoxes: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Box' }],

  // Boosts applied during event
  boosts: {
    xpMultiplier:       { type: Number, default: 1.0 },  // e.g. 2.0 = double XP
    rarityBoostPercent: { type: Number, default: 0 },    // % boost to rare+ probability
    cashbackBonus:      { type: Number, default: 0 },    // extra cashback %
    commissionBoost:    { type: Number, default: 0 }     // extra commission % for referrers
  },

  // Banner / visual config for frontend
  bannerImage: { type: String },
  accentColor: { type: String, default: '#a855f7' },
  badgeLabel:  { type: String },

  // Stats
  totalOpens:   { type: Number, default: 0 },
  totalRevenue: { type: Number, default: 0 },

  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
}, { timestamps: true });

seasonalEventSchema.index({ startAt: 1, endAt: 1, isActive: 1 });

module.exports = mongoose.model('SeasonalEvent', seasonalEventSchema);
