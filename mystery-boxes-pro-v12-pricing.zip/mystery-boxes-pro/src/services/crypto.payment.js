/**
 * crypto.payment.js
 *
 * Binance Pay integration – lowest fees, no company required to start.
 * Docs: https://developers.binance.com/docs/binance-pay/introduction
 */

const axios  = require('axios');
const crypto = require('crypto');
const logger = require('../utils/logger');

const BINANCE_BASE = 'https://bpay.binanceapi.com';

/**
 * Build Binance Pay signature.
 */
function buildSignature(timestamp, nonce, body, apiSecret) {
  const payload = `${timestamp}\n${nonce}\n${JSON.stringify(body)}\n`;
  return crypto.createHmac('sha512', apiSecret).update(payload).digest('hex').toUpperCase();
}

/**
 * Create a Binance Pay order (user pays crypto → we credit wallet).
 * @param {number} amount     - Amount in USD
 * @param {string} orderId    - Your internal order reference
 * @param {string} userId     - User identifier for metadata
 */
async function createBinancePayOrder(amount, orderId, userId) {
  const apiKey    = process.env.BINANCE_PAY_KEY;
  const apiSecret = process.env.BINANCE_PAY_SECRET;

  if (!apiKey || !apiSecret) {
    logger.warn('Binance Pay keys not configured – using mock mode');
    return {
      success:   true,
      mock:      true,
      checkoutUrl: `https://pay.binance.com/mock?amount=${amount}&ref=${orderId}`,
      prepayId:  `MOCK-${orderId}`
    };
  }

  const timestamp = Date.now();
  const nonce     = crypto.randomBytes(16).toString('hex');

  const body = {
    env:          { terminalType: 'WEB' },
    merchantTradeNo: orderId,
    orderAmount:  amount,
    currency:     'USDT',
    description:  'Mystery Box – wallet top-up',
    goodsDetails: [{
      goodsType:  '02',          // 02 = digital goods
      goodsCategory: 'Z000',
      referenceGoodsId: orderId,
      goodsName:  'Wallet Credit',
      goodsDetail: `Top-up $${amount} for user ${userId}`
    }]
  };

  const signature = buildSignature(timestamp, nonce, body, apiSecret);

  try {
    const res = await axios.post(`${BINANCE_BASE}/binancepay/openapi/v2/order`, body, {
      headers: {
        'BinancePay-Timestamp':  timestamp,
        'BinancePay-Nonce':      nonce,
        'BinancePay-Certificate-SN': apiKey,
        'BinancePay-Signature':  signature,
        'Content-Type':          'application/json'
      },
      timeout: 10000
    });

    if (res.data?.status === 'SUCCESS') {
      return {
        success:     true,
        prepayId:    res.data.data.prepayId,
        checkoutUrl: res.data.data.checkoutUrl,
        deepLink:    res.data.data.deeplink
      };
    }
    throw new Error(res.data?.errorMessage || 'Binance Pay order creation failed');
  } catch (err) {
    logger.error(`Binance Pay error: ${err.message}`);
    return { success: false, error: err.message };
  }
}

/**
 * Verify Binance Pay webhook signature.
 * Call this in your webhook route before crediting the user.
 */
function verifyBinanceWebhook(req) {
  const apiSecret  = process.env.BINANCE_PAY_SECRET;
  const timestamp  = req.headers['binancepay-timestamp'];
  const nonce      = req.headers['binancepay-nonce'];
  const signature  = req.headers['binancepay-signature'];
  const body       = req.body;

  const expected = buildSignature(timestamp, nonce, body, apiSecret);
  return signature === expected;
}

/**
 * Query order status from Binance Pay.
 */
async function queryBinanceOrder(prepayId) {
  const apiKey    = process.env.BINANCE_PAY_KEY;
  const apiSecret = process.env.BINANCE_PAY_SECRET;
  if (!apiKey) return { success: false, error: 'Not configured' };

  const timestamp = Date.now();
  const nonce     = crypto.randomBytes(16).toString('hex');
  const body      = { prepayId };
  const signature = buildSignature(timestamp, nonce, body, apiSecret);

  try {
    const res = await axios.post(`${BINANCE_BASE}/binancepay/openapi/v2/order/query`, body, {
      headers: {
        'BinancePay-Timestamp':  timestamp,
        'BinancePay-Nonce':      nonce,
        'BinancePay-Certificate-SN': apiKey,
        'BinancePay-Signature':  signature,
        'Content-Type':          'application/json'
      },
      timeout: 10000
    });
    return { success: true, data: res.data?.data };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

module.exports = { createBinancePayOrder, verifyBinanceWebhook, queryBinanceOrder };
