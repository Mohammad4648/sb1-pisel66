/**
 * webhook.service.js
 *
 * Sends signed webhook events to developer callback URLs.
 *
 * Every webhook is signed:
 *   X-Webhook-Signature: HMAC-SHA256(webhookSecret, timestamp + '.' + body)
 *   X-Webhook-Timestamp: unix ms
 *   X-Webhook-Event:     event name
 *
 * Retries: 3 attempts with exponential backoff (2s, 4s, 8s)
 * Developer can verify authenticity using their webhookSecret.
 */

const axios  = require('axios');
const crypto = require('crypto');
const logger = require('../utils/logger');

// Event types
const EVENTS = {
  BOX_OPENED:         'box_opened',
  COMMISSION_CREDITED:'commission_credited',
  PAYOUT_PROCESSED:   'payout_processed',
  API_KEY_ROTATED:    'api_key_rotated'
};

/**
 * Build HMAC signature for a webhook payload.
 */
function signPayload(secret, timestamp, body) {
  const str = `${timestamp}.${JSON.stringify(body)}`;
  return crypto.createHmac('sha256', secret).update(str).digest('hex');
}

/**
 * Send a webhook with retry logic.
 * @param {string} url            - Developer's webhook URL
 * @param {string} secret         - Developer's webhookSecret
 * @param {string} event          - Event name (from EVENTS)
 * @param {Object} payload        - Event data
 * @param {number} [maxRetries=3]
 */
async function sendWebhook(url, secret, event, payload, maxRetries = 3) {
  if (!url) return { sent: false, reason: 'No webhook URL configured' };

  const timestamp = Date.now();
  const signature = signPayload(secret, timestamp, payload);

  const headers = {
    'Content-Type':          'application/json',
    'X-Webhook-Event':       event,
    'X-Webhook-Timestamp':   String(timestamp),
    'X-Webhook-Signature':   signature,
    'X-Webhook-Version':     '1.0',
    'User-Agent':            'MysteryRewardsPlatform/4.0'
  };

  let lastError;
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      const res = await axios.post(url, payload, { headers, timeout: 8000 });
      logger.info(`Webhook sent: event=${event} dev_url=${url} status=${res.status} attempt=${attempt}`);
      return { sent: true, status: res.status, attempt };
    } catch (err) {
      lastError = err;
      const delay = Math.pow(2, attempt) * 1000; // 2s, 4s, 8s
      logger.warn(`Webhook attempt ${attempt}/${maxRetries} failed: ${err.message} — retry in ${delay}ms`);
      if (attempt < maxRetries) await new Promise(r => setTimeout(r, delay));
    }
  }

  logger.error(`Webhook failed after ${maxRetries} attempts: ${lastError?.message}`);
  return { sent: false, error: lastError?.message };
}

/**
 * Dispatch: box_opened event
 */
async function dispatchBoxOpened(developer, { externalUserId, boxId, boxName, reward, commission }) {
  return sendWebhook(
    developer.webhookUrl,
    developer.webhookSecret,
    EVENTS.BOX_OPENED,
    {
      event:          EVENTS.BOX_OPENED,
      timestamp:      new Date().toISOString(),
      developerId:    developer._id,
      externalUserId,
      boxId,
      boxName,
      reward: {
        name:   reward.name,
        rarity: reward.rarity,
        value:  reward.value,
        image:  reward.image
      },
      commission: +commission.toFixed(4)
    }
  );
}

/**
 * Dispatch: commission_credited event
 */
async function dispatchCommissionCredited(developer, amount, totalBalance) {
  return sendWebhook(
    developer.webhookUrl,
    developer.webhookSecret,
    EVENTS.COMMISSION_CREDITED,
    {
      event:        EVENTS.COMMISSION_CREDITED,
      timestamp:    new Date().toISOString(),
      developerId:  developer._id,
      amount:       +amount.toFixed(4),
      totalBalance: +totalBalance.toFixed(4)
    }
  );
}

/**
 * Dispatch: payout_processed event
 */
async function dispatchPayoutProcessed(developer, payout) {
  return sendWebhook(
    developer.webhookUrl,
    developer.webhookSecret,
    EVENTS.PAYOUT_PROCESSED,
    {
      event:      EVENTS.PAYOUT_PROCESSED,
      timestamp:  new Date().toISOString(),
      payoutId:   payout._id,
      amount:     payout.amount,
      method:     payout.method,
      status:     payout.status
    }
  );
}

/**
 * Verify an incoming webhook from our platform (for SDK use).
 * Developers use this to verify webhooks are from us.
 */
function verifyIncomingWebhook(secret, timestamp, body, signature) {
  const expected = signPayload(secret, timestamp, typeof body === 'string' ? JSON.parse(body) : body);
  try {
    return crypto.timingSafeEqual(Buffer.from(expected, 'hex'), Buffer.from(signature, 'hex'));
  } catch { return false; }
}

module.exports = {
  EVENTS,
  sendWebhook,
  dispatchBoxOpened,
  dispatchCommissionCredited,
  dispatchPayoutProcessed,
  verifyIncomingWebhook
};
