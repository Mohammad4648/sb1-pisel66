const express = require('express');
const router  = express.Router();
const { getFeed, getEpicFeed } = require('../services/activity.service');

// Public endpoints — no auth needed (social proof)
router.get('/',      (req, res) => {
  const limit = Math.min(parseInt(req.query.limit) || 20, 50);
  res.json({ success: true, feed: getFeed(limit) });
});
router.get('/epic', (req, res) => {
  res.json({ success: true, feed: getEpicFeed(10) });
});

module.exports = router;
